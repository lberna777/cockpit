package dentburger.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Collections;
import java.util.HashMap;

public class Menu {

	private Map<Categoria, Map<String,List<Prodotto>> > menu;
	
	public Menu() {
		menu = new HashMap<>();
	}
	
	public void add(Prodotto p) {
		Map<String,List<Prodotto>> prodottiDiQuellaCategoria = menu.get(p.getCategoria());
		if(prodottiDiQuellaCategoria==null) {
			prodottiDiQuellaCategoria = new HashMap<>();
			menu.put(p.getCategoria(), prodottiDiQuellaCategoria);
		}
		List<Prodotto> prodottiDelGiustoTipo = prodottiDiQuellaCategoria.get(p.getGenere());
		if (prodottiDelGiustoTipo==null) {
			prodottiDelGiustoTipo = new ArrayList<>();
			prodottiDiQuellaCategoria.put(p.getGenere(), prodottiDelGiustoTipo);
		}
		if (prodottiDelGiustoTipo.contains(p)) throw new IllegalArgumentException("Prodotto già esistente: " + p);
		else prodottiDelGiustoTipo.add(p);
	}
	
	private Map<String,List<Prodotto>> getProdottiPerCategoria(Categoria c){
		return Map.copyOf(menu.getOrDefault(c, Collections.emptyMap()));
	}
	
	public Set<String> getGeneriPerCategoria(Categoria c){
		return Map.copyOf(menu.getOrDefault(c, Collections.emptyMap())).keySet();
	}
	
	public List<Prodotto> getProdottiPerCategoriaEGenere(Categoria c, String denominazione){
		return List.copyOf(getProdottiPerCategoria(c).getOrDefault(denominazione, Collections.emptyList()));
	}
	
	@Override
	public String toString() { 
		return menu.keySet().stream()
							.map(this::getProdottiPerCategoria)
							.map(Map::entrySet)
							.flatMap(Set::stream)
							.map(entry -> entry.getKey() + " " + entry.getValue().toString())
							.collect(Collectors.joining(System.lineSeparator()));
	}
	
}
