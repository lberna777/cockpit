package dentburger.persistence;

import java.io.IOException;
import java.io.Reader;
import java.text.ParsePosition;
import java.io.BufferedReader;
import dentburger.model.Prodotto;
import dentburger.model.Categoria;
import dentburger.model.Formatters;
import dentburger.model.Menu;


public class MyMenuReader implements MenuReader {
	
	private static final int    TOKEN_COUNT = 4;
	private static final String SEPARATOR = "\t";
	
	@Override
	public Menu leggiProdotti(Reader reader) throws IOException, BadFileFormatException {
		if (reader==null) throw new IllegalArgumentException("Input reader should be open, but is null");
		BufferedReader bufferedReader = new BufferedReader(reader);
		String line;
		var menu = new Menu(); 
		while ((line = bufferedReader.readLine()) != null) {
			String[] items = line.split(SEPARATOR+"+");
			if (items.length!=TOKEN_COUNT) throw new BadFileFormatException("Errato numero di elementi in riga: " + line);
			Categoria c;
			double prezzo;
			try {
				c = Categoria.valueOf(items[0].trim().toUpperCase());
			}
			catch(IllegalArgumentException | NullPointerException e) {
				throw new BadFileFormatException("Categoria errata in riga: " + line);
			}
			ParsePosition pos = new ParsePosition(0);
			String priceAsString = items[3].trim();
			Number n = Formatters.priceFormatter.parse(priceAsString, pos);
			if (pos.getIndex()<priceAsString.length()) 
				throw new BadFileFormatException("Formato prezzo errato alla pos " + pos.getIndex() + " in riga: " + line);
			if (priceAsString.contains(".")) 
				throw new BadFileFormatException("Formato prezzo errato (punto decimale) in riga: " + line);
			prezzo = n.doubleValue();
			if (prezzo<0) throw new BadFileFormatException("Prezzo negativo in riga: " + line);	
			menu.add(new Prodotto(c,items[1].trim(),items[2].trim(),prezzo));
		}
		return menu;
	}


}
