package tangenziale.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import tangenziale.model.Autostrada;
import tangenziale.model.Tipologia;


public class MyAutostradeReader implements AutostradeReader {

	public  Map<String,Autostrada> leggiAutostrade(Reader reader) throws IOException, BadFileFormatException {
		//
		// **** DA FARE ****
		//
		// non c’è alcun costruttore
		//
		// Il metodo leggiAutostrade legge le autostrade e le accumula via via in una mappa, che poi restituirà. 
		// Deve effettuare due fondamentali controlli di consistenza:
		//
		//  1.  Uno su ogni singola autostrada, verificando che in ogni autostrada letta non vi siano due caselli 
		//	    o allacciamenti alla stessa progressiva chilometrica
		//
		//  2.  Un altro al termine della lettura, verificando che *nella rete autostradale nel suo complesso* vi sia 
		//      sempre *una e una sola* tangenziale. 
		//
		return null; // FAKE
	}


}
