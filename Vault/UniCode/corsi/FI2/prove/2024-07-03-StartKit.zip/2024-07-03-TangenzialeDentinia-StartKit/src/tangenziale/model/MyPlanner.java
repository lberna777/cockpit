package tangenziale.model;

import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;

public class MyPlanner implements Planner {

	private Map<String, Autostrada> rete;

	public MyPlanner(Map<String,Autostrada> rete) {
		//
		// ***** DA FARE *****
		//
		// il costruttore riceve la mappa della rete autostradale, che non può essere né nulla, né vuota 
		// (altrimenti, viene lanciata rispettivamente NullPointerException o IllegalArgumentException) 
		// e deve necessariamente contenere almeno la tangenziale (altrimenti, IllegalArgumentException) 
	}

	@Override
	public Percorso trovaPercorso(String da, String a) {
		//
		//  **** DA FARE ****
		//
		//  Calcola e restituisce il Percorso fra i due caselli o allacciamenti specificati, secondo le 
		//  specifiche e la tariffazione descritte nel Dominio del Problema
		//
		//  Preliminarmente, deve verificare accuratamente le precondizioni: 
		//  - gli argomenti non possono essere nulli (altrimenti NullPointerException) 
		//  - i caselli dati devono esistere nella rete autostradale (altrimenti IllegalArgumentException)
		//
		//  Si ricorda che: 
		//  - se i caselli di entrata e di uscita sono sulla stessa autostrada (o tangenziale), il percorso 
		//    è diretto (cioè, è composto da un’unica tratta); 
		//  - se, invece, i caselli di entrata e di uscita sono su due autostrade diverse, il percorso è indiretto 
		//    e comprende tre tratte, di cui senz’altro anche un tratto intermedio in Tangenziale; 
		//  - se, infine, i caselli di entrata e di uscita sono uno su un’autostrada e l’altro sulla Tangenziale 
		//    (o viceversa), il percorso è indiretto e composto di due tratte, una delle quali è senz’altro in Tangenziale
		//
		return null; // FAKE
	}

}

