package contocorrente.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;

import contocorrente.model.Movimento;
import contocorrente.model.ContoCorrente;
import contocorrente.model.Tipologia;


public class MyCCReader implements CCReader {

	/*  CC N.123456789
	 * 	31/01/22 31/01/22	10.317,81 	SALDO INIZIALE A VOSTRO CREDITO
		02/02/22 02/02/22	- 2,90 		IMP.BOLLO CC
		07/02/22 07/02/22 	- 61,59 	SPESE GESTIONE
		...
	 * */

	@Override
	public ContoCorrente readCC(Reader rdr) throws IOException {
		// *** DA FARE *** 
		// vedi testo per le specifiche
		return null; // (fake)
	}
}