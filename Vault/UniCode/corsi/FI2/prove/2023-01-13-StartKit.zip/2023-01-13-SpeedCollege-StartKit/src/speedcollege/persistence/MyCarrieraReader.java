package speedcollege.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;

import speedcollege.model.AttivitaFormativa;
import speedcollege.model.Carriera;
import speedcollege.model.Esame;
import speedcollege.model.Voto;


public class MyCarrieraReader implements CarrieraReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1 (cfu:9)			12/01/20	RT
		27991	ANALISI MATEMATICA T-1 (cfu:9)			10/02/20	22
		28004	FONDAMENTI DI INFORMATICA T-1 (cfu:12)	13/02/20	24
		29228	GEOMETRIA E ALGEBRA T (cfu:6)			18/01/20	26
		26337	LINGUA INGLESE B-2 (cfu:6)
		27993	ANALISI MATEMATICA T-2 (cfu:6)			10/06/20	RE
		27993	ANALISI MATEMATICA T-2 (cfu:6)			02/07/20	RT
		28006	FONDAMENTI DI INFORMATICA T-2 (cfu:12)
		28011	RETI LOGICHE T (cfu:6)		
		...
	*/

	@Override
	public Carriera leggiCarriera(Reader rdr) throws IOException {
		throw new UnsupportedOperationException("ANCORA DA FARE");
	}

}