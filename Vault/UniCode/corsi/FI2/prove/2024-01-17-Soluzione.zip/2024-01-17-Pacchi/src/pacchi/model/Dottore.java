package pacchi.model;

public class Dottore {

	private StatoPartita statoPartita;
	
	public Dottore(StatoPartita statoPartita) {
		this.statoPartita = statoPartita;
	}
	
	public Risposta interpella() {
		// offre fra 1/4 della media e la media
		int media = this.media();
		double fattoreDiScala = 1.0+Math.round(Math.random()*3); // un valore fra 1 e 4
		int possibileOfferta = (int) Math.round(media/fattoreDiScala);
		return new Risposta(new Valore(possibileOfferta));
	}

	public StatoPartita getStatoPartita() { // metodo presente solo per motivi di test
		return statoPartita;
	}
	
	public int media() { // reso pubblico solo per motivi di test
		var tuttiPacchiInGioco = statoPartita.getPacchiDaAprire();
		tuttiPacchiInGioco.add(statoPartita.getPaccoConcorrente());
		return (int) Math.round(tuttiPacchiInGioco.stream().map(Pacco::premio).mapToInt(Valore::valore).average().getAsDouble());
	}
			
}
