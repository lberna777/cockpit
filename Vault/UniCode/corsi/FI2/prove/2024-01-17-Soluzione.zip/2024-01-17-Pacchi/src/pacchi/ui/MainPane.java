package pacchi.ui;

import java.util.HashMap;
import java.util.stream.Collectors;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import pacchi.controller.Controller;
import pacchi.controller.Fase;
import pacchi.model.Formatters;
import pacchi.model.Pacco;
import pacchi.model.Valore;
import pacchi.model.Risposta;



public class MainPane extends BorderPane {
	
	private Controller controller;
	
	private TextArea outputArea;
	private TextField txtRispostaDottore;
	private Button accetta, rifiuta, chiedi;
	private HashMap<Pacco,PaccoButton> mappaPacchiBottoni;
	private Label quantiPacchiDaAprire;
	private Risposta rispostaDottore;
	

	public MainPane(Controller controller) {
		this.controller=controller;
		mappaPacchiBottoni = new HashMap<>();
		//
		VBox leftBox = new VBox();
		leftBox.setPrefWidth(500);
			//
			FlowPane buttonPane = new FlowPane();
			buttonPane.setPrefWidth(500);
			controller.getPacchiDaAprire().stream().forEach(p -> creaPaccoButton(buttonPane, p, "default"));
			leftBox.getChildren().addAll(new Label("  "), buttonPane);
			//
			FlowPane buttonConcorrentePane = new FlowPane();
			buttonConcorrentePane.setPrefWidth(500);
			var labelPaccoConcorrente = new Label("Pacco concorrente: ");
			labelPaccoConcorrente.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
			buttonConcorrentePane.getChildren().add(labelPaccoConcorrente);
			creaPaccoButtonConcorrente(buttonConcorrentePane, controller.getPaccoConcorrente(), "orange");
			leftBox.getChildren().addAll(new Label("  "), buttonConcorrentePane);
			//
			quantiPacchiDaAprire = new Label("Pacchi da aprire: " + controller.quantiDaAprire());
			quantiPacchiDaAprire.setPrefWidth(500);
			quantiPacchiDaAprire.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
			leftBox.getChildren().addAll(new Label("  "), quantiPacchiDaAprire);
			//
			var labelChiediDottore = new Label("Chiedi al Dottore: ");
			labelChiediDottore.setPrefWidth(500);
			labelChiediDottore.setFont(Font.font("Courier New", FontWeight.BOLD, 14));
			leftBox.getChildren().add(labelChiediDottore);
			//
			var miniHBoxDottore = new HBox();
				miniHBoxDottore.setPrefWidth(500);
				miniHBoxDottore.setAlignment(Pos.CENTER);
				chiedi = new Button("Chiedi");
				chiedi.setDisable(true);
				chiedi.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
				chiedi.setOnAction(ev -> interpellaDottore());
				miniHBoxDottore.getChildren().addAll(chiedi, new Label("   Risposta: "));
				txtRispostaDottore = new TextField(); 
				txtRispostaDottore.setEditable(false);
				txtRispostaDottore.setPrefWidth(130);
				miniHBoxDottore.getChildren().addAll(txtRispostaDottore, new Label("   ") );
				accetta = new Button("Accetta");
				accetta.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
				accetta.setDisable(true);
				accetta.setOnAction(ev -> accettaOfferta());	
				rifiuta = new Button("Rifiuta");
				rifiuta.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
				rifiuta.setDisable(true);
				rifiuta.setOnAction(ev -> rifiutaOfferta());
				miniHBoxDottore.getChildren().addAll(accetta,new Label("   "), rifiuta);
			leftBox.getChildren().addAll(new Label("  "), miniHBoxDottore);
			this.setLeft(leftBox);
		VBox rightBox = new VBox();
			rightBox.setPrefWidth(200);
			outputArea = new TextArea();
			outputArea.setPrefSize(200,430);
			outputArea.setFont(Font.font("Courier New", FontWeight.NORMAL, 14));
			outputArea.setEditable(false);
			rightBox.getChildren().addAll(outputArea);
			outputArea.setText(sintetizzaOutput());
		this.setRight(rightBox);
	}

	private void creaPaccoButton(FlowPane pane, Pacco p, String color) {
		var paccoButton = new PaccoButton(p.territorio(), p.numero(), color);
		mappaPacchiBottoni.put(p, paccoButton);
		paccoButton.setOnAction(ev -> apriPacco(p));
		pane.getChildren().add(paccoButton);
	}

	private void creaPaccoButtonConcorrente(FlowPane pane, Pacco p, String color) {
		var paccoButton = new PaccoButton(p.territorio(), p.numero(), color);
		mappaPacchiBottoni.put(p, paccoButton);
		paccoButton.setOnAction( ev -> 
			Controller.alert("STOP", "Fase di gioco errata", "Non puoi aprire il pacco concorrente ora.") );
		pane.getChildren().add(paccoButton);
	}

	private void interpellaDottore() {
		if (controller.getFase()!=Fase.INTERPELLA_DOTTORE) {
			Controller.alert("STOP", "Fase di gioco errata", "Impossibile interpellare il Dottore in questa fase.");
			return;
		}
		rispostaDottore = controller.interpellaDottore();
		txtRispostaDottore.setText(rispostaDottore.toString());
		controller.setFase(Fase.ACCETTA_RIFIUTA);
		accetta.setDisable(false);
		rifiuta.setDisable(false);
		chiedi.setDisable(true);
	}
	
	private void rifiutaOfferta() {
		if (controller.getFase()!=Fase.ACCETTA_RIFIUTA) {
			Controller.alert("STOP", "Fase di gioco errata", "Impossibile accettare o rifiutare offerte/cambi in questa fase)");
			return;
		}
		if (controller.premiRimasti().size()==2) {
			//
			controller.setFase(Fase.FINE);
			Controller.alert("FINE GIOCO", "Hai rifiutato l'offerta", "Hai vinto il contenuto del tuo pacco: " 
												+ Formatters.priceFormatter.format(controller.apriPaccoConcorrente().valore()));
			// resta da aprire l'ultimo pacco rimasto
			var ultimoPaccoDaAprire = controller.getPacchiDaAprire().iterator().next();
			aggiornaPaccoButton(ultimoPaccoDaAprire);
			aggiornaPaccoButton(controller.getPaccoConcorrente());
			controller.apriUltimoPacco(ultimoPaccoDaAprire.numero());
			sintetizzaOutput(); // per aggiornare il tabellone
		}
		else {
			controller.setFase(Fase.APERTURA_PACCHI);
			var q = controller.quantiDaAprire();
			Controller.alert("PROSECUZIONE GIOCO", "Hai rifiutato l'offerta","Ora dovrai aprire altri " + q + (" pacchi."));
			quantiPacchiDaAprire.setText("Pacchi da aprire: " + q);
		}
		accetta.setDisable(true);
		rifiuta.setDisable(true);
		txtRispostaDottore.setText("");
	}

	private void accettaOfferta() {
		if (controller.getFase()!=Fase.ACCETTA_RIFIUTA) {
			Controller.alert("STOP", "Fase di gioco errata", "Impossibile accettare o rifiutare offerte/cambi in questa fase.");
			return;
		}
		Controller.alert("FINE GIOCO", "Hai accettato l'offerta", 
					"Nel tuo pacco avevi: " + Formatters.priceFormatter.format(controller.apriPaccoConcorrente().valore()));
		accetta.setDisable(true);
		rifiuta.setDisable(true);
		aggiornaPaccoButton(controller.getPaccoConcorrente());
		controller.setFase(Fase.FINE);
	}

	private void apriPacco(Pacco p) {
		if (controller.getFase()!=Fase.APERTURA_PACCHI) {
			Controller.alert("STOP", "Fase di gioco errata", "Impossibile aprire pacchi in questa fase)");
			return;
		}
		if(controller.quantiDaAprire()==0) {
			Controller.alert("STOP", "Operazione inconsistente", "Già aperti tutti i pacchi previsti, ora chiedi al Dottore.");
			return;
		}
		aggiornaPaccoButton(p);
		controller.apriPacco(p.numero());
		quantiPacchiDaAprire.setText("Pacchi da aprire: " + controller.quantiDaAprire());
		outputArea.setText(sintetizzaOutput());
		if(controller.quantiDaAprire()==0) {
			controller.setFase(Fase.INTERPELLA_DOTTORE);
			chiedi.setDisable(false);
		}
	}

	private void aggiornaPaccoButton(Pacco p) {
		var button = this.mappaPacchiBottoni.get(p);
		button.setDisable(true);
		button.setText(p.toString() + System.lineSeparator() + Formatters.priceFormatter.format(p.premio().valore()));
	}
	
	private String sintetizzaOutput() {
		return 	"CONCORRENTE: " +
				System.lineSeparator() +
				controller.getPaccoConcorrente().toString() +
				System.lineSeparator() +
				System.lineSeparator() +
				controller.premiRimasti().stream()
										.map(Valore::valore)
										.map(Formatters.priceFormatter::format)
										.collect(Collectors.joining(System.lineSeparator(), "TABELLONE PREMI"+System.lineSeparator(), ""));
	}
	
}
