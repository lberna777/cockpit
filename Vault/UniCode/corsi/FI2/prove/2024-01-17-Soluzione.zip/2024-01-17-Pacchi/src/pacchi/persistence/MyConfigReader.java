package pacchi.persistence;

import java.io.IOException;
import java.io.Reader;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import pacchi.model.Territorio;
import pacchi.model.Formatters;
import pacchi.model.Valore;
import java.io.BufferedReader;


public class MyConfigReader implements ConfigReader {
	
	@Override
	public Set<Territorio> leggiTerritori(Reader reader) throws IOException, BadFileFormatException {
		if (reader==null) throw new IllegalArgumentException("Input reader null in leggiTerritori");
		BufferedReader bufferedReader = new BufferedReader(reader);
		String line;
		var territori = new HashSet<Territorio>(); 
		while ((line = bufferedReader.readLine()) != null) {
			territori.add(new Territorio(line.trim()));
		}
		return territori;
	}

	@Override
	public Set<Valore> leggiPremi(Reader reader) throws IOException, BadFileFormatException {
		if (reader==null) throw new IllegalArgumentException("Input reader null in leggiPremi");
		BufferedReader bufferedReader = new BufferedReader(reader);
		var premi = new HashSet<Valore>(); 
		String rigaPremiBassi = bufferedReader.readLine();
		String rigaPremiAlti  = bufferedReader.readLine();
		Set<Valore> premiAlti, premiBassi;
		try {
			premiAlti = elaboraRiga(rigaPremiAlti, ":", "PREMI ALTI");
			premi.addAll(premiAlti);
		} catch(IllegalArgumentException e) {
			throw new BadFileFormatException("Errato valore premio in riga: " + rigaPremiAlti);
		}
		try {
			premiBassi = elaboraRiga(rigaPremiBassi, ":", "PREMI BASSI");
			if (premiAlti.size() != premiBassi.size()) throw new BadFileFormatException("Diverso numero di premi alti e bassi");
			premi.addAll(premiBassi);
		} catch(IllegalArgumentException e) {
			throw new BadFileFormatException("Errato valore premio in riga: " + rigaPremiBassi);
		}
		return premi;
	}

	private Set<Valore> elaboraRiga(String rigaPremi, String separatore, String header) throws BadFileFormatException {
		String[] items = rigaPremi.split(separatore);
		if (items.length!=2) throw new BadFileFormatException("Errato numero di elementi in riga premi: " + rigaPremi);
		if (!items[0].trim().equals(header)) throw new BadFileFormatException("Errato header in riga premi: atteso " + header + ", riga=" + rigaPremi);
		return Stream.of(items[1].split(",")).map(String::trim)
											 .map(Formatters::parse)
											 .mapToInt(Number::intValue)
											 .mapToObj(Valore::new)
											 .collect(Collectors.toSet());
	}

}
