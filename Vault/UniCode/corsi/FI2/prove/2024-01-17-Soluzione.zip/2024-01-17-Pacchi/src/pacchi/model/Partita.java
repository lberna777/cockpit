package pacchi.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;

public class Partita {

	private Set<Territorio> territori;
	private Set<Valore> premi;
	private Set<Pacco> pacchi;
	private StatoPartita statoPartita;
	private Dottore dottore;
	
	public Partita(Set<Territorio> territori, Set<Valore> premi) {
		if (territori==null) throw new IllegalArgumentException("Lista territori nulla");
		if (premi==null) throw new IllegalArgumentException("Lista premi nulla");
		if (territori.size()<=0) throw new IllegalArgumentException("Lista territori di lunghezza inammissibile");
		if (premi.size()<=0) throw new IllegalArgumentException("Liste premi di lunghezza inammissibile");
		if (territori.size()!=premi.size()) throw new IllegalArgumentException("Liste territori e valori di lunghezza diversa");
		//
		this.territori = territori;
		this.premi = new HashSet<>(premi);
		this.pacchi = generaPacchi(territori, premi);
		//
		int indexPaccoConcorrente = (int) Math.floor(Math.random()*pacchi.size());
		var paccIterator = pacchi.iterator();
		for(int k=0; k<indexPaccoConcorrente;k++) paccIterator.next(); // ne salta un certo numero
		Pacco paccoConcorrente = paccIterator.next();
		paccIterator.remove();
		
		this.statoPartita = new StatoPartita(pacchi, paccoConcorrente);
		this.dottore = new Dottore(this.statoPartita);
	}

	public Set<Pacco> generaPacchi(Set<Territorio> territori, Set<Valore> premi) {
		// Metodo che dovrebbe essere privato, reso pubblico solo per motivi di test
		// Per lo stesso motivo non effettua validazione degli argomenti ricevuti, già validati dal costruttore
		var pacchi = new HashSet<Pacco>();

		Integer[] indiciPremi = Stream.generate(() -> (int) Math.floor(Math.random()*this.premi.size())+1)
									  .distinct()
									  .limit(this.premi.size())
									  .toArray(Integer[]::new);
		
		var terrIterator = territori.iterator();
		var premIterator = premi.iterator();
		var i=0;
		while (terrIterator.hasNext()) {
			pacchi.add(new Pacco(terrIterator.next(), new Numero(indiciPremi[i++]), premIterator.next()));
		}
		return pacchi;
	}

	public Set<Territorio> getTerritori() {
		return territori;
	}

	public Set<Valore> getPremi() {
		return premi;
	}

	public Set<Pacco> getPacchi() {
		return pacchi;
	}

	public StatoPartita getStatoPartita() {
		return statoPartita;
	}

	public Risposta interpellaDottore() {
		return dottore.interpella();
	}
	
	public double media() {
		return dottore.media();
	}
	
	public Valore apriPacco(Numero numeroPacco) {
		if(numeroPacco.valore()<=0 || numeroPacco.valore()>this.pacchi.size()+1) throw new IllegalArgumentException("Impossibile aprire pacco n." + numeroPacco + ", pacco inesistente");
		var paccoDaAprire = this.pacchi.stream().filter(p -> p.numero().equals(numeroPacco)).toList().get(0);
		return this.statoPartita.apriPacco(paccoDaAprire);
	}
	
	public Pacco getPacco(Numero numeroPacco) {
		if(numeroPacco.valore()<0 || numeroPacco.valore()>this.pacchi.size()+1) throw new IllegalArgumentException("Impossibile aprire pacco n." + numeroPacco + ", pacco inesistente");
		return this.pacchi.stream().filter(p -> p.numero().equals(numeroPacco)).toList().get(0);
	}

	@Override
	public String toString() {
		return "Partita [listaRegioni=" + territori + ", listaValori=" + premi + ", listaPacchi=" + pacchi
				+ ", statoPartita=" + statoPartita + ", dottore=" + dottore + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(premi, territori);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		Partita other = (Partita) obj;
		return Objects.equals(premi, other.premi) && Objects.equals(territori, other.territori);
	}
			
}
