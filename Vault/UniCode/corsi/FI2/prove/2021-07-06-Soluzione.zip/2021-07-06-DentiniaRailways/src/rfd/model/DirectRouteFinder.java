package rfd.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class DirectRouteFinder extends RouteFinder {

	public DirectRouteFinder(Set<RailwayLine> rwylines) {
		super(rwylines);
	}

	// ---- versione con stream ----
	/*
	@Override
	public List<Route> getRoutes(String from, String to) {
		if(from==null||to==null) throw new IllegalArgumentException("Null from/to station
		return rwylines .stream()
						.map(    railway -> railway.getSegment(from, to)             ) // chiedo se esiste quel segmento diretto
						.filter( optionalSegment -> optionalSegment.isPresent()      ) // filtro solo quelli che esistono davvero
						.map(    optionalSegment -> new Route(optionalSegment.get()) ) // costruisco la route con quel singolo segmento
						.collect(Collectors.toList());								   // saluti e baci :)
	}
	*/

	// ---- versione classica senza stream ----
	@Override
	public List<Route> getRoutes(String from, String to) {
		if(from==null||to==null) throw new IllegalArgumentException("Null from/to station");
		List<Route> result = new ArrayList<>();
		for(RailwayLine railway: this.getLinesAtStation(from)) {
			Optional<Segment> optionalSegment = railway.getSegment(from, to);
			if(optionalSegment.isPresent()) {
				result.add(new Route(optionalSegment.get()));
			}
		}
		return result;
	}
	
}
