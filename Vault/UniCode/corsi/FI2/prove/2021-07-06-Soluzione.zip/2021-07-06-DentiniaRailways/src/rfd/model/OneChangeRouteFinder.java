package rfd.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class OneChangeRouteFinder extends RouteFinder {
	
	public OneChangeRouteFinder(Set<RailwayLine> rwylines) {
		super(rwylines);
	}

	// ---- versione classica, senza stream ----
	@Override
	public List<Route> getRoutes(String from, String to) {
		List<Route> result = new ArrayList<>();
		for(RailwayLine railway: this.getLinesAtStation(from)) {		// Per ogni linea che passa dalla stazione di partenza
			if(!railway.getPointOfInterest(to).isPresent()) {			// che non contenga la stazione di arrivo (altrimenti sarebbe diretto) 
				for (String hub : railway.getTransferPoints()) {					// Ricaviamo i rispettivi hub (diversi dalla stazione stessa)
					Optional<Route> route = makeRoute(from, hub, to);	// Cerchiamo di costruire una route da essa alla destinazione via quell' hub
					if (route.isPresent()) {							// Se c'�...
						result.add(route.get());						// .. la aggiungiamo al risultato
					}
				}
			}
		}
		return result;
	}
	
	private Optional<Route> makeRoute(String from, String hub, String to) {
		DirectRouteFinder f = new DirectRouteFinder(rwylines);
		List<Route> fromHub = f.getRoutes(from, hub); // è sicuramente una lista di al più un solo elemento
		List<Route> hubTo   = f.getRoutes(hub,to);    // è sicuramente una lista di al più un solo elemento
		if (fromHub.size()<1 || hubTo.size()<1 ) return Optional.empty();
		else {
			Route ah = fromHub.get(0);
			Route hb = hubTo.get(0);
			Route result = new Route();
			ah.getRouteSegments().forEach( s-> result.add(s));
			hb.getRouteSegments().forEach( s-> result.add(s));
			return Optional.of(result);
		} 
	}
	
	// ---- versione con stream ----
	/*
	@Override
	public List<Route> getRoutes(String from, String to) {
		//System.err.println("searching from " + from + " to " + to);
		return	rwylines.stream()
						.filter(  railway -> railway.getPointOfInterest(from).isPresent() ) // Filtriamo solo railways con quella città di partenza..
						.filter(  railway -> !railway.getPointOfInterest(to).isPresent()  ) // ..che NON includono anche la città di arrivo
						.flatMap( railway -> railway.getHubs().stream() ) 					// Recuperiamo elenco di tutti gli hub...
						.distinct()															// ...togliamo i duplicati...
						.filter( hub -> !hub.equals(from))									// ..escludiamo la città di origine (nel caso fosse un hub)
						.filter( hub -> !hub.equals(to))									// ..e la città di origine (nel caso fosse un hub)
						.map( hub -> makeRoute(from,hub,to) )								// Cerchiamo di costruire una route da "from" a "to" via quell' hub
						.filter( optRoute -> optRoute.isPresent() )							// Se c'è...
						.map( optRoute -> optRoute.get())									// .. la estraiamo..
						//.peek(System.out::println)			
						.collect(Collectors.toList());										// .. e la aggiungiamo al risultato
	}
	*/

}
