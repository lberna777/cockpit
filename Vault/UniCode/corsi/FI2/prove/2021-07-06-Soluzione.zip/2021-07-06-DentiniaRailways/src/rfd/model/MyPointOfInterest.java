package rfd.model;

import java.util.Arrays;

public class MyPointOfInterest extends PointOfInterest {

	public MyPointOfInterest(String name, String progressivaKm) {
		super(name, progressivaKm);
		if (!progressivaKm.matches("[0-9]+\\+[0-9][0-9][0-9]")) throw new IllegalArgumentException("Progressiva chilometrica non valida: " + progressivaKm);
		// 
		// In alternativa: usare split e parseDouble esattamente come sotto, magari richiamando proprio lo stesso metodo in un try/catch,
		// catturando NumberFormatException per rilanciare la prescritta IllegalArgumentException; nella split controllare la lunghezza
		// delle due parti per verificare il numero di cifre
	}

	// --- versione tradizionale ---
	/*
	@Override
	public double getKmAsNum() {
		String[] items = getKm().split("\\+");
		double km = Double.parseDouble(items[0]);
		double mt = Double.parseDouble(items[1]);
		return km + mt/1000;
	}
	*/

	// --- versione con stream ---
	
	@Override
	public double getKmAsNum() {
		return Arrays.stream(getKm().split("\\+"))
					 .mapToDouble(Double::parseDouble)
					 .reduce((acc,v)->acc*1000+v)
					 .getAsDouble()/1000;
	}
	
}
