package rfd.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import rfd.model.PointOfInterest;
import rfd.model.MyPointOfInterest;
import rfd.model.RailwayLine;

public class MyRailwayLineReader implements RailwayLineReader {

	@Override
	public RailwayLine getRailwayLine(Reader rdr) throws IOException{
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		SortedMap<String,PointOfInterest> map = new TreeMap<>();
		SortedSet<String> transferPoints = new TreeSet<>();
		String line;
		while((line = reader.readLine())!=null) {
			String[] parts = line.split("\\t+"); // '+' needed in case of two or more subsequent tabs
			if(parts.length!=2) throw new IllegalArgumentException("badly formatted line");
			parts[1] = parts[1].trim();
			if(parts[1].equals("+") || "0123456789".indexOf(parts[1].charAt(0))>=0) { 
				throw new IllegalArgumentException("badly formatted line");
			}
			if(parts[1].endsWith("+")) { 
				parts[1] = parts[1].substring(0,parts[1].length()-1);
				if(parts[1].endsWith(" ")) throw new IllegalArgumentException("badly formatted line");
				transferPoints.add(parts[1]);
			}
			PointOfInterest poi = new MyPointOfInterest(parts[1], parts[0].trim());
			map.put(parts[1].trim(), poi);
		}
		return new RailwayLine(map, transferPoints);
	}
}