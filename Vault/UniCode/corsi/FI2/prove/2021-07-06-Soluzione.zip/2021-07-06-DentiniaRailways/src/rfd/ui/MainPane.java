package rfd.ui;

import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import rfd.controller.Controller;
import rfd.model.Route;


public class MainPane extends BorderPane {
	
	private TextArea outputArea; 
	private ComboBox<String> comboFrom, comboTo;
	private Controller controller;
	private CheckBox senzaCambi, unCambio;

	public MainPane(Controller controller) {
		this.controller=controller;
		HBox topBox = new HBox();
		topBox.setPrefHeight(40);
		// populate combos
		comboFrom = new ComboBox<>(); populateCombo(comboFrom);
		comboTo   = new ComboBox<>(); populateCombo(comboTo);
		comboFrom.setOnAction(this::reset);
		comboTo.setOnAction(this::reset);
		topBox.getChildren().addAll(new Label("Partenza "), comboFrom, new Label("  Arrivo "), comboTo);
		this.setTop(topBox);
		//
		HBox centerBox = new HBox();
		centerBox.setPrefHeight(80);
		centerBox.setAlignment(Pos.CENTER);
		senzaCambi = new CheckBox("senza cambi");
		unCambio = new CheckBox("con un cambio");
		centerBox.getChildren().addAll(new Label("Mostra soluzioni:    "), senzaCambi, new Label("   "), unCambio);
		this.setCenter(centerBox);
		//
		//b1.setOnAction(this::findDirectRoutes); 
		//b2.setOnAction(this::findIndirectRoutes);
		senzaCambi.setOnAction(this::myHandle); 
		unCambio.setOnAction(this::myHandle); 
		//
		outputArea = new TextArea();
		outputArea.setPrefSize(500,300);
		outputArea.setFont(Font.font("Courier New", 12));
		this.setBottom(outputArea);
	}

	private void populateCombo(ComboBox<String> combo) {
		combo.setItems(FXCollections.observableArrayList(this.controller.getStationNames()));
	}
	
	private void reset(ActionEvent event) {
		outputArea.setText("");
		senzaCambi.setSelected(false);
		unCambio.setSelected(false);
	}
	
	protected void myHandle(ActionEvent event) {
		outputArea.setText("");
		String from = comboFrom.getValue(); 
		String to   = comboTo.getValue();
		if (from==null || to == null) return; // se uno solo dei due è selezionato
		if(senzaCambi.isSelected()) findDirectRoutes(from, to);
		if(unCambio.isSelected()) findIndirectRoutes(from, to);
	}
	
	protected void findDirectRoutes(String from, String to) {
		String percorsiTrovati = controller.getDirectRoutes(from, to).stream().map(Route::toString).collect(Collectors.joining(System.lineSeparator()+System.lineSeparator())); 
		if (percorsiTrovati!=null && percorsiTrovati.length()>0) {
			outputArea.appendText("PERCORSI DIRETTI SENZA CAMBI:"+System.lineSeparator());
			outputArea.appendText(percorsiTrovati + System.lineSeparator() + System.lineSeparator());
		}
	}
	protected void findIndirectRoutes(String from, String to) {
		String percorsiTrovati = controller.getIndirectRoutes(from, to).stream().map(Route::toString).collect(Collectors.joining(System.lineSeparator()+System.lineSeparator()));
		if (percorsiTrovati!=null && percorsiTrovati.length()>0) {
			outputArea.appendText("PERCORSI INDIRETTI CON CAMBI:"+System.lineSeparator());
			outputArea.appendText(percorsiTrovati + System.lineSeparator() + System.lineSeparator());
		}
	}

}
