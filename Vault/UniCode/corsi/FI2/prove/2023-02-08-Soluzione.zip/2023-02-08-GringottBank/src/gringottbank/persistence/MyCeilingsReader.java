package gringottbank.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import gringottbank.model.Ceiling;
import gringottbank.model.Coin;
import gringottbank.model.CoinAmount;

	 /*
		Harry		20 galeoni
		Hermione	19 galeoni, 20 zellini
		Enrico		200 galeoni
		Ambra		100 galeoni, 20 zellini
		Roberta		100 galeoni, 28 zellini
		Ron			12 galeoni, 10 falci, 6 zellini
	 */

public class MyCeilingsReader implements CeilingsReader {

	@Override
	public List<Ceiling> readCeilings(Reader rdr) throws IOException, BadFileFormatException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		List<Ceiling> result = new ArrayList<>();
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			
			String[] items = line.split("\\t+");
			// ci sono sempre 2 elementi
			if (items.length!=2) throw new BadFileFormatException("Riga mal formattata, non ha i due elementi richiesti:\t" + line);

			// estrazione elementi
			String nome = items[0].trim();
			if (nome.length()==0) throw new BadFileFormatException("Riga mal formattata, manca il nome del cliente:\t" + line);
			String importoAsString	= items[1].trim().toLowerCase();
						
			// ammontare: verifica e sintesi del giusto Amount
			result.add(new Ceiling(nome, extractAmount(importoAsString))); 							
		}
		return result;
	}
	
	private CoinAmount extractAmount(String importoAsString) throws BadFileFormatException {		
		String[] sottoImporti = importoAsString.split(",");
		if (sottoImporti.length<1 || sottoImporti.length>3) throw new BadFileFormatException("Formato importo illegale:\t" + importoAsString);
		
		CoinAmount amount = new CoinAmount();
		
		for(String sottoImporto: sottoImporti) {
			String elements[] = sottoImporto.trim().split("\\s+");
			if (elements.length!=2) throw new BadFileFormatException("Formato sotto-importo illegale: non ci sono due elementi\t" + sottoImporto);
			
			int importo = parsePositive(elements[0]);
			String valuta = elements[1].trim();
			
			if (!Arrays.asList(Coin.getNames()).contains(valuta))
					throw new BadFileFormatException("Formato sotto-importo illegale: valuta imprevista\t" + sottoImporto);
			amount.plus(Coin.of(valuta), importo);
		}
		return amount;
	}

	private int parsePositive(String s) throws BadFileFormatException {
		int importo;
		try {
			importo = Integer.parseInt(s);
		}
		catch(NumberFormatException e) {
			throw new BadFileFormatException("Formato sotto-importo illegale: numero errato\t" + s);
		}
		if (importo<0) throw new BadFileFormatException("Formato sotto-importo illegale: numero negativo\t" + s);
		return importo;
	}
	
}