package contocorrente.model;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Objects;

public class Movimento {
	private LocalDate dataContabile, dataValuta;
	private Tipologia tipologia;
	private double importo;
	private String causale;
	private NumberFormat currencyFormatter;
		
	public Movimento(LocalDate dataContabile, LocalDate dataValuta, Tipologia tipologia, double importo, String causale) {
		if(dataContabile==null || dataValuta==null || tipologia==null || Double.isNaN(importo) || causale==null)
			throw new IllegalArgumentException("Argomento nullo nel movimento");
		if(importo<0 && (tipologia!=Tipologia.ADDEBITO && tipologia!=Tipologia.SALDO))
			throw new IllegalArgumentException("Accredito negativo");
		if(importo>0 && (tipologia!=Tipologia.ACCREDITO && tipologia!=Tipologia.SALDO))
			throw new IllegalArgumentException("Addebito positivo");
		if(importo==0 && (tipologia!=Tipologia.NULLO && tipologia!=Tipologia.SALDO))
			throw new IllegalArgumentException("Addebito/accredito nullo");
		this.dataContabile = dataContabile;
		this.dataValuta = dataValuta;
		this.tipologia = tipologia;
		this.importo = importo;
		this.causale = causale.toUpperCase(Locale.ITALY);
		currencyFormatter = NumberFormat.getCurrencyInstance(Locale.ITALY);
	}
	
	public LocalDate getDataContabile() {
		return dataContabile;
	}
	public LocalDate getDataValuta() {
		return dataValuta;
	}
	public Tipologia getTipologia() {
		return tipologia;
	}
	public double getImporto() {
		return importo;
	}
	public String getCausale() {
		return causale;
	}

	@Override
	public int hashCode() {
		return Objects.hash(causale, dataContabile, dataValuta, importo, tipologia);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		Movimento other = (Movimento) obj;
		return Objects.equals(causale, other.causale) && Objects.equals(dataContabile, other.dataContabile)
				&& Objects.equals(dataValuta, other.dataValuta)
				&& Double.doubleToLongBits(importo) == Double.doubleToLongBits(other.importo)
				&& tipologia == other.tipologia;
	}

	@Override
	public String toString() {
		return dataContabile + " " + tipologia + " di " + currencyFormatter.format(importo) + " per " + causale;
	}
	
}
