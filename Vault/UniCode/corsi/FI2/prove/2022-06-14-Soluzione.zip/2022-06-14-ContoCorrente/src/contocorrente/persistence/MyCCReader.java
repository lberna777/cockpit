package contocorrente.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;

import contocorrente.model.Movimento;
import contocorrente.model.ContoCorrente;
import contocorrente.model.Tipologia;


public class MyCCReader implements CCReader {

	/*  CC N.123456789
	 * 	31/01/22 31/01/22	10.317,81 	SALDO INIZIALE A VOSTRO CREDITO
		02/02/22 02/02/22	- 2,90 		IMP.BOLLO CC
		07/02/22 07/02/22 	- 61,59 	SPESE GESTIONE
		...
	 * */

	@Override
	public ContoCorrente readCC(Reader rdr) throws IOException {
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		
		long id;
		// Elaborazione riga di intestazione
		String line = reader.readLine();
		String[] items = line.split("\s+");
		// validazione input
		if (items.length<2 || items.length>3)
			throw new BadFileFormatException("Numero elementi errato nella riga di intestazione");
		if (!items[0].toUpperCase().equals("CC"))
			throw new BadFileFormatException("La riga di intestazione non inizia con 'CC'");
		if (!items[1].toUpperCase().startsWith("N."))
			throw new BadFileFormatException("La riga di intestazione non contiene 'N.'");
		if (items.length>2 && !items[1].toUpperCase().equalsIgnoreCase("N."))
			throw new BadFileFormatException("Numero elementi errato nella riga di intestazione");
		
		String ccId = items.length==2 ? items[1].substring("N.".length()) : items[2];
		try {
			id = Long.parseLong(ccId);
			if(id<0) throw new BadFileFormatException("Il numero di conto corrente non può essere negativo");
		}
		catch(NumberFormatException e) {
			throw new BadFileFormatException("La riga di intestazione non contiene il numero di conto corrente");
		}
		
		// Elaborazione movimenti
		
		ContoCorrente cc = new ContoCorrente(id);
		
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			items = line.split("\t+");
			// ci devono essere sempre 4 parti
			if (items.length!=4) 
				throw new BadFileFormatException("La riga non contiene un movimento correttamente formattato'\t" + line);
			String strDataContabile = items[0].trim(); 
			String strDataValuta 	= items[1].trim(); 
			String strImporto 	 	= items[2].trim();
			String causale 	 		= items[3].trim().toUpperCase();
			// validazione e conversione
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).withLocale(Locale.ITALY);
			try {
				LocalDate dataContabile = LocalDate.parse(strDataContabile,dateFormatter);
				LocalDate dataValuta    = LocalDate.parse(strDataValuta,dateFormatter);
				NumberFormat formatter = NumberFormat.getNumberInstance(Locale.ITALY);
				double importo = formatter.parse(strImporto.replace(" ", "")).doubleValue();
				Tipologia tip = causale.startsWith("SALDO") && !causale.startsWith("SALDO INIZIALE") ? Tipologia.SALDO : 
								importo>0 ? (Tipologia.ACCREDITO) : 
								importo<0 ? Tipologia.ADDEBITO : Tipologia.NULLO;
				cc.aggiungi(new Movimento(dataContabile, dataValuta, tip, importo, causale.toUpperCase()));
			}
			catch(DateTimeParseException | ParseException e) {
				throw new BadFileFormatException("Il movimento contiene una data o un importo non correttamente formattati'\t" + line);
			}
		}
		return cc;
	}
}