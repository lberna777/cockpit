package contocorrente.model;

import java.time.LocalDate;

public class MyAnalizzatore implements Analizzatore {
	
	private ContoCorrente cc;
	
	public MyAnalizzatore(ContoCorrente cc) {
		if(cc==null) throw new IllegalArgumentException("CC nullo nel costruttore dell'analizzatore dati");
		this.cc=cc;
	}

	@Override
	public double getSaldo(LocalDate data) {
		double saldo = 0;
		for(Movimento m : cc.getMovimenti())
			if (!m.getDataContabile().isAfter(data)) {
				if (m.getTipologia()!=Tipologia.SALDO) saldo += m.getImporto();
				else {
					if (Math.abs(m.getImporto()-saldo)>0.01) throw new InconsistentBalanceException("Saldo dichiarato " + m.getImporto() + " diverso da somma movimenti precedenti " + saldo);
				}
			}
		return saldo;
	}
	
	@Override
	public double getSommaPerTipologia(LocalDate data, Tipologia tipologia) {
		if (tipologia!=Tipologia.ACCREDITO && tipologia!=Tipologia.ADDEBITO)
			throw new IllegalArgumentException("Tipologia non ammessa nella somma per tipologia dell'analizzatore dati");
		double somma = 0;
		for(Movimento m : cc.getMovimenti()) {
			if (!m.getDataContabile().isAfter(data) && m.getTipologia()==tipologia) somma += m.getImporto();
			}
		return somma;
	}
	
}
