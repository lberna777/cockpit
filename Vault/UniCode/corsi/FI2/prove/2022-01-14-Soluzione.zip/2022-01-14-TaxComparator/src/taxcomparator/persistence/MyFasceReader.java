package taxcomparator.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import taxcomparator.model.*;

public class MyFasceReader implements FasceReader {

	public Fasce readFasce(String descr, Reader reader) throws BadFileFormatException, IOException {
		if (reader == null) throw new IllegalArgumentException("reader nullo in readFasce");

		List<Fascia> listaFasce = new ArrayList<>();
		double noTaxArea = Double.NaN;
		
		try {
			BufferedReader bufferedReader = new BufferedReader(reader);
			NumberFormat formatter = NumberFormat.getNumberInstance(Locale.ITALY);
			String line = bufferedReader.readLine(); // prima riga
			if (line==null) throw new BadFileFormatException("empty file");
			String[] items = line.trim().split(":");
			if (!items[0].trim().equalsIgnoreCase("no-tax area")) throw new BadFileFormatException("bad no tax area specification in first line");
			noTaxArea = formatter.parse(items[1].trim()).doubleValue();

			while ((line = bufferedReader.readLine()) != null) {
				StringTokenizer tokenizer = new StringTokenizer(line, "-:\t");
				String min = tokenizer.nextToken().trim();
				String max = tokenizer.nextToken().trim(); 
				String perc = tokenizer.nextToken().trim();
				// verifiche consistenza formato
				double sogliaMin = formatter.parse(min).doubleValue();
				Fascia fascia = 
						max.equalsIgnoreCase("oltre") ? new Fascia(sogliaMin, perc) 
										    : new Fascia(sogliaMin, formatter.parse(max).doubleValue(), perc);
				listaFasce.add(fascia);
			}
			
		} catch (ParseException | NoSuchElementException e) {
			throw new BadFileFormatException(e + "Errore lettura fasce");
		}
		return new Fasce(descr, listaFasce, noTaxArea);

	}

}
