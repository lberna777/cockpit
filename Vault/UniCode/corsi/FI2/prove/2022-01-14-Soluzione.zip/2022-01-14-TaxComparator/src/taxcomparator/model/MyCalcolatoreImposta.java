package taxcomparator.model;

import java.text.DecimalFormat;

public class MyCalcolatoreImposta implements CalcolatoreImposta {
	
	private Fasce fasce;	
	private StringBuilder logger;
	private DecimalFormat formatter;
	
	public MyCalcolatoreImposta() {
		logger = new StringBuilder();
		formatter = new DecimalFormat("� #,##0.##");
	}
	
	public double calcolaImposta(double redditoLordo, Fasce fasce) {
		this.fasce=fasce;
		logger.setLength(0);
		double redditoImponibile = Math.max(0, redditoLordo - fasce.getNoTaxArea());
		
		logger.append("imponibile lordo = " + formatter.format(redditoLordo) +
						", no-tax area = " + formatter.format(fasce.getNoTaxArea()) + 
						", imponibile netto = " + formatter.format(redditoImponibile) +  System.lineSeparator()
		);
		
		if (redditoImponibile == 0) {
			logger.append("imponibile netto = 0, nessuna imposta da calcolare" + System.lineSeparator());
			return 0;
		}
		
		int fasciaMax = determinaIndiceFasciaMax(redditoImponibile);
		
		double imponibileCorrente = redditoImponibile;
		double imposta = 0;
		for(int i=fasciaMax; i>=0; i--){
			Fascia fasciaCorrente = fasce.getFasce().get(i);
			logger.append(fasciaCorrente + System.lineSeparator() +
					      "imponibile corrente = " + formatter.format(imponibileCorrente));
			double impostaDellaFascia = (imponibileCorrente-fasciaCorrente.getMin())*fasciaCorrente.getAliquota(); 
			imposta += impostaDellaFascia;
			imponibileCorrente = fasciaCorrente.getMin();
			logger.append(", imposta = " + formatter.format(impostaDellaFascia) + 
			              ", imponibile restante = " + formatter.format(imponibileCorrente) + 
			              System.lineSeparator());
		}
		return imposta;
	}

	private int determinaIndiceFasciaMax(double imponibile){
		int i=0;
		while(i < fasce.getFasce().size() && 
				fasce.getFasce().get(i).getMin() < imponibile) i++;
		return i-1;
	}

	@Override
	public String getLog() {
		return logger.toString();
	}

}
