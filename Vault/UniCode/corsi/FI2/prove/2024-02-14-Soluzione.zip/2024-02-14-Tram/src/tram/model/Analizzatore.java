package tram.model;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Optional;
import java.util.Set;

public class Analizzatore {
	
	private Set<Linea> linee;

	public Analizzatore(Set<Linea> linee) {
		if (linee==null) throw new IllegalArgumentException("Insieme linee nullo");
		if (linee.size()<=0) throw new IllegalArgumentException("Insieme linee vuoto");
		this.linee = linee;
	}

	public Set<Linea> getLinee() {
		return linee;
	}
	
	public Optional<Linea> getLinea(String nome) {
		return linee.stream().filter(linea -> linea.getNome().equals(nome)).findFirst();
	}
	
	public LocalTime prossimoPassaggio(String nomeLinea, String nomeFermata, Direzione dir, LocalTime orario) {
		if (nomeLinea==null || nomeLinea.isBlank()) throw new IllegalArgumentException("nome linea nullo o vuoto");
		Linea linea = this.getLinea(nomeLinea).orElseThrow( ()-> new IllegalArgumentException("Linea inesistente"));
		if (nomeFermata==null || nomeFermata.isBlank()) throw new IllegalArgumentException("nome fermata nullo o vuoto");
		if (dir==null) throw new IllegalArgumentException("direzione nulla");
		if (orario==null) throw new IllegalArgumentException("orario nullo");
		
		var orarioPrimaCorsaAllaNostraFermata = linea.getOrarioPrimaCorsaAllaFermata(nomeFermata, dir);
		var orarioUltimaCorsaAllaNostraFermata = linea.getOrarioUltimaCorsaAllaFermata(nomeFermata, dir);
		if (orario.isBefore(orarioPrimaCorsaAllaNostraFermata) || orario.isAfter(orarioUltimaCorsaAllaNostraFermata)) return orarioPrimaCorsaAllaNostraFermata;
		
		var differenzaOrariaAllaFermataRichiestaInMinuti = Duration.between(orarioPrimaCorsaAllaNostraFermata, orario).toMinutes();
		var numeroCorseGiaSvolte = differenzaOrariaAllaFermataRichiestaInMinuti / linea.getFrequenza().valore();
		var orarioCorsaPrecedenteAllaFermataRichiesta = orarioPrimaCorsaAllaNostraFermata.plusMinutes(numeroCorseGiaSvolte * linea.getFrequenza().valore());
				System.out.print("orario richiesto " + orario + ", ");
		if(orarioCorsaPrecedenteAllaFermataRichiesta.equals(orario)) {
				System.out.println("passa una corsa proprio in questo momento");
			return orario;
		}
		else {
				System.out.print("corsa precedente passata alle " + orarioCorsaPrecedenteAllaFermataRichiesta + ", ");
			var orarioProssimaCorsaAllaFermataRichiesta = orarioCorsaPrecedenteAllaFermataRichiesta.plusMinutes(linea.getFrequenza().valore());
				System.out.println("prossima corsa prevista alle " + orarioProssimaCorsaAllaFermataRichiesta);
			return orarioProssimaCorsaAllaFermataRichiesta;				
		}
	}	
}
