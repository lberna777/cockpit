package tram.persistence;

import java.io.IOException;
import java.io.Reader;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import tram.model.Fermata;
import tram.model.Formatters;
import tram.model.Frequenza;
import tram.model.Linea;

import java.io.BufferedReader;


public class MyLinesReader implements LinesReader {
	
	String nome;
	Frequenza freq;
	LocalTime inizioServizio, fineServizio;
	List<Fermata> fermate;
	
	@Override
	public Set<Linea> leggiLinee(Reader reader) throws IOException, BadFileFormatException {
		if (reader==null) throw new IllegalArgumentException("Input reader null in leggiLinee");
		Linea linea;
		var linee = new HashSet<Linea>(); 
		var bReader = new BufferedReader(reader);
		while ((linea = leggiLinea(bReader)) != null) {
			linee.add(linea);
		}
		return linee;
	}

	private Linea leggiLinea(BufferedReader bufferedReader) throws IOException, BadFileFormatException {
		String riga1, riga2;
		while((riga1=bufferedReader.readLine())!=null && riga1.isBlank());
		if(riga1==null) return null;
		riga2=bufferedReader.readLine();
		if (riga2==null || riga2.isBlank()) throw new BadFileFormatException("Riga vuota in specifica linea: " + riga2);
		//
		elaboraRiga1(riga1); // parsing e inizializzazione di nome, frequenza e orari
		elaboraRiga2(riga2); // parsing e inizializzazione della lista delle fermate		
		//
		return new Linea(nome, freq, inizioServizio, fineServizio, fermate);
	}
	
	private void elaboraRiga1(String riga1) throws BadFileFormatException {
		// parsing e inizializzazione di nome, frequenza e orari
		String[] itemsRiga1 = riga1.split(",");
		if (itemsRiga1.length!=3) throw new BadFileFormatException("Formato riga errato: " + riga1);
		nome = itemsRiga1[0].trim(); 
		if (!nome.startsWith("Linea ")) throw new BadFileFormatException("Nome linea errato: " + riga1);
		String sFreq = itemsRiga1[1].trim(); 
		if (!sFreq.startsWith("frequenza ") || !sFreq.endsWith(" minuti")) throw new BadFileFormatException("Frequenza errata: " + riga1);
		String[] subItems = sFreq.split("\\s+");
		if (subItems.length!=3) throw new BadFileFormatException("Formato frequenza errato: " + sFreq);
		try {
			freq = new Frequenza(Integer.parseInt(subItems[1]));
		} catch(NumberFormatException e) {
			throw new BadFileFormatException("Valore frequenza errato: " + sFreq);
		}
		String sOrari = itemsRiga1[2].trim();
		subItems = sOrari.split("-");
		try {
			inizioServizio = LocalTime.parse(subItems[0].trim(), Formatters.timeFormatter);
			fineServizio   = LocalTime.parse(subItems[1].trim(), Formatters.timeFormatter);
		} catch(DateTimeParseException e) {
			throw new BadFileFormatException("Uno o entrambi gli orari sono in formato errato: '" + subItems[0].trim() + "', '" + subItems[1].trim() + "'");
		}
}
	
	private void elaboraRiga2(String riga2) throws BadFileFormatException {
		// parsing e inizializzazione della lista delle fermate
		String[] itemsRiga2 = riga2.split(",");
		fermate = new ArrayList<>();
		for (String s : itemsRiga2) {
			String[] subItems = s.split("[\\(\\)]");
			String nomeFermata = subItems[0].trim();
			String sMinutiFermata = subItems[1].trim();
			try {
				int m  = Integer.parseInt(sMinutiFermata);
				fermate.add(new Fermata(nomeFermata,m));
			} catch(NumberFormatException e) {
				throw new BadFileFormatException("Valore minuti errato: " + s);
			}
		}
	}

}
