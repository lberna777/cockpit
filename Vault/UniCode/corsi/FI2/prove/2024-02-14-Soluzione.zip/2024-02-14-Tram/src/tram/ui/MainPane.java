package tram.ui;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import tram.controller.Controller;
import tram.model.Fermata;
import tram.model.Formatters;
import tram.model.Linea;
import tram.model.Direzione;



public class MainPane extends BorderPane {
	
	private Controller controller;
	
	private TextArea outputArea;
	private TextField txtOrarioDesiderato;
	private RadioButton avanti, indietro;
	private Button cerca;
	private ComboBox<Linea> comboLinee;
	private ComboBox<Fermata> comboFermate;
	private ToggleGroup tg;
	private Direzione direzione;

	public MainPane(Controller controller) {
		this.controller=controller;
		//
		HBox topBox = new HBox();
		topBox.setPrefWidth(500);
			//
			topBox.setPadding(new Insets(10, 10, 10, 10));
			comboLinee = new ComboBox<>(FXCollections.observableArrayList(controller.getLinee()));
			comboLinee.setTooltip(new Tooltip("Scegliere la linea"));
			comboLinee.setPrefWidth(130);
			comboFermate = new ComboBox<>();
			comboFermate.setPrefWidth(150);
			comboFermate.setTooltip(new Tooltip("Scegliere la fermata desiderata"));
			comboLinee.setOnAction(ev -> popolaFermate(comboLinee.getValue()));
			topBox.getChildren().addAll(new Label("Linee  "), comboLinee, new Label("  Fermate  "), comboFermate);
			//
			avanti = new RadioButton("Andata");
			indietro = new RadioButton("Ritorno");
			topBox.getChildren().addAll(new Label("   "), avanti, new Label("  "), indietro);
			tg = new ToggleGroup();
			avanti.setToggleGroup(tg);
			indietro.setToggleGroup(tg);
			avanti.setOnAction(ev -> setDirection(Direzione.ANDATA));
			indietro.setOnAction(ev -> setDirection(Direzione.RITORNO));
			avanti.setSelected(true); 
			direzione = Direzione.ANDATA;
		this.setTop(topBox);
		HBox centerBox = new HBox();
			centerBox.setPrefWidth(550);
			centerBox.setPadding(new Insets(10, 10, 10, 10));
			txtOrarioDesiderato = new TextField();
			txtOrarioDesiderato.setPrefWidth(50);
			txtOrarioDesiderato.setTooltip(new Tooltip("Inserire l'orario nella forma italiana HH:MM"));
			txtOrarioDesiderato.setText("10:30");
			cerca = new Button("Prossima corsa");
			cerca.setOnAction(ev -> cerca());
			centerBox.getChildren().addAll(new Label("Orario desiderato  "), txtOrarioDesiderato, new Label("      "), cerca);
		this.setCenter(centerBox);	
		HBox bottomBox = new HBox();	
			outputArea = new TextArea();
			outputArea.setPrefSize(550,150);
			outputArea.setFont(Font.font("Courier New", FontWeight.NORMAL, 14));
			outputArea.setEditable(false);
			bottomBox.getChildren().addAll(outputArea);
		this.setBottom(bottomBox);
	}

	private void popolaFermate(Linea value) {
		var linea = comboLinee.getValue();
		try {
			comboFermate.setItems(FXCollections.observableArrayList(controller.fermateLinea(linea)));
		}
		catch(IllegalArgumentException e) {
			Controller.alert("Errore nella selezione della linea", "Linea inesistente",
					"Dettagli:\n" + e.getMessage());
		}
	}

	private void cerca() {
		var linea = comboLinee.getValue();
		if (linea==null) { 
			Controller.alert("Linea non selezionata", "Occorre prima selezionare la linea", "Selezionare la linea desiderata dalla combo in alto a sinistra\n");
			return;
		}
		var fermata = comboFermate.getValue();
		if (fermata==null) { 
			Controller.alert("Fermata non selezionata", "Occorre selezionare la fermata", "Selezionare la fermata desiderata dalla combo in alto al centro\n");
			return;
		}
		LocalTime orarioDesiderato = LocalTime.of(0, 0); // fake default
		try {
			orarioDesiderato = LocalTime.parse(txtOrarioDesiderato.getText(), Formatters.timeFormatter);
		}
		catch(DateTimeParseException e) {
			Controller.alert("Errore nella lettura dell'orario", "Orario non segue il formato HH:MM", "Dettagli:\n" + e.getMessage());
			return;
		}
		var prossimaCorsa = controller.prossimaCorsa(linea.getNome(), fermata.nome(), this.direzione, orarioDesiderato);
		outputArea.setText("orario richiesto " + Formatters.timeFormatter.format(orarioDesiderato) + System.lineSeparator());
		if(prossimaCorsa.equals(orarioDesiderato)) {
			outputArea.appendText("passa una corsa proprio in questo momento" + System.lineSeparator());
		}
		else {
			outputArea.appendText("prossima corsa prevista alle " + Formatters.timeFormatter.format(prossimaCorsa) + System.lineSeparator());
		}
	}

	private void setDirection(Direzione dir) {
		this.direzione = dir;
	}
	
}
