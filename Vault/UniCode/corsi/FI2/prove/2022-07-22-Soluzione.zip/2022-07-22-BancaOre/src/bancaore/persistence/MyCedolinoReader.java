package bancaore.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.Optional;

import bancaore.model.Cedolino;
import bancaore.model.SettimanaLavorativa;
import bancaore.model.VoceCedolino;
import bancaore.model.Causale;


public class MyCedolinoReader implements CedolinoReader {

	/*  Dipendente:	Rossi Mario
		Mese di:	GENNAIO 2022
		Ore previste: 	 	6H/9H/6H/9H/6H/0H/0H
		Saldo precedente:	12H07M
		
		03 Lunedì	08:30	14:30
		04 Martedì	08:30	17:30
		05 Mercoledì	08:30	14:30	Riposo Compensativo
		07 Venerdì	08:30	14:30	Riposo Compensativo
		10 Lunedì	07:30	13:42	
		10 Lunedì	13:42	13:53	Pausa Pranzo
		10 Lunedì	13:53	15:45	
		11 Martedì	07:30	13:28		
		...
	 **/

	@Override
	public Cedolino leggiCedolino(Reader rdr) throws IOException {
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		
		// Lettura e validazione intestazione
		String nomeDipendente  		  = analizzaIntestazioneRiga1(reader.readLine());
		LocalDate dataCedolino 		  = analizzaIntestazioneRiga2(reader.readLine());
		SettimanaLavorativa settimana = analizzaIntestazioneRiga3(reader.readLine());
		Duration saldoPrecedente 	  = analizzaIntestazioneRiga4(reader.readLine());
		
		// creazione del cedolino inizialmente vuoto
		Cedolino cedolino = new Cedolino(nomeDipendente,dataCedolino,settimana,saldoPrecedente);

		// Lettura ed elaborazione delle righe con le singole voci
		
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			String[] items = line.split("\t+");
			
			// ci devono essere sempre 3 o 4 parti
			if (items.length>4 || items.length<3) 
				throw new BadFileFormatException("La riga non contiene una voce correttamente formattata (numero elementi errato)\nRiga: " + line);
			String strGiornoConNome = items[0].trim().toLowerCase(); 
			String strOraEntrata = items[1].trim(); 
			String strOraUscita  = items[2].trim();
			String strCausale 	 = items.length==4 ? items[3].trim().toUpperCase().replace(' ', '_') : "";

			// validazione e conversione
			String strGiornoENome[] = strGiornoConNome.split("\s+");
			if (strGiornoENome.length!=2) 
				throw new BadFileFormatException("La riga non contiene una voce correttamente formattata (Numerogiorno NomeGiorno)\nRiga" + line);
			try {
				LocalDate data = dataCedolino.withDayOfMonth(Integer.parseInt(strGiornoENome[0])); // recuperiamo mese e anno dalla data del cedolino 
				// verifichiamo che il giorno della settimana sia corretto
				String nomeGiornoAtteso = CedolinoReader.getDayOfWeekName(data.getDayOfWeek(), Locale.ITALY);
				if(!nomeGiornoAtteso.equalsIgnoreCase(strGiornoENome[1].trim())) throw new BadFileFormatException("Il giorno della settimana non corrisponde alla data\nRiga" + line);
				// elaborazione orari
				LocalTime oraEntrata    = LocalTime.parse(strOraEntrata, timeFormatter);
				LocalTime oraUscita     = LocalTime.parse(strOraUscita,  timeFormatter);
				// elaborazione causale
				Optional<Causale> optCausale = 
						!strCausale.equals("") ? Optional.of(Causale.valueOf(strCausale)) : Optional.empty();
				cedolino.aggiungi(new VoceCedolino(data, oraEntrata, oraUscita, optCausale));
			}
			catch(DateTimeException | IllegalArgumentException e) {
				throw new BadFileFormatException("La riga contiene una data o un orario non correttamente formattati\nRiga" + line + e.getMessage());
			}
		}
		return cedolino;
	}

	private Duration analizzaIntestazioneRiga4(String line) throws BadFileFormatException {
		// Elaborazione quarta riga di intestazione
		// Saldo precedente:	12H07M
		String[] items = line.split(":");
		// validazione input quarta riga di intestazione
		if (items.length!=2)
			throw new BadFileFormatException("Numero elementi errato nella quarta riga di intestazione: " + line);
		if (!items[0].toLowerCase().equals("saldo precedente"))
			throw new BadFileFormatException("La riga di intestazione non inizia con 'Saldo precedente:'\nRiga: " + items[0]);
		String strSaldoPrec = items[1].trim().toUpperCase();
		return Duration.parse("PT"+strSaldoPrec);
	}

	private SettimanaLavorativa analizzaIntestazioneRiga3(String line) throws BadFileFormatException {
		// Elaborazione terza riga di intestazione
		// Ore previste: 9H/6H/9H/6H/9H/0H/0H
		String[] items = line.split(":");
		if (items.length!=2)
			throw new BadFileFormatException("Numero elementi errato nella terza riga di intestazione: " + line);
		if (!items[0].toLowerCase().equals("ore previste"))
			throw new BadFileFormatException("La riga di intestazione non inizia con 'Ore previste:'\nRiga: " + items[0]);
		String[] strSettLav = items[1].trim().toUpperCase().split("/+");
		
		try {
			return new SettimanaLavorativa(strSettLav);
		}
		catch(IllegalArgumentException | DateTimeParseException e) {
			throw new BadFileFormatException("La riga di intestazione non contiene una settimana lavorativa correttamente formattata\nRiga: " + items[1].trim());
		}
	}

	private LocalDate analizzaIntestazioneRiga2(String line) throws BadFileFormatException {
		// Elaborazione seconda riga di intestazione
		// Mese di:	GENNAIO 2022
		DateTimeFormatter dateFormatterLong = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(Locale.ITALY);
		String[] items = line.split(":");
		if (items.length!=2)
			throw new BadFileFormatException("Numero elementi errato nella seconda riga di intestazione: " + line);
		if (!items[0].toLowerCase().equals("mese di"))
			throw new BadFileFormatException("La riga di intestazione non inizia con 'Mese di:'\nRiga: " + line);
		String strMeseAnno = items[1].trim().toLowerCase();
		// NB per verificare correttezza costruiamo una data al primo giorno di quel mese/anno
		try {
			return LocalDate.parse("1 " + strMeseAnno, dateFormatterLong);
		}
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("La riga di intestazione contiene mese e/o anno errati: " + strMeseAnno);
		}
	}

	private String analizzaIntestazioneRiga1(String line) throws BadFileFormatException {
		// Elaborazione prima riga di intestazione
		// Dipendente:	Rossi Mario
		String[] items = line.split(":");
		if (items.length!=2)
			throw new BadFileFormatException("Numero elementi errato nella prima riga di intestazione: " + line);
		if (!items[0].toLowerCase().equals("dipendente"))
			throw new BadFileFormatException("La riga di intestazione non inizia con 'Dipendente:'\nRiga: " + line);
		return items[1].trim();
	}
	
}