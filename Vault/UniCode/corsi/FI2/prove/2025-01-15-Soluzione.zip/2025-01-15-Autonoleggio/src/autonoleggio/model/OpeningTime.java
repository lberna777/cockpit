package autonoleggio.model;

import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

public class OpeningTime {
	
	private List<Slot> slots;
	public static OpeningTime CHIUSO = new OpeningTime();
	
	private OpeningTime() {
		slots = List.of();
	}
	
	public OpeningTime(Slot slotUnico) {
		Objects.requireNonNull(slotUnico, "Slot non può essere nullo");
		slots = List.of(slotUnico);
	}
	
	public OpeningTime(Slot mattino, Slot pomeriggio) {
		Objects.requireNonNull(mattino, "Slot mattino non può essere nullo");
		Objects.requireNonNull(pomeriggio, "Slot pomeriggio non può essere nullo");
		if(!mattino.to().isBefore(pomeriggio.from())) throw new IllegalArgumentException("Slot pomeridiano deve seguire slot mattutino");
		slots = List.of(mattino, pomeriggio);
	}
	
	public boolean isOpenAt(LocalTime time) {
		Objects.requireNonNull(time, "L'orario da verificare non può essere nullo");
		return switch(slots.size()) {
		case 0 -> false;
		case 1 -> slots.get(0).contains(time);
		case 2 -> slots.get(0).contains(time) || slots.get(1).contains(time);
		default -> throw new IllegalArgumentException("Unexpected value: " + slots.size());
		};
	}
	
	public String toString() {
		return switch(slots.size()) {
		case 0 -> "chiuso";
		case 1 -> slots.get(0).toString();
		case 2 -> slots.get(0).toString() + "/" + slots.get(1).toString();
		default -> throw new IllegalArgumentException("Unexpected value: " + slots.size());
		};
	}
	

}
