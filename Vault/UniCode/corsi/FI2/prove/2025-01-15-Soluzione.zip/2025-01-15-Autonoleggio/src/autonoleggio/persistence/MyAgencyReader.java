package autonoleggio.persistence;

import java.io.IOException;
import java.io.Reader;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import autonoleggio.model.Agency;
import autonoleggio.model.Formatters;
import autonoleggio.model.OpeningTime;
import autonoleggio.model.Slot;

import java.io.BufferedReader;


public class MyAgencyReader implements AgencyReader {
	
	String nome;
	OpeningTime freq;
	LocalTime inizioServizio, fineServizio;
	List<Agency> fermate;
	
	// BOLOGNA, Aeroporto Marconi, lun-ven 08:00-23:59, sab 08:00-23:59, dom 08:00-23:59
	
	@Override
	public Set<Agency> readAllAgencies(Reader reader) throws IOException, BadFileFormatException {
		Objects.requireNonNull(reader, "Input reader null in MyAgencyReader.readAllAgencies");
		var bufferedReader = new BufferedReader(reader);
		var agencies = new HashSet<Agency>(); 
		String riga;
		while((riga=bufferedReader.readLine())!=null) {
			String[] items = riga.split(",");
			if (items.length!=5) throw new BadFileFormatException("Riga mal formattata, numero elementi non è 5");
			var openingTimeMonFri = extractOpeningTime(items[2].trim(), "lun-ven");
			var openingTimeSat = extractOpeningTime(items[3].trim(), "sab");
			var openingTimeSun = extractOpeningTime(items[4].trim(), "dom");
			agencies.add(new Agency(items[0].trim().toUpperCase(), items[1].trim(), openingTimeMonFri, openingTimeSat, openingTimeSun));
		}
		return agencies;
	}

	private OpeningTime extractOpeningTime(String item, String prefix) throws BadFileFormatException {
		String[] elements = item.split("\\s+");
		if (!elements[0].trim().equals(prefix)) throw new BadFileFormatException("Orario di apertura illegale: " + item + " non inizia per " + prefix);
		String orarioApertura = elements[1].trim();
		if (orarioApertura.contains("/")) {
			String[] fasceOrarie = orarioApertura.split("/");
			Slot slotMattino = makeSlot(fasceOrarie[0].trim());
			Slot slotPomeriggio = makeSlot(fasceOrarie[1].trim());
			try {
				return new OpeningTime(slotMattino,slotPomeriggio);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Slot mattino / pomeriggio invertiti o con orari che si sovrappongono " + orarioApertura);
			}
		}
		else { // slot unico o "chiuso"
			if (orarioApertura.equalsIgnoreCase("CHIUSO")) return OpeningTime.CHIUSO;
			Slot slotUnico = makeSlot(orarioApertura.trim());
			try {
				return new OpeningTime(slotUnico);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Slot con orari invertiti o che si sovrappongono " + orarioApertura);
			}
		}
	}
	
	private Slot makeSlot(String fasciaOraria) throws BadFileFormatException {
		String[] orari = fasciaOraria.split("-");
		try {
			return new Slot(LocalTime.parse(orari[0].trim(), Formatters.timeFormatter), LocalTime.parse(orari[1].trim(), Formatters.timeFormatter));
		}
		catch(DateTimeParseException | IllegalArgumentException e) {
			throw new BadFileFormatException("Orario mal formattato in " + fasciaOraria);
		}
	}

}
