package autonoleggio.persistence;

import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import java.time.LocalTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.io.BufferedReader;

import autonoleggio.model.Agency;
import autonoleggio.model.CarType;
import autonoleggio.model.Formatters;
import autonoleggio.model.OpeningTime;
import autonoleggio.model.Rate;


public class MyRateReader implements RateReader {
	
	// IMPORTANTE: questo reader è incluso solo come utile esercizio, ma NON era richiesto durante l'esame.
	// Perciò, sebbene la main app aprisse il file rates (che quindi doveva essere presente), esso non veniva in realtà letto.
	// Lo start kit ne simulava la presenza con un fake, allo scopo di ridurre la difficoltà dell'esercizio. 
	
	String nome;
	OpeningTime freq;
	LocalTime inizioServizio, fineServizio;
	List<Agency> fermate;
	
	// A: daily 45€, weekend 87€, dropoff 100€
	
	public SortedMap<CarType,Rate> readAllRates(Reader reader) throws IOException, BadFileFormatException {
		Objects.requireNonNull(reader, "Input reader null in MyAgencyReader.readAllAgencies");
		var bufferedReader = new BufferedReader(reader);
		var mappa = new TreeMap<CarType,Rate>(); 
		String riga;
		while((riga=bufferedReader.readLine())!=null) {
			String[] items = riga.split(":");
			if (items.length!=2) throw new BadFileFormatException("Riga mal formattata, CarType non è seguito da ':'");
			CarType carType;
			try {
				carType = CarType.valueOf(items[0].trim().toUpperCase());
			}
			catch(NoSuchElementException e) {
				throw new BadFileFormatException("Riga mal formattata, CarType illegale " + items[0].trim());
			}
			String[] rates = items[1].split(",");
			if (rates.length!=3) throw new BadFileFormatException("Riga mal formattata, non ci sono le tre tariffe previste");
			var dailyRate = extractRate(rates[0].trim(), "daily");
			var weekendRate = extractRate(rates[1].trim(), "weekend");
			var dropoffRate = extractRate(rates[2].trim(), "dropoff");
			mappa.put(carType, new Rate(carType, dailyRate, weekendRate, dropoffRate));
		}
		return mappa;
	}

	private double extractRate(String item, String prefix) throws BadFileFormatException {
		String[] elements = item.split("=");
		if (!elements[0].trim().equals(prefix)) throw new BadFileFormatException("Tariffa illegale: " + item + " non inizia per " + prefix);
		try {
			var result = Formatters.euroFormatter.parse(elements[1].trim()).doubleValue();
			if (result < 0) throw new BadFileFormatException("Tariffa illegale: " + item + " ha valore negativo");
			return result;
		}
		catch(ParseException e) {
			throw new BadFileFormatException("Tariffa illegale: " + elements[1] + " non specifica un valore in euro");
		}
	}

}
