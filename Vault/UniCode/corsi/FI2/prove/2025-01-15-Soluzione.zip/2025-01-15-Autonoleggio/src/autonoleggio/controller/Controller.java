package autonoleggio.controller;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;

import autonoleggio.model.Rate;
import autonoleggio.model.Agency;
import autonoleggio.model.CarType;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class Controller {

	public static void alert(String title, String headerMessage, String contentMessage) {
		javafx.scene.control.Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(headerMessage);
		alert.setContentText(contentMessage);
		alert.showAndWait();
	}

	private Set<Agency> agencies;
	private SortedMap<CarType, Rate> rates;
	public final Set<DayOfWeek> WEEKEND_DAYS = Set.of(DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
		
	//--------------
	
	public Controller(Set<Agency> agencies, SortedMap<CarType, Rate> rates) {
		Objects.requireNonNull(agencies, "Insieme agenzie nullo nel construttore del Controller");
		Objects.requireNonNull(rates, "Elenco tariffe nullo nel construttore del Controller");
		this.agencies = agencies;
		this.rates = rates;
	}

	public Set<Agency> getAgencies() {
		return agencies;
	}

	public SortedMap<CarType, Rate> getRates() {
		return rates;
	}

	public List<String> getCities() {
		return agencies.stream().map(Agency::city).sorted().distinct().toList();
	}
	
	public List<Agency> getAgencies(String city) {
		return agencies.stream().filter( agency -> agency.city().equalsIgnoreCase(city)).sorted().toList();
	}

	private String siNo(boolean flag) {
		return flag ? "sì" : "no";
	}
	
	public Result calcolaTariffa(String city, Agency agency, LocalDateTime start, LocalDateTime end, CarType carType, boolean dropOff) {
		Objects.requireNonNull(city, "Nome città nullo in calcolaTariffa");
		Objects.requireNonNull(agency, "Agenzia nulla in calcolaTariffa");
		Objects.requireNonNull(start, "Data e ora iniziale nulla in calcolaTariffa");
		Objects.requireNonNull(end, "Data e ora finale nulla in calcolaTariffa");
		Objects.requireNonNull(carType, "Tipo auto nullo in calcolaTariffa");
		if (city.isBlank()) throw new IllegalArgumentException("Nome città vuoto in calcolaTariffa");
		if (end.isBefore(start)) throw new IllegalArgumentException("Fine noleggio antecedente all'inizio in calcolaTariffa");
		//----
		var rate = rates.get(carType);
		boolean isWeekend = WEEKEND_DAYS.contains(start.getDayOfWeek()) && WEEKEND_DAYS.contains(end.getDayOfWeek()) && Duration.between(start, end).toDays()<=3;
		int durataInGiorni = (int) Math.ceil(Duration.between(start, end).toMinutes()/24.0/60.0); // oppure: Duration.between(start, end).toDays()+1
		var tariffaBase = rate.dailyRate() * durataInGiorni;
		boolean weekendRateApplicable = isWeekend && rate.weekendRate()<=tariffaBase;
		var importoBase = weekendRateApplicable ? rate.weekendRate() : tariffaBase;
		importoBase += (dropOff ? rate.dropoffCharge() : 0);
		return new Result(importoBase, "Giorni: " + durataInGiorni + ", tariffa weekend: " + siNo(weekendRateApplicable) + ", dropOff: " + siNo(dropOff));
	}
	
}
