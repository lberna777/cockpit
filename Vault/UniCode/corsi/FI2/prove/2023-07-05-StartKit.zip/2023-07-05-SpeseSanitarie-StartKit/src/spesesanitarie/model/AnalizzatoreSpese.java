package spesesanitarie.model;

import java.util.Collections;
import java.util.List;


public class AnalizzatoreSpese {

	private List<DocumentoDiSpesa> listaSpese;

	public AnalizzatoreSpese(List<DocumentoDiSpesa> listaSpese) {
		if (listaSpese==null || listaSpese.isEmpty()) throw new IllegalArgumentException("la lista spese non può essere nulla né vuota");
		this.listaSpese = listaSpese;
	}

	public List<DocumentoDiSpesa> getListaSpese() {
		return listaSpese;
	}

	@Override
	public String toString() {
		return "AnalizzatoreSpese [listaSpese=" + listaSpese + "]";
	}
	
	public double somma(Tipologia t){
		// 
		// ***** DA IMPLEMENTARE ***** 
		//
		return 0; // FAKE; da implementare
	}
	
	public List<DocumentoDiSpesa> filtraPer(Tipologia t){
		// 
		// ***** DA IMPLEMENTARE ***** 
		//
		return Collections.emptyList(); // FAKE; da implementare
	}

}
