package spesesanitarie.model;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class DocumentoDiSpesa {
	private LocalDate data;
	private String emittente;
	private double importo;
	private List<VoceDiSpesa> items;
	
	public DocumentoDiSpesa(LocalDate data, String emittente, double importo, List<VoceDiSpesa> items) {
		verificaPrecondizioni(data, emittente, importo, items);
		verificaCongruenzaVoci(importo, items);
		this.data = data;
		this.emittente = emittente;
		this.importo = importo;
		this.items = items;
	}

	private void verificaPrecondizioni(LocalDate data, String emittente, double importo, List<VoceDiSpesa> items) {
		//
		// *** DA IMPLEMENTARE ***
		// Verifica che i riferimenti non siano nulli, che l'importo sia effettivamente un numero, e che la lista non sia vuota
		//
	}

	private void verificaCongruenzaVoci(double importo, List<VoceDiSpesa> items) {
		//
		// *** DA IMPLEMENTARE ***
		// Verifica che il totale delle voci di spesa coincida (a meno di 1 cent) col totale del documento di spesa
		//
	}

	public LocalDate getData() {
		return data;
	}

	public String getEmittente() {
		return emittente;
	}

	public double getImporto() {
		return importo;
	}

	public List<VoceDiSpesa> getVoci() {
		return items;
	}

	public boolean contieneVoce(Tipologia t) {
		return items.stream().anyMatch(voce -> voce.getTipologia()==t);
	}
	
	@Override
	public String toString() {
		//
		// *** DA IMPLEMENTARE ***
		// Deve emettere la stringa che sarà mostrata nella GUI nell'area di testo riassuntiva
		// E' richiesto che tale stringa sia adeguatamente formattata
		//
		return "stringa da implementare"; // FAKE, da implementare
	}
	
	
}
