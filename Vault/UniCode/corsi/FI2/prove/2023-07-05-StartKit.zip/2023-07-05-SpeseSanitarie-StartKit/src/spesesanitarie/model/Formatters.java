package spesesanitarie.model;

import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;

public class Formatters {
	public static final DateTimeFormatter itDateFormatter = // da implementare: questa è un'implementazione pro-forma 
			DateTimeFormatter.BASIC_ISO_DATE; 				// FAKE, da implementare
	public static final NumberFormat itPriceFormatter = 	// da implementare: questa è un'implementazione pro-forma
			NumberFormat.getCurrencyInstance();				// FAKE, da implementare
}
