package meteodent.persistence;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import meteodent.model.Previsione;
import meteodent.model.ProbPioggia;
import meteodent.model.Temperatura;

public class MyPrevisioniReader implements PrevisioniReader {
	
	private static final int    TOKEN_COUNT = 5;
	private static final String SEPARATOR = ",";
	private static final String DEGREE_SYMBOL = "°";
	private static final String PERCENT_SYMBOL = "%";

	@Override
	public Map<String, SortedSet<Previsione>> leggiPrevisioni(Reader reader) throws IOException, BadFileFormatException {
		HashMap<String, SortedSet<Previsione>> result = new HashMap<String, SortedSet<Previsione>>();
		if (reader==null) throw new IllegalArgumentException("Input reader should be open, but is null");
		BufferedReader bufferedReader = new BufferedReader(reader);
		Previsione previsione;
		while ((previsione = leggiSingolaPrevisione(bufferedReader)) != null) {
			SortedSet<Previsione> previsioni = result.get(previsione.getLocalita());
			if (previsioni == null) {
				previsioni = new TreeSet<Previsione>(Comparator.comparing(Previsione::getDataOra));
				result.put(previsione.getLocalita(), previsioni);
			}
			previsioni.add(previsione);
		}
		return result;
	}

	private Previsione leggiSingolaPrevisione(BufferedReader reader) throws IOException, BadFileFormatException {
		String line = reader.readLine();
		if (line == null || line.trim().isEmpty()) return null;
		
		String[] items = line.split(SEPARATOR); 
		if (items.length != TOKEN_COUNT)
			throw new BadFileFormatException("Errato numero di token nella riga: devono essere " + TOKEN_COUNT + ", invece ce ne sono " + items.length);
		
		String localita = items[0].trim();
		if (localita.isEmpty()) throw new BadFileFormatException("Località mancante");		
		
		String dataAsString = items[1].trim();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).withLocale(Locale.ITALY);
		LocalDate data;
		try {
			data = dateFormatter.parse(dataAsString, LocalDate::from);
		} 
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("Formato data errato: " + e);
		}
		
		String oraAsString = items[2].trim();
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
		LocalTime ora;
		try {
			ora = timeFormatter.parse(oraAsString, LocalTime::from);
		} 
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("Formato data/ora errato: " + e);
		}

		String temperaturaToken = items[3].trim();
		if (!temperaturaToken.endsWith(DEGREE_SYMBOL))
			throw new BadFileFormatException("Formato temperatura errato: manca il simbolo " + DEGREE_SYMBOL + " alla fine");
		int temperatura;
		try {
			temperatura = Integer.parseInt(temperaturaToken.substring(0,temperaturaToken.length()-1));
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Formato temperatura errato: non è un valore intero");
		}
		
		String probabilitaPioggiaToken = items[4].trim();
		if (!probabilitaPioggiaToken.endsWith(PERCENT_SYMBOL))
			throw new BadFileFormatException("Formato probabilità pioggia errato: manca il simbolo " + PERCENT_SYMBOL);
		int probabilitaPioggia;
		try {
			probabilitaPioggia = Integer.parseInt(probabilitaPioggiaToken.substring(0,probabilitaPioggiaToken.length()-1));
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Formato probabilità pioggia errato: non è una valida percentuale");
		}
		if (probabilitaPioggia<0 || probabilitaPioggia>100)
			throw new BadFileFormatException("Valore probabilità pioggia errato: non è una valida percentuale");

		return new Previsione(localita, data, ora, Temperatura.of(temperatura), ProbPioggia.of(probabilitaPioggia));
	}

}
