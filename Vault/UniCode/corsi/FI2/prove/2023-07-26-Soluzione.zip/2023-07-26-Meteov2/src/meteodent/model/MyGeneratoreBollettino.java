package meteodent.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

public class MyGeneratoreBollettino implements GeneratoreBollettino {

	@Override
	public Bollettino generaBollettino(List<Previsione> previsioni, TipoBollettino tipoBollettino) {
		if (previsioni == null || previsioni.size() == 0)
			throw new IllegalArgumentException("Lista previsioni vuota o nulla");
		if (previsioni.stream().map(Previsione::getLocalita).distinct().count()>1)
			throw new IllegalArgumentException("Le previsioni non si riferiscono tutte alla stessa località");
		if (previsioni.stream().map(Previsione::getDataOra).map(LocalDateTime::toLocalDate).distinct().count()>1)
			throw new IllegalArgumentException("Le previsioni non si riferiscono tutte alla stessa data");
		if (previsioni.stream().map(Previsione::getDataOra).map(LocalDateTime::toLocalTime).distinct().count()<previsioni.size())
			throw new IllegalArgumentException("Non possono esserci più previsioni per la stessa ora");
		//
		// se la prima previsione non è alle ore 0:00, propaghiamo all'indietro i dati della prima previsione,
		// aggiungendo nuova previsione in testa
		Previsione prima = previsioni.get(0);
		if(prima.getDataOra().toLocalTime().isAfter(LocalTime.of(0,0)))
			previsioni.add(0,new Previsione(prima.getLocalita(), 
					prima.getDataOra().toLocalDate(), LocalTime.of(0,0),
					prima.getTemperatura(), prima.getProbabilitaPioggia()));
		// se l'ultima previsione non è alle 24, propaghiamo identici dati fino alle 24 aggiungendo nuova previsione in fondo
		Previsione ultima = previsioni.get(previsioni.size()-1);
		if(ultima.getDataOra().toLocalTime().isBefore(LocalTime.of(23,59)))
			previsioni.add(new Previsione(ultima.getLocalita(), 
											ultima.getDataOra().toLocalDate(), LocalTime.of(23,59),
											ultima.getTemperatura(), ultima.getProbabilitaPioggia()));
		//
		double accProbPioggia = 0;
		double accTemp = 0;
		for (int i = 1; i < previsioni.size(); i++) {
			Previsione prec = previsioni.get(i-1);
			Previsione curr = previsioni.get(i);
			Duration d = Duration.between(prec.getDataOra().toLocalTime(), curr.getDataOra().toLocalTime());
			var probPioggiaMedia = (prec.getProbabilitaPioggia().getValue() + curr.getProbabilitaPioggia().getValue())/2.0;
			var tempMedia = (prec.getTemperatura().getValue() + curr.getTemperatura().getValue())/2.0;
			accProbPioggia += probPioggiaMedia * d.toMinutes() / 60.0;	// NON toHours perché troncherebbe
			accTemp += tempMedia * d.toMinutes() / 60.0; 				// NON toHours perché troncherebbe
		}
		Duration dTot = Duration.between(previsioni.get(0).getDataOra().toLocalTime(), 
										 previsioni.get(previsioni.size()-1).getDataOra().toLocalTime());
		int probPioggia = (int) Math.round( (accProbPioggia / (dTot.toMinutes() / 60.0)) ); // NON toHours perché troncherebbe
		int temperatura = (int) Math.round( (accTemp / (dTot.toMinutes() / 60.0)) );		// NON toHours perché troncherebbe
		
		String testo = 
				(tipoBollettino==TipoBollettino.DETTAGLIATO ?
						previsioni.stream().map(Previsione::toString).collect(Collectors.joining("\n","","\n")) : "")
				+
				SintesiGiornata.getTestoAnnuncio(probPioggia)
				+
				"\ne temperatura media di " + temperatura + "°C";
				;

		return new Bollettino(previsioni.get(0).getDataOra().toLocalDate(), 
							  previsioni.get(0).getLocalita(), 
							  probPioggia, temperatura, testo);
	}
	
}
