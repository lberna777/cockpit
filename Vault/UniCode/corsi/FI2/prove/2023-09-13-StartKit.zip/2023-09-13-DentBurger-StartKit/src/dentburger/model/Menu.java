package dentburger.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Collections;
import java.util.HashMap;

/** Rappresenta il menù del ristorante, strutturato come mappa di mappe che gestiscono liste di prodotti. 
 *  Più precisamente, il menù è organizzato come mappa indicizzata per Categoria: a ogni categoria è 
 *  associata un'ulteriore mappa, indicizzata per genere (stringa), che associa a ogni genere la lista 
 *  dei Prodotto di quella categoria e genere (vedere figura nel testo)
 */
public class Menu {

	private Map<Categoria, Map<String,List<Prodotto>> > menu;
	
	/** Il costruttore istanzia la mappa vuota: è compito del metodo add popolarla via via che vengono 
	 *  aggiunti prodotti, curando la costruzione delle mappe di secondo livello e delle liste quando 
	 *  necessario. 
	 */
	public Menu() {
		menu = new HashMap<>();
	}
	
	public void add(Prodotto p) {
		// *** DA FARE ***
		// aggiunge un nuovo prodotto nell’opportuna lista dell’opportuna mappa
	}
	
	private Map<String,List<Prodotto>> getProdottiPerCategoria(Categoria c){
		return Map.copyOf(menu.getOrDefault(c, Collections.emptyMap()));
	}
	
	public Set<String> getGeneriPerCategoria(Categoria c){
		// *** DA FARE ***
		// Restituisce l’insieme (eventualmente vuoto) dei generi associati a una data categoria
		return Collections.emptySet(); // FAKE
	}
	
	public List<Prodotto> getProdottiPerCategoriaEGenere(Categoria c, String denominazione){
		// *** DA FARE ***
		// Restituisce  la lista (eventualmente vuota) dei prodotti di una data categoria e genere.
		// NB: può essere utile sfruttare il metodo privato getProdottiPerCategoria, che restituisce 
		//     la sottomappa relativa alla categoria ricevuta come argomento.
		return Collections.emptyList(); // FAKE
	}
	
	@Override
	public String toString() { 
		return menu.keySet().stream()
							.map(this::getProdottiPerCategoria)
							.map(Map::entrySet)
							.flatMap(Set::stream)
							.map(entry -> entry.getKey() + " " + entry.getValue().toString())
							.collect(Collectors.joining(System.lineSeparator()));
	}
	
}
