package gringottbank.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import gringottbank.model.Ceiling;
import gringottbank.model.Coin;
import gringottbank.model.CoinAmount;

	 /*
		Harry		20 galeoni
		Hermione	19 galeoni, 20 zellini
		Enrico		200 galeoni
		Ambra		100 galeoni, 20 zellini
		Roberta		100 galeoni, 28 zellini
		Ron			12 galeoni, 10 falci, 6 zellini
	 */

public class MyCeilingsReader implements CeilingsReader {

	@Override
	public List<Ceiling> readCeilings(Reader rdr) throws IOException, BadFileFormatException {
		// DA IMPLEMENTARE
		return null; // FAKE
	}
	
	private CoinAmount extractAmount(String importoAsString) throws BadFileFormatException {		
		// METODO DI UTILITA' PER CONVERTIRE UN IMPORTO GRINGOTT (es. "12 galeoni, 20 zellini") IN UN COIN AMOUNT
		// DA IMPLEMENTARE
		return null; // FAKE
	}

	private int parsePositive(String s) throws BadFileFormatException {
		// METODO DI UTILITA' IN REGALO :)
		int importo;
		try {
			importo = Integer.parseInt(s);
		}
		catch(NumberFormatException e) {
			throw new BadFileFormatException("Formato sotto-importo illegale: numero errato\t" + s);
		}
		if (importo<0) throw new BadFileFormatException("Formato sotto-importo illegale: numero negativo\t" + s);
		return importo;
	}
	
}