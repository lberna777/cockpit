package tram.persistence;

import java.io.IOException;
import java.io.Reader;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import tram.model.Fermata;
import tram.model.Formatters;
import tram.model.Frequenza;
import tram.model.Linea;

import java.io.BufferedReader;


public class MyLinesReader implements LinesReader {
	
	String nome;
	Frequenza freq;
	LocalTime inizioServizio, fineServizio;
	List<Fermata> fermate;
	
	@Override
	public Set<Linea> leggiLinee(Reader reader) throws IOException, BadFileFormatException {
		if (reader==null) throw new IllegalArgumentException("Input reader null in leggiLinee");
		Linea linea;
		var linee = new HashSet<Linea>(); 
		var bReader = new BufferedReader(reader);
		while ((linea = leggiLinea(bReader)) != null) {
			linee.add(linea);
		}
		return linee;
	}

	private Linea leggiLinea(BufferedReader bufferedReader) throws IOException, BadFileFormatException {
		String riga1, riga2;
		while((riga1=bufferedReader.readLine())!=null && riga1.isBlank());
		if(riga1==null) return null;
		riga2=bufferedReader.readLine();
		if (riga2==null || riga2.isBlank()) throw new BadFileFormatException("Riga vuota in specifica linea: " + riga2);
		//
		elaboraRiga1(riga1); // parsing e inizializzazione di nome, frequenza e orari
		elaboraRiga2(riga2); // parsing e inizializzazione della lista delle fermate		
		//
		return new Linea(nome, freq, inizioServizio, fineServizio, fermate);
	}
	
	private void elaboraRiga1(String riga1) throws BadFileFormatException {
		// parsing e inizializzazione di nome, frequenza e orari
		//
		// ************ DA FARE ************ 
		// La prima riga specifica il nome della linea, la frequenza e gli orari di servizio al capolinea iniziale: 
		// il nome è preceduto dalla parola “Linea” seguita da spazi, la frequenza è un valore intero non negativo 
		// e non superiore a 60, ricompreso fra le due parole “frequenza” e “minuti”, separate da spazi, mentre gli 
		// orari della prima e dell’ultima corsa al capolinea iniziale sono espressi nel formato italiano short HH:MM,
		// separati fra loro da un trattino (senza spazi intermedi)
		// ********************************* 
}
	
	private void elaboraRiga2(String riga2) throws BadFileFormatException {
		// parsing e inizializzazione della lista delle fermate
		//
		// ************ DA FARE ************ 
		// La seconda riga elenca invece le varie fermate, indicando per ciascuna:
		// - il nome, eventualmente seguito da spazi per comodità di lettura
		// - la distanza temporale in minuti dal capolinea iniziale (un intero non negativo), indicata fra parentesi tonde
		// ********************************* 
	}

}
