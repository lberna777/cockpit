package tram.model;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Optional;
import java.util.Set;

public class Analizzatore {
	
	private Set<Linea> linee;

	public Analizzatore(Set<Linea> linee) {
		if (linee==null) throw new IllegalArgumentException("Insieme linee nullo");
		if (linee.size()<=0) throw new IllegalArgumentException("Insieme linee vuoto");
		this.linee = linee;
	}

	public Set<Linea> getLinee() {
		return linee;
	}
	
	public Optional<Linea> getLinea(String nome) {
		return linee.stream().filter(linea -> linea.getNome().equals(nome)).findFirst();
	}
	
	public LocalTime prossimoPassaggio(String nomeLinea, String nomeFermata, Direzione dir, LocalTime orario) {
		//
		// ************ DA FARE ************ 
		//
		// Il metodo deve preventivamente verificare, lanciando IllegalArgumentException in caso di violazione:
		// - che gli argomenti non siano nulli, o, nel caso di stringhe, anche blank
		// - che una linea di nome uguale a quello specificato esista realmente
		//   NB: non occorre analoga verifica per la fermata perché tale controllo è già svolto nei metodi getOrarioXXX di Linea
		// Successivamente, il metodo:
		// - calcola l’orario di servizio (prima/ultima corsa) alla fermata richiesta nella direzione indicata
		// - se l’orario richiesto è esterno all’orario di servizio calcolato, restituisce l’orario della prima corsa
		// - se invece l’orario richiesto è ricompreso nell’orario di servizio odierno, calcola, tenendo conto della frequenza del servizio, 
		//   l’orario della prima corsa di orario uguale o successivo a quello richiesto, e lo restituisce come risultato
		//
		return LocalTime.of(0,0); // fake, solo per compilare
		// ********************************* 
	}	
}
