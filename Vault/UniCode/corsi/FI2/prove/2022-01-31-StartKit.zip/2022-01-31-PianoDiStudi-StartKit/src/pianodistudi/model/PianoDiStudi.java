package pianodistudi.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.stream.Stream;

public class PianoDiStudi implements Piano {	
	private Map<Tipologia, List<AttivitaFormativa>> piano;
	private StringBuilder logger;
	
	public PianoDiStudi() {
		this.piano=new HashMap<>();
		this.logger = new StringBuilder();
		for (Tipologia t : Tipologia.values())
			piano.put(t, new ArrayList<>());
	}
	
	public String logVerifica() {
		return logger.toString();
	}
	
	public void inserisci(AttivitaFormativa af, Tipologia t) {
		// ***** DA FARE *****
		// consente di aggiungere un'attività formativa in una data tipologia; 
		// deve controllare che l’attività formativa da inserire non sia già presente nel piano 
		// (né in quella tipologia, né in altre) – altrimenti, lanciare IllegalArgumentException
	}

	public void rimuovi(AttivitaFormativa af, Tipologia t) {
		// ***** DA FARE *****
		// consente di rimuovere un'attività formativa da una data tipologia; 
		// deve controllare che l’attività formativa da rimuovere sia già presente nel piano 
		// *in quella specifica tipologia* - altrimenti, lanciare IllegalArgumentException
	}

	@Override
	public String toString() {
		return "PianoDiStudi [piano=" + piano + "]";
	}

	@Override
	public int getCfu(Tipologia t) {
		return piano.get(t).stream().mapToInt(af -> af.getCfu()).reduce(0, (a,b) -> a+b);
	}
	
	@Override
	public int getCfuTot() {
		return Stream.of(Tipologia.values()).mapToInt(this::getCfu).reduce(0, (a,b) -> a+b);
	}
	
	@Override
	public List<AttivitaFormativa> getAttivitaFormative(Tipologia t) {
		return piano.get(t);
	}
	
	//------------
	
	/** verifica che il piano rispetti l'ordinamento, ossia che:
	*   1) il totale crediti previsti in ogni tipologia rientri nel range min-max stabilito dall'ordinamento per tale tipologia
	*   2) le attività formative previste in ogni tipologia appartengano a un SSd ammesso dall'ordinamento per tale tipologia
	*/
	public boolean verificaOrdinamento(Ordinamento ord) {
		// DA FARE
		// Suggerimento (non obbligatorio, meno efficiente ma più chiaro): strutturare le due verifiche in due metodi ausiliari 
		// ad esempio: return verificaRangeCfu(ord) &&  verificaSettoriAttivita(ord);
		return false; // fake return solo per completare lo scheletro del metodo
	}

}
