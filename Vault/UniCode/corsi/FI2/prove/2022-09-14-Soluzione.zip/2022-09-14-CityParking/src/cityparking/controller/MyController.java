package cityparking.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;

import cityparking.model.MyCalcolatoreSosta;
import cityparking.model.Tariffa;
import cityparking.model.Ricevuta;
import cityparking.model.BadTimeIntervalException;
import cityparking.model.CalcolatoreSosta;


public class MyController implements Controller {
	private CalcolatoreSosta tickerIssuer;

	public MyController(Tariffa tariffa) {
		tickerIssuer = new MyCalcolatoreSosta(tariffa);
	}

	@Override
	public Ricevuta calcolaSosta(LocalDate dataInizio, String strOraInizio, LocalDate dataFine, String strOraFine) 
			throws BadTimeIntervalException, BadTimeFormatException {
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
		LocalTime oraInizio, oraFine;
		try {
			oraInizio = LocalTime.parse(strOraInizio, formatter);
			oraFine = LocalTime.parse(strOraFine, formatter);
		}
		catch(DateTimeParseException e) {
			throw new BadTimeFormatException("L'orario non ha il formato HH:MM - " + e);
		}
		// NB: il calcolatore sosta verifica già che orario finale non preceda quello iniziale,
		//     lanciando nel caso la prescritta eccezione
		LocalDateTime inizioSosta = LocalDateTime.of(dataInizio, oraInizio);
		LocalDateTime fineSosta = LocalDateTime.of(dataFine, oraFine);
		return tickerIssuer.calcola(inizioSosta, fineSosta);
	}
	
}
