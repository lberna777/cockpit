package cityparking.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.util.Locale;

import cityparking.model.Tariffa;


public class MyTariffaReader implements TariffaReader {
	
	/* 	Durata unità = 15m
		Costo iniziale = 2,00 €
		Unità successive = 0,80 €
		Cap giornaliero = 35,00 €
		12h successive = 16,00 €
	*/
	
	@Override
	public Tariffa leggiTariffa(Reader reader) throws IOException, BadFileFormatException {
		BufferedReader fin = new BufferedReader(reader);
			
		Duration durataUnita = leggiDurata(fin,"Durata unità");
		double costoIniziale = leggiCosto(fin,"Costo iniziale");
		double costoUnitaSuccessive  = leggiCosto(fin,"Unità successive");
		double capGiornaliero = leggiCosto(fin,"Cap giornaliero");
		double oltre = leggiCosto(fin,"12h successive");
		
		try {
			return new Tariffa(durataUnita, 
				costoIniziale, costoUnitaSuccessive, capGiornaliero, oltre);
		}
		catch(IllegalArgumentException e) {
			throw new BadFileFormatException(e);
		}
	}
	
	private Duration leggiDurata(BufferedReader fin, String descrizione) throws IOException, BadFileFormatException {
		// struttura: descrizione = valore
		String line = fin.readLine().trim();
		String[] items = line.split("=");
		if (items.length!=2 || !items[0].trim().equalsIgnoreCase(descrizione)) 
			throw new BadFileFormatException("Errore di formato in " + descrizione + ": " + line);
		try {
			return Duration.parse("PT"+items[1].trim().toUpperCase());
		}
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("Errore nel formato durata in " + descrizione + ": " + line);
		}
	}

	private double leggiCosto(BufferedReader fin, String descrizione) throws BadFileFormatException, IOException {
		// struttura: descrizione = prezzo in euro
		String line = fin.readLine().trim();
		String[] items = line.split("=");
		if (items.length!=2 || !items[0].trim().equalsIgnoreCase(descrizione)) 
			throw new BadFileFormatException("Errore di formato in " + descrizione + ": " + line);
		NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.ITALY);
		try {
			return currencyFormatter.parse(items[1].trim()).doubleValue();
		}
		catch(ParseException e) {
			throw new BadFileFormatException("Errore nel formato durata in " + descrizione + ": " + line);
		}
	}
	
}
