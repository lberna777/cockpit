package taxcomparator.ui;

import java.text.DecimalFormat;
import java.text.ParseException;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import taxcomparator.controller.Controller;
import taxcomparator.model.Fasce;


public class MainPane extends BorderPane {
	
	// DA COMPLETARE

	private CurrencyTextField reddito, imposta;
	private TextArea dettaglio;
	private Button calcola;
	private ComboBox<Fasce> combo;
	private Controller controller;
	
	public MainPane(Controller controller) {
		this.controller=controller;
		VBox topBox = new VBox();
		//
		// PARTE STRUTTURALE DA COMPLETARE
		//
		this.setTop(topBox);
		// AGGANCIO GESTIONE EVENTO DA FARE
	}

	//
	// METODO DI GESTIONE DELL'EVENTO
	//

}
