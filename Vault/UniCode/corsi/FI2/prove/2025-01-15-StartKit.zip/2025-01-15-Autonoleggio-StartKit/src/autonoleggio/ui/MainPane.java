package autonoleggio.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

import autonoleggio.controller.Controller;
import autonoleggio.model.Agency;
import autonoleggio.model.CarType;
import autonoleggio.model.Formatters;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;



public class MainPane extends BorderPane {
	
	private Controller controller;
	
	private TextArea outputArea;
	private TextField txtOrarioIniziale, txtOrarioFinale;
	private DatePicker pickerGiornoIniziale, pickerGiornoFinale;
	private Button cerca;
	private ComboBox<String> comboCities;
	private ComboBox<Agency> comboAgencies;
	private ComboBox<CarType> comboCarTypes;
	private CheckBox checkboxDropoff;

	@SuppressWarnings("unused")
	public MainPane(Controller controller) {
		this.controller=controller;
		//
		HBox topBox = new HBox();
			topBox.setPadding(new Insets(10, 10, 10, 5));
			
			comboCities = new ComboBox<>(FXCollections.observableArrayList(controller.getCities()));
			comboCities.setTooltip(new Tooltip("Scegliere la città"));
			comboCities.setPrefWidth(130);
			comboCities.setOnAction(ev -> popolaComboAgencies());
			
			comboAgencies = new ComboBox<>();
			comboAgencies.setPrefWidth(150);
			comboAgencies.setTooltip(new Tooltip("Scegliere l'agenzia desiderata"));
			comboAgencies.setOnAction(ev -> mostraOrariApertura());
			
			topBox.getChildren().addAll(new Label("Città  "), comboCities, new Label("  Agenzie  "), comboAgencies);			
		this.setTop(topBox);
		
		VBox centerBox = new VBox();
			centerBox.setPadding(new Insets(0, 10, 10, 10));
			HBox row1 = new HBox();
			row1.setPadding(new Insets(10, 10, 10, 0));
			
			pickerGiornoIniziale = new DatePicker(LocalDate.now());
			pickerGiornoIniziale.setPrefWidth(150);
			pickerGiornoIniziale.setTooltip(new Tooltip("Scegliere la data di inizio noleggio"));
			pickerGiornoIniziale.setOnAction(ev -> impostaDataFinale());
			txtOrarioIniziale = new TextField();
			txtOrarioIniziale.setPrefWidth(100);
			txtOrarioIniziale.setTooltip(new Tooltip("Inserire l'orario nella forma HH:MM"));
			txtOrarioIniziale.setText("10:00");

			row1.getChildren().addAll(new Label("Inizio noleggio  "), pickerGiornoIniziale, txtOrarioIniziale);
			
			HBox row2 = new HBox();
			row2.setPadding(new Insets(0, 10, 10, 0));
			
			pickerGiornoFinale = new DatePicker(LocalDate.now());
			pickerGiornoFinale.setPrefWidth(150);
			pickerGiornoFinale.setTooltip(new Tooltip("Scegliere la data di fine noleggio"));
			txtOrarioFinale = new TextField();
			txtOrarioFinale.setPrefWidth(100);
			txtOrarioFinale.setTooltip(new Tooltip("Inserire l'orario nella forma HH:MM"));
			txtOrarioFinale.setText("18:00");
			
			row2.getChildren().addAll(new Label("Fine noleggio    "), pickerGiornoFinale, txtOrarioFinale);
			
			HBox row3 = new HBox();
			row3.setPadding(new Insets(0, 10, 10, 0));
			
			comboCarTypes = new ComboBox<>(FXCollections.observableArrayList(CarType.values()));
			comboCarTypes.setTooltip(new Tooltip("Scegliere il tipo di auto"));
			cerca = new Button("Cerca");
			cerca.setFont(Font.font("Arial", FontWeight.BOLD, 11));
			cerca.setOnAction(ev -> cerca());
			
			checkboxDropoff = new CheckBox("Riconsegna in altra città");
			row3.getChildren().addAll(new Label("Tipo auto           "), comboCarTypes, new Label("    "), cerca, new Label("    "), checkboxDropoff);
			
			centerBox.getChildren().addAll(row1, row2, row3);
		this.setCenter(centerBox);	
		
		HBox bottomBox = new HBox();
			bottomBox.setPadding(new Insets(0, 10, 10, 10));
			outputArea = new TextArea();
			outputArea.setPrefSize(420,100);
			outputArea.setFont(Font.font("Courier New", FontWeight.NORMAL, 14));
			outputArea.setEditable(false);
			bottomBox.getChildren().addAll(outputArea);
		this.setBottom(bottomBox);
	}


	private void impostaDataFinale() {
		// ********DA FARE ********
	}

	private void popolaComboAgencies() {
		// ********DA FARE ********
	}
	
	private void mostraOrariApertura() {
		// ********DA FARE ********
	}

	private void cerca() {
		// ********DA FARE ********
	}
	
}
