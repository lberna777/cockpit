package autonoleggio.model;

import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

public class OpeningTime {
	
	private List<Slot> slots;
	public static OpeningTime CHIUSO = new OpeningTime();
	
	private OpeningTime() {
		slots = List.of();
	}
	
	public OpeningTime(Slot slotUnico) {
		Objects.requireNonNull(slotUnico, "Slot non può essere nullo");
		slots = List.of(slotUnico);
	}
	
	public OpeningTime(Slot mattino, Slot pomeriggio) {
		Objects.requireNonNull(mattino, "Slot mattino non può essere nullo");
		Objects.requireNonNull(pomeriggio, "Slot pomeriggio non può essere nullo");
		if(!mattino.to().isBefore(pomeriggio.from())) throw new IllegalArgumentException("Slot pomeridiano deve seguire slot mattutino");
		slots = List.of(mattino, pomeriggio);
	}
	
	public boolean isOpenAt(LocalTime time) {
		// ********* DA FARE *********
		return true; // FAKE
	}
	
	public String toString() {
		// ********* DA FARE *********
		return "toString ancora da fare"; // FAKE
	}
	

}
