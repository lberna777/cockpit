package autonoleggio.model;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.Objects;

public record Agency(String city, String agencyName, 
						OpeningTime openingTimeMonFri, OpeningTime openingTimeSat, OpeningTime openingTimeSun) 
					implements Comparable<Agency>{
	
	public Agency {
		Objects.requireNonNull(city, "Il nome della città non può essere nullo");
		if (city.isBlank()) throw new IllegalArgumentException("Il nome della città non può essere vuoto");
		Objects.requireNonNull(agencyName, "Il nome dell'agenzia non può essere nullo");
		if (agencyName.isBlank()) throw new IllegalArgumentException("Il nome dell'agenzia non può essere vuoto");
		if (agencyName==null  || agencyName.isBlank()) throw new IllegalArgumentException("Il nome della fermata non può essere nullo o vuoto");
		Objects.requireNonNull(openingTimeMonFri, "L'orario di apertura non può essere nullo");
		Objects.requireNonNull(openingTimeSat, "L'orario di apertura del sabato non può essere nullo");
		Objects.requireNonNull(openingTimeSun, "L'orario di apertura della domenica non può essere nullo");
	}
	
	@Override
	public String toString() {
		return city + ", " + agencyName;
	}

	@Override
	public int compareTo(Agency other) {
		return Comparator.comparing(Agency::city).thenComparing(Agency::agencyName).compare(this, other);
	}
	
	public boolean isOpenAt(LocalDateTime dateTime) {
		Objects.requireNonNull(dateTime, "Giorno e ora da verificare non possono essere nulli");
		return switch(dateTime.getDayOfWeek()) {
		case SATURDAY -> openingTimeSat.isOpenAt(dateTime.toLocalTime());
		case SUNDAY   -> openingTimeSun.isOpenAt(dateTime.toLocalTime());
		default       -> openingTimeMonFri.isOpenAt(dateTime.toLocalTime());
		};
	}
}
