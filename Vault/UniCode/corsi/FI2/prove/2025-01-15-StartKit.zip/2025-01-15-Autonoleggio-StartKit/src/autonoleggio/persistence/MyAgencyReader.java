package autonoleggio.persistence;

import java.io.IOException;
import java.io.Reader;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import autonoleggio.model.Agency;
import autonoleggio.model.Formatters;
import autonoleggio.model.OpeningTime;
import autonoleggio.model.Slot;

import java.io.BufferedReader;


public class MyAgencyReader implements AgencyReader {
	
	String nome;
	OpeningTime freq;
	LocalTime inizioServizio, fineServizio;
	List<Agency> fermate;
	
	// BOLOGNA, Aeroporto Marconi, lun-ven 08:00-23:59, sab 08:00-23:59, dom 08:00-23:59
	
	@Override
	public Set<Agency> readAllAgencies(Reader reader) throws IOException, BadFileFormatException {
		// ********DA FARE ********
		return null; // FAKE
	}

	private OpeningTime extractOpeningTime(String item, String prefix) throws BadFileFormatException {
		// ********DA FARE ********
		return null; // FAKE
	}
	
	private Slot makeSlot(String fasciaOraria) throws BadFileFormatException {
		// ********DA FARE ********
		return null; // FAKE
	}

}
