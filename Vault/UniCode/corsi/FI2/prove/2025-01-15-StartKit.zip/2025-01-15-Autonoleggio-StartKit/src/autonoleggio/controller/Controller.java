package autonoleggio.controller;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;

import autonoleggio.model.Rate;
import autonoleggio.model.Agency;
import autonoleggio.model.CarType;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class Controller {

	public static void alert(String title, String headerMessage, String contentMessage) {
		javafx.scene.control.Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(headerMessage);
		alert.setContentText(contentMessage);
		alert.showAndWait();
	}

	private Set<Agency> agencies;
	private SortedMap<CarType, Rate> rates;
	public final Set<DayOfWeek> WEEKEND_DAYS = Set.of(DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
		
	//--------------
	
	public Controller(Set<Agency> agencies, SortedMap<CarType, Rate> rates) {
		Objects.requireNonNull(agencies, "Insieme agenzie nullo nel construttore del Controller");
		Objects.requireNonNull(rates, "Elenco tariffe nullo nel construttore del Controller");
		this.agencies = agencies;
		this.rates = rates;
	}

	public Set<Agency> getAgencies() {
		return agencies;
	}

	public SortedMap<CarType, Rate> getRates() {
		return rates;
	}

	public List<String> getCities() {
		return agencies.stream().map(Agency::city).sorted().distinct().toList();
	}
	
	public List<Agency> getAgencies(String city) {
		return agencies.stream().filter( agency -> agency.city().equalsIgnoreCase(city)).sorted().toList();
	}

	private String siNo(boolean flag) {
		return flag ? "sì" : "no";
	}
	
	public Result calcolaTariffa(String city, Agency agency, LocalDateTime start, LocalDateTime end, CarType carType, boolean dropOff) {
		// ********DA FARE ********
		return null; // FAKE
	}
	
}
