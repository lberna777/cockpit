package trainstats.model;

import java.util.Optional;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.Objects;

public class Recording {
	
	private static final String UNDEFINED_TIME = " --- ";
	private Optional<LocalTime> scheduledArrival, actualArrival, scheduledDeparture, actualDeparture;
	private DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
	private String station;

	public Recording(String station, Optional<LocalTime> scheduledArrival, Optional<LocalTime> actualArrival, 
									 Optional<LocalTime> scheduledDeparture, Optional<LocalTime> actualDeparture) {
			/*
			 ****************** DA COMPLETARE QUI **************
			 
			  È compito del costruttore verificare che:
				- nessuno degli argomenti sia null
				- gli optional empty siano solo per le coppie di orari previse (ossia, o entrambi gli orari di arrivo, 
				  o entrambi quelli di partenza): ogni altro uso di optional empty dev’essere considerato illegale
				- l'orario di partenza previsto non sia antecedente all'orario di arrivo previsto
				- l'orario di partenza reale non sia antecedente né all'orario di arrivo previsto, né all'orario di partenza previsto
			 */
		this.scheduledArrival = scheduledArrival;
		this.actualArrival = actualArrival;
		this.scheduledDeparture = scheduledDeparture;
		this.actualDeparture = actualDeparture;
		this.station=station;
	}

	public String getStation() {
		return station;
	}

	public Optional<LocalTime> getScheduledArrivalTime() {
		return scheduledArrival;
	}

	public Optional<LocalTime> getActualArrivalTime() {
		return actualArrival;
	}

	public Optional<LocalTime> getScheduledDepartureTime() {
		return scheduledDeparture;
	}

	public Optional<LocalTime> getActualDepartureTime() {
		return actualDeparture;
	}

	private String formatTime(Optional<LocalTime> time) {
		return time.isEmpty() ? UNDEFINED_TIME : formatter.format(time.get());
	}
	
	@Override
	public String toString() {
		return 	String.format("%-20s", station) + "\t" + 
				formatTime(scheduledArrival) + "\t" + formatTime(actualArrival) + "\t" +
				formatTime(scheduledDeparture) + "\t" + formatTime(actualDeparture);
	}

	@Override
	public int hashCode() {
		return Objects.hash(station, scheduledArrival, actualArrival, scheduledDeparture, actualDeparture);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		Recording other = (Recording) obj;
		return  Objects.equals(station, other.station) &&
				Objects.equals(scheduledArrival, other.scheduledArrival) && Objects.equals(actualArrival, other.actualArrival) &&
				Objects.equals(scheduledDeparture, other.scheduledDeparture) && Objects.equals(actualDeparture, other.actualDeparture);
	}	
	
}
