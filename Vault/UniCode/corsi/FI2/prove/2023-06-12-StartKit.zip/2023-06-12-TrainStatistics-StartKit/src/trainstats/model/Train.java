package trainstats.model;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Train {	
	private List<Recording> recordings;
	private Map<String,Recording> recordingMap; // (Station,Recording)
	private Map<String,Long> delayMap; 			// (Station,Delay) // per ipotesi, esclude la prima stazione
	private String firstStation, lastStation;
	
	public Train(List<Recording> recordings) {
		
		/*
		 ****************** DA COMPLETARE QUI **************
		 
		  La classe Train incapsula una sequenza di rilevazioni: tale sequenza non può essere nulla e, poiché 
		  il percorso minimo va da una stazione iniziale a una finale, deve sempre contenere almeno due stazioni. 
		  È compito del costruttore 
		  - verificare la congruità di tutti gli argomenti e quindi in particolare
		  		- verificare il rispetto dei vincoli sopra menzionati per quanto riguarda la lista d'ingresso
		  		- assicurarsi che la stazione iniziale non specifichi orari di arrivo
		  		- assicurarsi che la stazione finale non specifichi orari di partenza
		  - predisporre tutte le strutture dati, in particolare:
				- una mappa <String, Recording>, restituita poi dal metodo getRecordingMap, che associ a ogni stazione 
				  la corrispondente rilevazione
				- una mappa <String, Long>, restituita poi dal metodo getDelayMap, che associ a ogni stazione il 
				  corrispondente ritardo all’arrivo 
				  (NB: se il treno è arrivato in anticipo, il ritardo va considerato zero)
 		 */

	}

	@Override
	public String toString() {
		return  String.format("%-20s%8s%8s%8s%8s%n", "stazione", "a.p.","a.r.","p.p.","p.r.") + 
				recordings.stream().map(Recording::toString).collect(Collectors.joining(System.lineSeparator()));
	}

	public List<Recording> getRecordings() {
		return recordings;
	}

	public Map<String, Recording> getRecordingMap() {
		return recordingMap;
	}

	public Map<String, Long> getDelayMap() {
		return delayMap;
	}
	
	public String getFirstStation() {
		return firstStation;
	}

	public String getLastStation() {
		return lastStation;
	}
	
	
}
