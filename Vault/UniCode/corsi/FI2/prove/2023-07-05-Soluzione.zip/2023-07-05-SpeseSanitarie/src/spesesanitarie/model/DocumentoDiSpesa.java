package spesesanitarie.model;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class DocumentoDiSpesa {
	private LocalDate data;
	private String emittente;
	private double importo;
	private List<VoceDiSpesa> items;
	
	public DocumentoDiSpesa(LocalDate data, String emittente, double importo, List<VoceDiSpesa> items) {
		verificaPrecondizioni(data, emittente, importo, items);
		verificaCongruenzaVoci(importo, items);
		this.data = data;
		this.emittente = emittente;
		this.importo = importo;
		this.items = items;
	}

	private void verificaPrecondizioni(LocalDate data, String emittente, double importo, List<VoceDiSpesa> items) {
		if (data==null) throw new IllegalArgumentException("la data di emissione non può essere nulla");
		if (emittente==null) throw new IllegalArgumentException("l'emittente non può essere nullo");
		if (!Double.isFinite(importo) || importo<0) throw new IllegalArgumentException("l'importo deve'essere un numero non negativo");
		if (items==null || items.isEmpty()) throw new IllegalArgumentException("la lista di voci non può essere nulla né vuota");
	}

	private void verificaCongruenzaVoci(double importo, List<VoceDiSpesa> items) {
		var sommaItems = items.stream().mapToDouble(VoceDiSpesa::getImporto).sum();
		if (Math.abs(importo-sommaItems)>0.01) 
			throw new IllegalArgumentException("gli importi della lista voci " 
						+ items.stream().mapToDouble(VoceDiSpesa::getImporto).mapToObj(Formatters.itPriceFormatter::format).collect(Collectors.joining("; ","[","]"))
						+ " non collimano col totale [" + Formatters.itPriceFormatter.format(importo) + "]");
	}

	public LocalDate getData() {
		return data;
	}

	public String getEmittente() {
		return emittente;
	}

	public double getImporto() {
		return importo;
	}

	public List<VoceDiSpesa> getVoci() {
		return items;
	}

	public boolean contieneVoce(Tipologia t) {
		return items.stream().anyMatch(voce -> voce.getTipologia()==t);
	}
	
	@Override
	public String toString() {
		return Formatters.itDateFormatter.format(data) + " " + emittente + " " + Formatters.itPriceFormatter.format(importo) + ", di cui:\n  "
	                                      + items.stream().map(VoceDiSpesa::toString).collect(Collectors.joining("\n  "));
	}
	
	
}
