package spesesanitarie.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.ArrayList;

import spesesanitarie.model.Formatters;
import spesesanitarie.model.DocumentoDiSpesa;
import spesesanitarie.model.Tipologia;
import spesesanitarie.model.VoceDiSpesa;

	/*
		03/01/2022;Farmacia;€ 25,71
		FC;€ 4,98
		FC;€ 8,04
		FC;€ 4,41
		FC;€ 8,28
		18/01/2022;Farmacia;€ 16,65
		FC;€ 16,65
		24/01/2022;Farmacia;€ 3,00
		TK;€ 3,00
		25/01/2022;Dentista;€ 300,00
		LP;€ 300,00
		...
	*/

public class MySpeseReader implements SpeseReader {

	@Override
	public List<DocumentoDiSpesa> leggiSpese(Reader rdr) throws IOException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		
		List<DocumentoDiSpesa> spese = new ArrayList<>(); 
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			
			String[] tokens = line.split(";");
			// ci sono sempre 4 elementi
			if (tokens.length!=4) throw new BadFileFormatException("Riga mal formattata, non ha 43 elementi:\t" + line);

			// data, stringa, importo
			String dataAsString = tokens[0].trim();
			String emittente    = tokens[1].trim();
			String nItemsAsString = tokens[2].trim();
			String importoAsString = tokens[3].trim();
			LocalDate data = null;
			double importo;
			int nItems;
			try {
				data = Formatters.itDateFormatter.parse(dataAsString, LocalDate::from);
				nItems = Integer.parseInt(nItemsAsString);
				importo = Formatters.itPriceFormatter.parse(importoAsString).doubleValue();
			}
			catch(DateTimeParseException e) {
				throw new BadFileFormatException("Data mal formattata in riga:\t" + line);				
			}
			catch(ParseException e) {
				throw new BadFileFormatException("Importo mal formattato in riga:\t" + line);				
			}
			if (nItems<=0) throw new BadFileFormatException("Numero elementi negativo o nullo in riga:\t" + line);
			// ora bisogna recuperare le righe del blocco
			List<VoceDiSpesa> items = leggiVoci(nItems,reader);
			spese.add(new DocumentoDiSpesa(data, emittente, importo, items));
		}
		return spese;
	}


	private List<VoceDiSpesa> leggiVoci(int nItems, BufferedReader reader) throws IOException {
		List<VoceDiSpesa> voci = new ArrayList<>();
		for(int i=0; i<nItems; i++) {
			String line = reader.readLine();
			if (line==null) throw new BadFileFormatException("Fine file inattesa, voci di spesa mancanti");
			String[] tokens = line.split(";");
			String tipologiaAsString = tokens[0].trim();
			String importoAsString = tokens[1].trim();
			double importo;
			Tipologia t = null;
			try {
				t = Tipologia.valueOf(tipologiaAsString);
				importo = Formatters.itPriceFormatter.parse(importoAsString).doubleValue();
			}
			catch(ParseException e) {
				throw new BadFileFormatException("Importo mal formattato in riga:\t" + line);				
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Tipologia inesistente in riga:\t" + line);				
			}
			voci.add(new VoceDiSpesa(t,importo));
		}
		return voci;
	}

}