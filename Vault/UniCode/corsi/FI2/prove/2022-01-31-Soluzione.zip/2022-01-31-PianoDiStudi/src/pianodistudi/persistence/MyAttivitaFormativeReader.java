package pianodistudi.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import pianodistudi.model.AttivitaFormativa;
import pianodistudi.model.Ssd;


public class MyAttivitaFormativeReader implements AttivitaFormativeReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1								MAT/05			9
		28004	FONDAMENTI DI INFORMATICA T-1						ING-INF/05		12
		29228	GEOMETRIA E ALGEBRA T								MAT/03			6
		26337	LINGUA INGLESE B-2									lingua straniera	6
		...
	* */

	@Override
	public Map<String,AttivitaFormativa> recuperaElenco(Reader rdr) throws IOException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		Map<String,AttivitaFormativa> mappaAF = new HashMap<>();
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			String[] items = line.split("\\t+");
			// ci sono sempre 4 parti
			if (items.length!=4) throw new BadFileFormatException("Riga mal formattata, non ha quattro elementi:\t" + line);
			@SuppressWarnings("unused")
			String codice 		= items[0].trim().toUpperCase(); // non usato
			// questi invece servono tutti
			String nome 		= items[1].trim().toUpperCase();
			String siglaSettore	= items[2].trim().toUpperCase();
			String cfuAsString	= items[3].trim().toUpperCase();
			// conversioni di tipo
			int cfu;
			Ssd ssd;			
			try {
				ssd = Ssd.of(siglaSettore);
				cfu = Integer.parseInt(cfuAsString);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException(e.getMessage() + ": " + line);
			}
			mappaAF.put(nome, new AttivitaFormativa(nome, ssd, cfu));
		}
		return mappaAF;
	}
}