package pianodistudi.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PianoDiStudi implements Piano {	
	private Map<Tipologia, List<AttivitaFormativa>> piano;
	private StringBuilder logger;
	
	public PianoDiStudi() {
		this.piano=new HashMap<>();
		this.logger = new StringBuilder();
		for (Tipologia t : Tipologia.values())
			piano.put(t, new ArrayList<>());
	}
	
	public String logVerifica() {
		return logger.toString();
	}
	
	public void inserisci(AttivitaFormativa af, Tipologia t) {
		for (Tipologia tip : Tipologia.values()) {
			if (piano.get(tip).contains(af)) throw new IllegalArgumentException("Attività formativa gia presente in " + tip + ": " + af);
		}
		piano.get(t).add(af);
	}

	public void rimuovi(AttivitaFormativa af, Tipologia t) {
		if (!piano.get(t).contains(af)) throw new IllegalArgumentException("Attività formativa non presente in "+ t + ": " + af);
		piano.get(t).remove(af);
	}

	@Override
	public String toString() {
		return "PianoDiStudi [piano=" + piano + "]";
	}

	@Override
	public int getCfu(Tipologia t) {
		return piano.get(t).stream().mapToInt(af -> af.getCfu()).reduce(0, (a,b) -> a+b);
	}
	
	@Override
	public int getCfuTot() {
		return Stream.of(Tipologia.values()).mapToInt(this::getCfu).reduce(0, (a,b) -> a+b);
	}
	
	@Override
	public List<AttivitaFormativa> getAttivitaFormative(Tipologia t) {
		return piano.get(t);
	}
	
	//------------
	
	/** verifica che il piano rispetti l'ordinamento, ossia che:
	*   1) il totale crediti previsti in ogni tipologia rientri nel range min-max stabilito dall'ordinamento per tale tipologia
	*   2) le attività formative previste in ogni tipologia appartengano a un SSd ammesso dall'ordinamento per tale tipologia
	*/
	public boolean verificaOrdinamento(Ordinamento ord) {
		logger.delete(0, logger.length());
		if (ord==null) throw new IllegalArgumentException("Ordinamento nullo");
		// NB: sarebbe più efficiente una verifica integrata dei due aspetti, in un unico ciclo
		// Tuttavia si ritiene preferibile separarla per chiarezza, visto che le tipologie sono solo una decina
		return verificaRangeCfu(ord) &&  verificaSettoriAttivita(ord);
	}
	
	/** verifica che il totale crediti previsti dal piano in ogni tipologia rientri nel range min-max previsto
	*   dall'ordinamento per tale tipologia
	*/
	private boolean verificaRangeCfu(Ordinamento ord) {
		boolean result = true;
		// calcolo cfu per tipologia in questo piano
		Map<Tipologia, Integer> cfuPianoPerTipologia = Stream.of(Tipologia.values()).collect(Collectors.toMap(t->t, this::getCfu));
		// oppure ciclo: for (Tipologia t : Tipologia.values()) cfuPianoPerTipologia.put(t, getCfu(t));
		//
		// --- inizio verifica rispetto ordinamento
		int cfuTotNelPiano = 0;
		for (Tipologia t : Tipologia.values()) {
			cfuTotNelPiano += cfuPianoPerTipologia.get(t);
			if (!ord.getRange(t).contains(cfuPianoPerTipologia.get(t))) {
				logger.append("Crediti inconsistenti in " + t + ": " + cfuPianoPerTipologia.get(t) + " vs. " + ord.getRange(t) + System.lineSeparator());
				result = false;
			}
			else {
				logger.append("Crediti corretti in " + t + ": " + cfuPianoPerTipologia.get(t) + " vs. " + ord.getRange(t) + System.lineSeparator());
			}
		}
		if (cfuTotNelPiano<CFULT) {
			logger.append("Cfu totali nel piano (" + cfuTotNelPiano +") < " + CFULT +  System.lineSeparator());
			result = false;
		} else {
			logger.append("Cfu totali nel piano: " + cfuTotNelPiano +  System.lineSeparator());
		}
		return result;
	}
	
	/** verifica che le attività formative previste dal piano in ogni tipologia siano di un SSd ammesso 
	*   dall'ordinamento per tale tipologia
	*/
	private boolean verificaSettoriAttivita(Ordinamento ord) {
		boolean consistente = true;
		for (Tipologia t : Tipologia.values()) {
			// NB: appartenere all'elenco settori è un vincolo, quindi se l'elenco è vuoto (o contiene solo "qualsiasi") 
			//     non ci sono vincoli, e qualunque settore è ammesso (è il caso delle tipologie D,F)
			Optional<List<Ssd>> settori = ord.getSettori(t);
			if (!settori.isEmpty() && !settori.get().contains(Ssd.QUALSIASI)) {
				//result = this.getAttivitaFormative(t).stream().map(af -> af.getSsd()).map(ssd -> settori.get().contains(ssd)).reduce(true, (a, b) -> a && b);
				consistente = this.getAttivitaFormative(t).stream().map(af -> af.getSsd()).map(ssd -> settori.get().contains(ssd)).peek(System.out::println).reduce(true, (a, b) -> a && b);
				if (!consistente) logger.append("Una o più attività formative non appartengono ai ssd permessi per tipologia " + t + ": " + this.getAttivitaFormative(t)+ System.lineSeparator());
			}
		}
		return consistente;
	}

}
