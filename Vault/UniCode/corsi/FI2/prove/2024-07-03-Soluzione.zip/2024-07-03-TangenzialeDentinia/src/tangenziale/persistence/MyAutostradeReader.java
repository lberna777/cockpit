package tangenziale.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import tangenziale.model.Autostrada;
import tangenziale.model.Tipologia;


public class MyAutostradeReader implements AutostradeReader {

	public  Map<String,Autostrada> leggiAutostrade(Reader reader) throws IOException, BadFileFormatException {
		Objects.requireNonNull(reader, "reader non deve essere nullo");
		var myReader = new BufferedReader(reader);
		
		Map<String,Autostrada> profili = new TreeMap<>();
		
		String line;
		while((line=myReader.readLine())!=null) {
			if(line.isBlank()) continue;
			
			var tipologia = (line.startsWith(Autostrada.TANGENZIALE)) ? Tipologia.TANGENZIALE : Tipologia.AUTOSTRADA;
			String id = line.trim();
			
			SortedMap<Integer,String> caselli = new TreeMap<>();
			try {
			 while(!(line=myReader.readLine()).equals(AutostradeReader.END_TAG)) {
				String[] items = line.split("\\s*\\t+\\s*");
				if (items.length!=2) throw new BadFileFormatException("formato riga errato: " + line);
				int km;
				try {
					km = Integer.parseInt(items[0]);
				}
				catch(NumberFormatException e) {
					throw new BadFileFormatException("progressiva km illegale nella riga: " + line);
				}
				
				String nome = items[1];
				
				// --- controlli di consistenza sulla singola autostrada ---
				//
				// NB: il controllo sull'esistenza di due caselli omonimi lo farebbe già Autostrada,
				// 	   quindi questo è sovrabbondante
				if (caselli.entrySet().stream().map(Entry::getValue).filter(n -> n.equals(nome)).count() > 0)
					throw new BadFileFormatException("Impossibile avere due caselli omonimi : " + line);
				
				//     Invece, Autostrada non può verificare se nel file ci fossero due progressive km identiche
				//	   perché al secondo inserimento in mappa, il secondo sovrascriverebbe semplicemente il primo
				//	   Quindi, occorre controllarlo qui, prima di effettuare l'inserimento
							if(caselli.get(km)!=null)
						throw new BadFileFormatException("Impossibile avere due caselli alla stessa progressiva km: " + line);
							
				caselli.put(km, nome);
			 }

			 profili.put(id, new Autostrada(tipologia, id, caselli));			
			}
			catch(NullPointerException e) {
				throw new BadFileFormatException("Fine file inattesa, file terminato inaspettatamente");
			}
		}
		
		// --- controlli di consistenza globale sulla rete autostradale nel suo complesso ---
		if (profili.entrySet().stream().map(Entry::getValue).map(Autostrada::tipologia).filter(t -> t==Tipologia.TANGENZIALE).count() != 1)
			throw new BadFileFormatException("Manca la tangenziale!");
			
		return profili;
	}


}
