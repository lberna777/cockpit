package tangenziale.model;

import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;

public class MyPlanner implements Planner {

	private Map<String, Autostrada> rete;

	public MyPlanner(Map<String,Autostrada> rete) {
		Objects.requireNonNull(rete, "Planner: la rete autostradale non può essere null");
		if(rete.isEmpty()) throw new IllegalArgumentException("Planner: la rete autostradale non può essere vuota");
		if(!rete.keySet().contains(Autostrada.TANGENZIALE)) throw new IllegalArgumentException("Planner: la rete autostradale non contiene la Tangenziale");
		this.rete = rete;
	}

	@Override
	public Percorso trovaPercorso(String da, String a) {
		// ---- validazione input ----
		Objects.requireNonNull(da, "casello di partenza non può essere nullo");
		Objects.requireNonNull(a,  "casello di arrivo non può essere nullo");
		Optional<Autostrada> optAutostradaDa = rete.entrySet().stream().filter(autostrada -> autostrada.getValue().profilo().values().contains(da)).map(Entry::getValue).findFirst();
		Optional<Autostrada> optAutostradaA  = rete.entrySet().stream().filter(autostrada -> autostrada.getValue().profilo().values().contains(a)).map(Entry::getValue).findFirst();
		if(optAutostradaDa.isEmpty()) throw new IllegalArgumentException("casello di partenza " + da + " inesistente sulla rete autostradale");
		if(optAutostradaA.isEmpty()) throw new IllegalArgumentException("casello di arrivo " + a + " inesistente sulla rete autostradale");
		
		// ---- predisposizione autostrade in gioco ----
		var autostradaDa = optAutostradaDa.get();
		var autostradaA = optAutostradaA.get();
		var tangenziale = rete.get(Autostrada.TANGENZIALE);
		
		// ---- algoritmo ----
		var percorso = new ArrayList<Tratta>();
						
		if(autostradaDa == autostradaA)  
			percorso.add(new Tratta(da, a, autostradaDa));
		else 
		if(autostradaDa!=tangenziale && autostradaA!=tangenziale) {
			percorso.add(new Tratta(da, Autostrada.TANGENZIALE, autostradaDa));
			percorso.add(new Tratta(autostradaDa.id(), autostradaA.id(), tangenziale));
			percorso.add(new Tratta(Autostrada.TANGENZIALE, a, autostradaA ));			
		}
		else { // una delle due è tangenziale, l'altra no
			var autostradaOrigine =      (autostradaDa==tangenziale ? tangenziale : autostradaDa);
			var autostradaDestinazione = (autostradaA==tangenziale  ? tangenziale : autostradaA);
			percorso.add(new Tratta(da, autostradaDestinazione.id(), autostradaOrigine     ));
			percorso.add(new Tratta(autostradaOrigine.id(), a,       autostradaDestinazione));			
		}
		
		return new Percorso(percorso);
	}

}

