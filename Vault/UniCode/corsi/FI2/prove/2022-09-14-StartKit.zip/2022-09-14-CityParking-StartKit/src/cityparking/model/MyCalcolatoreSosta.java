package cityparking.model;

import java.time.LocalDateTime;

public class MyCalcolatoreSosta extends CalcolatoreSosta {

	public MyCalcolatoreSosta(Tariffa tariffa) {
		super(tariffa);
	}

	// *** DA REALIZZARE ***
	@Override
	public Ricevuta calcola(LocalDateTime inizio, LocalDateTime fine) throws BadTimeIntervalException {
		return null; // fake
	}

}
