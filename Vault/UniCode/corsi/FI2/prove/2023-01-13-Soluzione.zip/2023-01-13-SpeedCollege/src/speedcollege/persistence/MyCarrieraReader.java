package speedcollege.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;

import speedcollege.model.AttivitaFormativa;
import speedcollege.model.Carriera;
import speedcollege.model.Esame;
import speedcollege.model.Voto;


public class MyCarrieraReader implements CarrieraReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1 (cfu:9)			12/01/20	RT
		27991	ANALISI MATEMATICA T-1 (cfu:9)			10/02/20	22
		28004	FONDAMENTI DI INFORMATICA T-1 (cfu:12)	13/02/20	24
		29228	GEOMETRIA E ALGEBRA T (cfu:6)			18/01/20	26
		26337	LINGUA INGLESE B-2 (cfu:6)
		27993	ANALISI MATEMATICA T-2 (cfu:6)			10/06/20	RE
		27993	ANALISI MATEMATICA T-2 (cfu:6)			02/07/20	RT
		28006	FONDAMENTI DI INFORMATICA T-2 (cfu:12)
		28011	RETI LOGICHE T (cfu:6)		
		...
	*/

	@Override
	public Carriera leggiCarriera(Reader rdr) throws IOException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		Carriera carriera = new Carriera();
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			
			String[] items = line.split("\\t+");
			// ci sono sempre 2 o 4 elementi
			if (items.length!=2 && items.length!=4) throw new BadFileFormatException("Riga mal formattata, non ha 2 o 4 elementi:\t" + line);

			// i primi due elementi ci sono sempre e vanno comunque verificati
			String idAsString = items[0].trim().toUpperCase();
			String nomeAndCfuAsString = items[1].trim();
			
			// conversioni di tipo: id
			long id;
			try {
				id = Long.parseLong(idAsString);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Codice illegale, non è un long:\t" + line);				
			}
			if (id<1) throw new BadFileFormatException("Codice illegale, deve essere positivo:\t" + line);

			String[] nameAndCfu = nomeAndCfuAsString.split("\\(cfu:");
			if (nameAndCfu.length!=2) throw new BadFileFormatException("Formato cfu illegale:\t" + line);	
			String name = nameAndCfu[0].trim().toUpperCase();
			String[] cfuAsStringAndClosedPar = nameAndCfu[1].trim().split("\\)");
			if (cfuAsStringAndClosedPar.length!=1) throw new BadFileFormatException("Formato cfu illegale:\t" + line);
			String cfuAsString = cfuAsStringAndClosedPar[0].trim();
			
			// conversioni di tipo: cfu			
			int cfu = 0;
			try {
				cfu = Integer.parseInt(cfuAsString);
			}
			catch(NumberFormatException e) {
				throw new BadFileFormatException("Valore cfu deve essere intero:\t" + line);				
			}
			if (cfu<1) throw new BadFileFormatException("Valore cfu deve essere positivo:\t" + line);

			
			if (items.length==2) continue; // interessano solo gli esami sostenuti
			// da qui in poi ci sono sempre tutti e cinque gli elementi
	
			String dataAsString	= items[2].trim().toUpperCase();
			String votoAsString	= items[3].trim().toUpperCase();
			
			// conversioni di tipo: data
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT).withLocale(Locale.ITALY);
			LocalDate date = null;
			try {
				date = LocalDate.parse(dataAsString, dateFormatter);
			}
			catch(DateTimeParseException e) {
				throw new BadFileFormatException("Data mal formattata:\t" + line);				
			}
			// conversioni di tipo: voto
			Voto voto = null; 
			try {
				voto = Voto.of(votoAsString);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Voto illegale o mal formattato:\t" + line);				
			}
			try {
			carriera.inserisci(new Esame(
					new AttivitaFormativa(id, name, cfu),
					date,
					voto
					));
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Inserimento illegale in carriera:\t" + line);				
			}
		}
		return carriera;
	}

}