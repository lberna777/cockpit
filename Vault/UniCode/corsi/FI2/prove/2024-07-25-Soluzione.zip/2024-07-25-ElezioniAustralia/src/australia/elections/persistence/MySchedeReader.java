package australia.elections.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import australia.elections.model.Scheda;

public class MySchedeReader implements SchedeReader {

	public List<Scheda> leggiSchede(Reader reader) throws IOException, BadFileFormatException {
		Objects.requireNonNull(reader, "reader non deve essere nullo");
		var myReader = new BufferedReader(reader);
		List<Scheda> schedeLette = new ArrayList<>();
		
		String line;
		int nItems = 0;
		Set<String> nomiCandidati = Collections.emptySet();
		
		while((line=myReader.readLine())!=null) {
			SortedMap<String,Integer> preferenze = new TreeMap<>();
			String[] items = line.split(",");
			
			if (items.length %2 != 0) throw new BadFileFormatException("La riga non contiene un numero pari di elementi: " + line);
			
			if (nItems==0) nItems = items.length; // solo la prima volta
			else if (items.length!=nItems) throw new BadFileFormatException("Le righe devono avere tutte lo stesso numero di elementi: " + line);
			
			try {
				for (int k=0; k<nItems; k += 2) {
					String nome = items[k].trim();
					if (nome.matches("\\d+")) throw new BadFileFormatException("Il nome del candidato non può essere un numero: " + line);
					int pref = Integer.parseInt(items[k+1].trim());
					preferenze.put(nome, pref);
				}
			} catch(NumberFormatException e) {
				throw new BadFileFormatException("La riga non contiene stringhe e numeri interi alternati: " + line);
			}
			
			if(nomiCandidati.isEmpty()) nomiCandidati = preferenze.keySet();
			if(!nomiCandidati.isEmpty() && !nomiCandidati.equals(preferenze.keySet()))
				throw new BadFileFormatException("Le righe non contengono sempre gli stessi nomi di candidati: " + line);
			schedeLette.add(new Scheda(preferenze));
		}
		
		return schedeLette;
	}


}
