package australia.elections.model;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

public class Scrutinio {

	private Map<String,List<Scheda>> mappa;
	private long totaleVoti;
	private StringBuilder logger;
	
	public Scrutinio(List<Scheda> schedeLette) {
		Objects.requireNonNull(schedeLette, "La lista delle schede lette non può essere null");
		if (schedeLette.isEmpty()) throw new IllegalArgumentException("La lista delle schede lette non può essere vuota");
		this.mappa = schedeLette.stream().collect(Collectors.groupingBy(
												scheda -> scheda.candidatiInOrdineDiPreferenza().get(0)
											));
		this.totaleVoti = schedeLette.size();
		this.logger = new StringBuilder();
	}
	
	public Risultato scrutina() {
		long maxVoti;
		do {
			maxVoti = mappa.values().stream().map(list -> list.size()).max(Integer::compare).get();
			logger.append("log: " + mappa + ", maxVoti = " + maxVoti + System.lineSeparator());		
			if(noMaggioranza(maxVoti)) {
				String ultimo = mappa.entrySet().stream()
											   .sorted(Comparator.comparing(entry -> entry.getValue().size()))
											   .findFirst().get()
											   .getKey();
				logger.append("log: rimozione candidato " + ultimo + System.lineSeparator());
				var schedeUltimo = mappa.get(ultimo);
				mappa.remove(ultimo);
				schedeUltimo.forEach( scheda -> {
					var candidatoTarget = scheda.successivoFra(ultimo, mappa.keySet()).get();
						// System.out.println("ultimo: " + ultimo + ", scheda = " + scheda + ", next = " + candidatoTarget);
					mappa.get(candidatoTarget).add(scheda);
				});
				
			}
		} while(noMaggioranza(maxVoti));
		logger.append("log: risultato " + mappa + System.lineSeparator());
		Map<String,Long> mappaVoti = mappa.entrySet().stream().collect(Collectors.toMap(Entry::getKey, entry -> (long) entry.getValue().size()));
		return new Risultato(mappaVoti);
	}

	private boolean noMaggioranza(long maxVoti) {
		return maxVoti< totaleVoti/2 + 1;
	}
	
	public long getTotaleVoti() {
		return totaleVoti;
	}
	
	public String getLog() {
		return logger.toString();
	}
}
