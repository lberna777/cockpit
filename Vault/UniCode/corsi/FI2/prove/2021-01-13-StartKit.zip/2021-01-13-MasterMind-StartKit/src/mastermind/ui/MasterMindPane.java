package mastermind.ui;

import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import mastermind.model.Combinazione;
import mastermind.model.PioloDiGioco;
import mastermind.model.Status;

public class MasterMindPane extends BorderPane {

	private TextArea output;
	private Button stampaReport, restart, inserisci, svela;
	private Controller controller;
	private Label rimasti, status;
	private List<ComboBox<PioloDiGioco>> bottoniCodice;
	
	public MasterMindPane(Controller controller, Stage stage) {
		this.controller=controller;
		// ...
		// DA COMPLETARE
	}
	
	// da agganciare al pulsante "Stampa report"
	private void saver(ActionEvent e) {
		// ...
		// DA COMPLETARE
	}

	private void gioca(ActionEvent e) {
		// ...
		// DA COMPLETARE
	}

	// da agganciare al pulsante "Svela"
	private void reveal(ActionEvent e) {
		// ...
		// DA COMPLETARE
	}
	
	// da agganciare al pulsante "Restart"
	private void restarter(ActionEvent e) {
		controller.restart();
		output.setText("");
		inserisci.setDisable(false);
		rimasti.setText("Tentativi rimasti: " + controller.tentativiRimasti() + "  ");
		status.setText("Stato del gioco: " + controller.status());
		for (ComboBox<PioloDiGioco> c : bottoniCodice) {
			c.getSelectionModel().clearSelection();
			c.setStyle("-fx-background-color: #C0C0C0;");
		}
	}

	// da agganciare alle combo per colorarne automaticamente lo sfondo
	private void colorer(ActionEvent e) {
		@SuppressWarnings("unchecked")
		ComboBox<PioloDiGioco> combo = (ComboBox<PioloDiGioco>)(e.getSource());
		if (combo.getValue()!=null) {
			combo.setStyle("-fx-background-color: " + combo.getValue().rgb() + ";");
		};
	}
	
}
