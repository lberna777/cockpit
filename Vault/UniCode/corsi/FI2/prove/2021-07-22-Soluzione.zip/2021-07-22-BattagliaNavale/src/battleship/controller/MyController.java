package battleship.controller;

import battleship.model.ShipBoard;
import battleship.model.ShipItem;


public class MyController extends AbstractController {

	public MyController(ShipBoard solutionBoard, ShipBoard playerBoard) {
		super(solutionBoard,playerBoard);
	}

	@Override
	public int verify() {
		int wrong = 0; 
		boolean gameOver=true;
		for (int row = 0; row < getSize(); row++) {
			for (int col = 0; col < getSize(); col++) {
				if(!getPlayerBoard().getCell(row,col).equals(getSolutionBoard().getCell(row,col))
						&& getPlayerBoard().getCell(row,col)!=ShipItem.EMPTY) {
					wrong++;
					getPlayerBoard().setCell(row,col, ShipItem.EMPTY);
				}
				else {
					if(getPlayerBoard().getCell(row,col)==ShipItem.EMPTY) gameOver=false;
				}
			}
		}
		this.gameOver = gameOver;
		// System.out.println(gameOver);
		return wrong;
	}
	
}
