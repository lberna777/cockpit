package mediaesami.ui;

import java.text.NumberFormat;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import mediaesami.controller.Controller;

public class MainPane extends BorderPane {
	
	private Controller controller;
	private ComboBox<String> carriereCombo;
	private TextArea area;
	private String selectedValue;
	private TextField txtMediaPesata, txtCreditiAcquisiti;
	private NumberFormat formatter;

	public MainPane(Controller controller) {
		this.controller=controller;
		formatter = NumberFormat.getInstance(Locale.ITALY);
		formatter.setMaximumFractionDigits(2);
		formatter.setMinimumFractionDigits(2);
		//
		VBox leftBox = new VBox();
		leftBox.setPrefWidth(100);
			HBox miniBoxIniziale = new HBox(); miniBoxIniziale.setAlignment(Pos.CENTER);
			Label titolino = new Label("Carriere studenti");
			titolino.setStyle("-fx-font-weight: bold");
			miniBoxIniziale.getChildren().addAll(titolino);
			leftBox.getChildren().addAll(new Label("  "), miniBoxIniziale, new Label("  "));
			//
			carriereCombo = new ComboBox<>(FXCollections.observableArrayList(this.controller.getListaIdCarriere()));
			//carriereCombo.getSelectionModel().selectFirst();
			carriereCombo.setTooltip(new Tooltip("Scegliere la carriera da visualizzare"));
			leftBox.getChildren().addAll(new Label(" Scelta carriera:  "), carriereCombo);
			//
			carriereCombo.setOnAction(this::myHandle);
			//
			//if (this.controller.getListaIdCarriere().size()>0) selectedValue = this.controller.getListaIdCarriere().get(0);
			//
			//HBox miniBox = new HBox(); miniBox.setAlignment(Pos.CENTER);
			txtMediaPesata = new TextField();
			txtCreditiAcquisiti = new TextField();
			txtMediaPesata.setFont(Font.font("Courier New", FontWeight.BOLD, 11));
			txtCreditiAcquisiti.setFont(Font.font("Courier New", FontWeight.BOLD, 11));
			txtMediaPesata.setAlignment(Pos.CENTER_RIGHT);
			txtCreditiAcquisiti.setAlignment(Pos.CENTER_RIGHT);
			txtMediaPesata.setEditable(false);
			txtCreditiAcquisiti.setEditable(false);
			leftBox.getChildren().addAll(new Label(" Media pesata:  "), txtMediaPesata);
			leftBox.getChildren().addAll(new Label(" Crediti acquisiti:  "), txtCreditiAcquisiti);
			this.setLeft(leftBox);
		VBox rightBox = new VBox();
			rightBox.setPrefWidth(550);
			area = new TextArea();
			area.setPrefSize(550,500);
			area.setFont(Font.font("Courier New", FontWeight.NORMAL, 11));
			area.setEditable(false);
			rightBox.getChildren().addAll(area);
		this.setRight(rightBox);
	}
	
	private void myHandle(ActionEvent ev) {
		selectedValue = carriereCombo.getValue();
		area.setText(this.controller.getCarriera(selectedValue).toString());
		txtMediaPesata.setText(formatter.format(this.controller.getMediaPesata(selectedValue))+"/30");
		txtCreditiAcquisiti.setText(formatter.format(this.controller.getCreditiAcquisiti(selectedValue))+"/180");
	}
	
}
