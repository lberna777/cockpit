package mediaesami.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

import mediaesami.model.AttivitaFormativa;
import mediaesami.model.Carriera;
import mediaesami.model.Esame;
import mediaesami.model.Voto;


public class MyCarrieraReader implements CarrieraReader {

	/*
	 * 	27991	ANALISI MATEMATICA T-1				9,0		12/1/2020	RT
		27991	ANALISI MATEMATICA T-1				9,0		10/2/2020	22
		28004	FONDAMENTI DI INFORMATICA T-1		12,0	13/2/2020	24
		29228	GEOMETRIA E ALGEBRA T				6,0		18/1/2020	26
		26337	LINGUA INGLESE B-2					6,0
		27993	ANALISI MATEMATICA T-2				6,0		10/6/2020	RE
		27993	ANALISI MATEMATICA T-2				6,0		02/7/2020	RT
		28006	FONDAMENTI DI INFORMATICA T-2		12,0
		28011	RETI LOGICHE T						6,0
		...
	* */

	@Override
	public Carriera leggiCarriera(Reader rdr) throws IOException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		Carriera carriera = new Carriera();
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			
			String[] items = line.split("\\t+");
			// ci sono sempre 3 o 5 elementi
			if (items.length!=3 && items.length!=5) throw new BadFileFormatException("Riga mal formattata, non ha 3 o 5 elementi:\t" + line);

			// i primi tre elementi ci sono sempre e vanno comunque verificati
			String idAsString	= items[0].trim().toUpperCase();
			String nome 		= items[1].trim().toUpperCase();
			String cfuAsString	= items[2].trim().toUpperCase();

			// conversioni di tipo: id
			long id;
			try {
				id = Long.parseLong(idAsString);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Codice illegale, non è un long:\t" + line);				
			}
			if (id<1) throw new BadFileFormatException("Codice illegale, deve essere positivo:\t" + line);

			// conversioni di tipo: cfu
			NumberFormat numberFormatter = NumberFormat.getInstance(Locale.ITALY);
			ParsePosition pos = new ParsePosition(0);
			Number cfuNum = numberFormatter.parse(cfuAsString.replace('.',' '), pos);
			if (cfuNum==null || pos.getIndex()<cfuAsString.length() || cfuNum.doubleValue()<1.0)
				throw new BadFileFormatException("Valore crediti mal formattato o illegale: " + line);
			double cfu = cfuNum.doubleValue();
			
			if (items.length==3) continue; // interessano solo gli esami sostenuti
			// da qui in poi ci sono sempre tutti e cinque gli elementi
	
			String dataAsString	= items[3].trim().toUpperCase();
			String votoAsString	= items[4].trim().toUpperCase();
			
			// conversioni di tipo: data
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("d/M/yyyy").withLocale(Locale.ITALY);
			LocalDate date = null;
			try {
				date = LocalDate.parse(dataAsString, dateFormatter);
			}
			catch(DateTimeParseException e) {
				throw new BadFileFormatException("Data mal formattata:\t" + line);				
			}
			// conversioni di tipo: voto
			Voto voto = null; 
			try {
				voto = Voto.of(votoAsString);
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Voto illegale o mal formattato:\t" + line);				
			}
			try {
			carriera.inserisci(new Esame(
					new AttivitaFormativa(id, nome, cfu),
					date,
					voto
					));
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Inserimento illegale in carriera:\t" + line);				
			}
		}
		return carriera;
	}

}