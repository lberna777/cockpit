package edlift.model;

import java.util.OptionalInt;

public class BasicLift extends Lift {
	
	public BasicLift(int minFloor, int maxFloor, int initialFloor, double speed) {
		super(minFloor, maxFloor, initialFloor, speed);
    }

	@Override
	public RequestResult goToFloor(int floor){
		if (floor>getMaxFloor() || floor<getMinFloor()) 
			throw new IllegalArgumentException("Arrival floor out of range");
		// l'ascensore base non accetta richieste mentre � in movimento
		if (getCurrentState()!=LiftState.REST) return RequestResult.REJECTED;
		else setCallingFloor(floor);
		return RequestResult.ACCEPTED;
	}
	
	@Override
	public String getMode() {
		return "Basic";
	}


}
