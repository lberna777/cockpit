package edlift.persistence;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.NoSuchElementException;

import edlift.model.*;

public class MyInstallationReader implements InstallationReader {

	private final List<String> tipiAmmissibili = List.of("BASIC", "MULTI", "HEALTHY"); 
	
	@Override
	public List<Installation> readAll(Reader reader) throws BadFileFormatException, IOException {

		List<Installation> installations = new ArrayList<>();
		String line = null, descr;
		int minFloor, maxFloor, numFloors;

		try {
			BufferedReader myReader = new BufferedReader(reader);
			while ((line = myReader.readLine()) != null) {
				String tipo, piani, min, max;
				if(line.toUpperCase().startsWith("ASCENSORE")) {
			 		
					String[] items = line.toUpperCase().split("(ASCENSORE )+");
					if(items.length!=2 || items[0]!="") throw new BadFileFormatException("missing ASCENSORE in starting position of 1st line of lift block");
					else descr = items[1];
					line = myReader.readLine();
					items = line.toUpperCase().split("(\\s|TIPO |DA |PIANI |A )+");
					if(items[0]!="") throw new BadFileFormatException("missing TIPO in starting position of 2nd line of lift block");
					else if(items.length!=5) throw new BadFileFormatException("wrong numbers of items in 2nd line of lift block");
					else {
						tipo  = items[1];
						piani = items[2];
						min = items[3];
						max = items[4];
					}
					if(!tipiAmmissibili.contains(tipo))
						throw new BadFileFormatException("wrong TIPO in 2nd line of lift block");
					
					minFloor = Integer.parseInt(min);
					maxFloor = Integer.parseInt(max);
					numFloors = Integer.parseInt(piani);
					if (maxFloor <= minFloor)
						throw new BadFileFormatException("Max floor must be > min floor");
					if (numFloors != maxFloor-minFloor+1)
						throw new BadFileFormatException("Inconsistent floor numbers: min=" + minFloor + ", max=" + maxFloor + ", floors=" + numFloors + "\nbut should be " + (maxFloor-minFloor+1));
						
					line = myReader.readLine();
					items = line.toUpperCase().toUpperCase().split("(\\s|VELOCITA |M/S)+");
					double speed;
					if(items.length<1 || items[0]!="") throw new BadFileFormatException("missing VELOCITA in starting position of 3rd line of lift block");
					else if(items.length!=2) throw new BadFileFormatException("wrong numbers of items in 3rd line of lift block");
					else speed = Double.parseDouble(items[1]);
				
					installations.add(new Installation(descr, Lift.of(tipo, minFloor, maxFloor, speed)));
				}
				else { // line does not start with "ASCENSORE"
					if (!line.isEmpty()) // empty lines are acceptable in-between 
						throw new BadFileFormatException("missing ASCENSORE in starting position of 1st line of lift block");
				}

			}
			return installations;
		} catch (NumberFormatException e) {
			throw new BadFileFormatException("Illegal number: " + e);
		} catch (NoSuchElementException | IllegalArgumentException e) {
			throw new BadFileFormatException(e);
		}
	}

}
