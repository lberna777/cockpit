package sudoku.model;

import java.util.Arrays;
import java.util.OptionalInt;

public class SudokuBoard {
	private OptionalInt[][] board;
	private static final int DIM = 9;
	private int fullCellNumber;

	public SudokuBoard() {
		board = new OptionalInt[DIM][DIM];
		Arrays.stream(board).forEach(arr -> Arrays.fill(arr, OptionalInt.empty()));
		fullCellNumber = 0;
	}

	public void setCellRow(int row, int[] numValues) {
		if (row < 0 || row >= DIM || numValues.length!=DIM)
			throw new IllegalArgumentException("Errore nei parametri");
		for (int col = 0; col < DIM; col++) {
			if (numValues[col] < 0 || numValues[col] > DIM) {
				throw new IllegalArgumentException("Errore nei parametri");
			}
			if (numValues[col] != 0) {
				board[row][col] = OptionalInt.of(numValues[col]);
				fullCellNumber++;
			}
		}
	}

	public OptionalInt getCell(int row, int col) {
		if (row < 0 || row >= DIM || col < 0 || col >= DIM)
			throw new IllegalArgumentException("Errore nei parametri");

		return board[row][col];

	}

	public int getSize() {
		return DIM;
	}

	private int min(int x) {
		return 3 * (x / 3);
	}

	private int max(int x) {
		return min(x) + 3;
	}

	public void clearCell(int row, int col)
	{
		if (row < 0 || row >= DIM || col < 0 || col >= DIM )
			throw new IllegalArgumentException("Errore nei parametri");
		   board[row][col]=OptionalInt.empty();
		   fullCellNumber--;
				   
	}
	
	
	
	public boolean setCell(int row, int col, int digit) {
		if (row < 0 || row >= DIM || col < 0 || col >= DIM || digit <= 0 || digit > DIM)
			throw new IllegalArgumentException("Errore nei parametri");
		
		// controllo che la cifra non ci sia gi� nella colonna
		for (int xx = 0; xx < 9; xx++) {
			if ((getCell(xx, col).isPresent())) {
				if (getCell(xx, col).getAsInt() == digit)
					return false;
			}
		}

		// controllo che la cifra non ci sia gi� nella riga
		for (int yy = 0; yy < 9; yy++) {
			if ((getCell(row, yy).isPresent())) {
				if (getCell(row, yy).getAsInt() == digit)
					return false;
			}
		}
		// controllo che la cifra non ci sia gi� nel quadratino
		for (int xx = min(row); xx < max(row); xx++) {
			for (int yy = min(col); yy < max(col); yy++) {
				if ((getCell(xx, yy).isPresent())) {
					if (getCell(xx, yy).getAsInt() == digit)
						return false;
				}
			}
		}

		if (!board[row][col].isPresent()) fullCellNumber++;
		board[row][col] = OptionalInt.of(digit);
		return true;
	}

	public boolean isFull() {
		return (fullCellNumber == DIM * DIM) ? true : false;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int k = 0; k < DIM * DIM; k++) {
			if (getCell(k / DIM, k % DIM).isPresent())
				sb.append(board[k / DIM][k % DIM].getAsInt());
			else
				sb.append(" ");
			sb.append(k % DIM == DIM - 1 ? System.lineSeparator() : '\t');
		}
		return sb.toString();
	}

	public int getEmpyCellNumber() {
		return (DIM * DIM) - fullCellNumber;
	}
}
