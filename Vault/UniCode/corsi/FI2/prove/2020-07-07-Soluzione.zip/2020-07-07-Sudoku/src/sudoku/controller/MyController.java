package sudoku.controller;

import java.util.OptionalInt;

import sudoku.model.SudokuBoard;

public class MyController extends AbstractController {

	public MyController(SudokuBoard sud) {
		super(sud);
	}

	

	public String getCellLabel(int row, int col) {

		OptionalInt value = sudoku.getCell(row, col);
		if (value.isPresent())
			return value.getAsInt() + "";
		else
			return " ";
	}

	public boolean setCell(int row, int col, String value) {
		if(value.contentEquals(" ")) {
			sudoku.clearCell(row, col); 
			return true;
			}
		else
		{
			return sudoku.setCell(row, col, Integer.parseInt(value));
		}

}

}
