package gasforlife.controller;

import java.util.List;
import java.util.Map;

import gasforlife.model.Bill;
import gasforlife.model.Flat;
import gasforlife.model.Share;
import gasforlife.model.BillingFrequency;
import gasforlife.persistence.ConsumptionReader;
import gasforlife.persistence.FlatReader;

public class MyController implements Controller {
	private Map<String, List<Double>> gasConsumption;
	private Map<String, Flat> flats;

	public MyController(FlatReader flatReader, ConsumptionReader conReader) {
		this.gasConsumption = conReader.getItems();
		this.flats = flatReader.getItems();
	}

	@Override
	public void computeShare(Bill bill) {
		switch(bill.getBillingFrequency()) {
			case ANNUAL:  computeAnnualCost(bill); break;
			case MONTHLY: computeMonthlyCost(bill); break;
		}
	}

	private void computeAnnualCost(Bill bill) {
		double totalPrice = 0;
		for (String flat : flats.keySet()) {
			double price = 0;
			double totalCons = 0;
			for (int month = 0; month < 12; month++) {
				double realCons = gasConsumption.get(flat).get(month);
				price += this.getMonthlyCostForFlat(flats.get(flat), bill, realCons);
				totalCons += realCons;

			}
			totalPrice += price;
			price += bill.getFixedCost() / flats.size();
			bill.addShare(new Share(flats.get(flat), totalCons, price));
		}
		updateShare(bill, totalPrice);
	}

	private void updateShare(Bill bill, double totalPrice) {
		double update = (bill.getVariableCost() - totalPrice) / flats.size();
		for (Share q : bill.getShares()) {
			q.addCorrection(update);
		}

	}

	// inizio parte DA REALIZZARE------------------
	private void computeMonthlyCost(Bill bill) {
		if (bill.getMonth().isEmpty()) {
			throw new IllegalArgumentException("Mese non specificato nella bolletta");
		}

		double totalPrice = 0;
		int index = bill.getMonth().get().getValue() - 1;

		for (String flat : flats.keySet()) {
			double realCons = gasConsumption.get(flat).get(index);

			double price = this.getMonthlyCostForFlat(flats.get(flat), bill, realCons);
			totalPrice += price;
			price += bill.getFixedCost() / flats.size();

			bill.addShare(new Share(flats.get(flat), realCons, price));
		}
		updateShare(bill, totalPrice);
	}

	private double getMonthlyCostForFlat(Flat flat, Bill bill, double realCons) {
		double maxCons = flat.getMaxConsumption();
		double standard, extra;
		if (realCons > maxCons) {
			standard = maxCons;
			extra = realCons - maxCons;
		} else {
			standard = realCons;
			extra = 0;
		}
		return standard * bill.getCostM3() + extra * bill.getExtraCostM3();
	}
	// fine parte DA REALIZZARE------------------

	@Override
	public double getMonthlyTotalConsumption(int index) {
		double total = 0;
		for (String flat : flats.keySet()) {
			total += gasConsumption.get(flat).get(index);
		}
		return total;
	}

	@Override
	public double getAnnualTotalConsumption() {
		double total = 0;

		for (int i = 0; i < 12; i++) {
			total += getMonthlyTotalConsumption(i);
		}

		return total;
	}

	// inizio parte DA REALIZZARE------------------
	@Override
	public double getDiffCons(Bill bill) {
		double realCons;
		if (bill.getBillingFrequency().equals(BillingFrequency.ANNUAL)) {
			realCons = getAnnualTotalConsumption();
		} else {
			int index = bill.getMonth().get().getValue() - 1;
			realCons = getMonthlyTotalConsumption(index);
		}
		return (bill.getConsumption() - realCons);
	}
	// fine parte DA REALIZZARE------------------


}
