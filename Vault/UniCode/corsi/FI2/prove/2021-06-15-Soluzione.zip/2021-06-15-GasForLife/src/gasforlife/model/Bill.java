package gasforlife.model;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public class Bill {
	private List<Share> quotes;
	private BillingFrequency billFreq;
	private double total;
	private double fixedCost;
	private double variableCost;
	private double consumption;
	private double costM3;
	private double extraCostM3;
	private Optional<Month> month;

	public Bill(BillingFrequency billFreq, double total, double fixedCost, double variableCost, double consumption, double costM3, double extraCostM3, Optional<Month> month) {
		for (Object notNull : new Object[] { billFreq, month }) {
			if (notNull == null) {
				throw new IllegalArgumentException("Parametri nulli");
			}
		}
		for (double greaterThanZero : new double[] { total, fixedCost, variableCost, consumption, costM3, extraCostM3 }) {
			if (greaterThanZero <= 0) {
				throw new IllegalArgumentException("Paramentri negativi o uguali a 0");
			}
		}

		this.billFreq = billFreq;
		this.total = total;
		this.fixedCost = fixedCost;
		this.variableCost = variableCost;
		this.consumption = consumption;
		this.costM3 = costM3;
		this.extraCostM3 = extraCostM3;
		this.month = month;
		this.quotes = new ArrayList<Share>();
	}

	public double getConsumption() {
		return consumption;
	}

	public boolean addShare(Share quote) {
		return this.quotes.add(quote);

	}

	private String getMonthAsString() {
		if (month.isPresent()) {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMMM").withLocale(Locale.ITALIAN);
			LocalDate date = LocalDate.of(2021, month.get(), 1);
			return dtf.format(date);
		} else
			return "mese non presente";

	}

	public Optional<Month> getMonth() {
		return month;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Bolletta ");
		sb.append(this.billFreq.equals(BillingFrequency.ANNUAL) ? "annuale " : "mensile ");
		if (month.isPresent())
			sb.append(getMonthAsString());
		sb.append(System.lineSeparator());
		sb.append(" Costo fisso: " + this.fixedCost);
		sb.append(System.lineSeparator());
		sb.append(" Costo variabile: " + this.variableCost);
		sb.append(System.lineSeparator());
		sb.append(" Consumo complessivo: " + this.consumption);
		sb.append(" Costo normale consumo al m3: " + costM3);
		sb.append(" Costo extra consumo al m3: " + extraCostM3);
		sb.append(System.lineSeparator());
		quotes.sort(Comparator.comparing(x -> x.getFlat().getId()));
		for (Share q : quotes) {
			sb.append(q.toString());
			sb.append(System.lineSeparator());
		}

		return sb.toString();
	}

	public List<Share> getShares() {
		return quotes;
	}

	public BillingFrequency getBillingFrequency() {
		return billFreq;
	}

	public double getValue() {
		return total;
	}

	public double getFixedCost() {
		return fixedCost;
	}

	public double getVariableCost() {
		return variableCost;
	}

	public double getCostM3() {
		return costM3;
	}

	public double getExtraCostM3() {
		return extraCostM3;
	}
}
