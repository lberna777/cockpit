package gasforlife.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyConsumptionReader implements ConsumptionReader {
	private static final double Fattore_Conversione = 10.69;
	private Map<String, List<Double>> gasConsumption;
	
	public MyConsumptionReader(Reader reader) throws IOException, BadFileFormatException {
		 gasConsumption = new HashMap<String, List<Double>>();
		 
		 loadAllItems(reader);
	 }
	 
	 
		@Override
		public Map<String, List<Double>> getItems() {
			return gasConsumption;
		}

		
		private void loadAllItems(Reader reader) throws IOException, BadFileFormatException {
			BufferedReader buffreader = new BufferedReader(reader);
			String line;
			while((line=buffreader.readLine())!=null) {
				if(line.trim().length()==0) continue;
				String[] items = line.trim().split("\\s:");
				if (items.length!=2){
					throw new BadFileFormatException("Wrong number of items in line: " + line);
				}
				String sensore = items[0].trim();
				String[] letture = items[1].trim().split("\\|");
				if (letture.length!=12){
					throw new BadFileFormatException("Wrong number of items in line: " + line);
				}
				ArrayList<Double> valoriLetture= new ArrayList<Double>();
				for(String x : letture) {
				   try {
					   valoriLetture.add(Double.parseDouble(x.trim())/Fattore_Conversione);
				   }
				   catch(NumberFormatException e) {
					   throw new BadFileFormatException("Wrong elements of items in line: " + line);
				   }
				}
				gasConsumption.put(sensore, valoriLetture);
				
			}

		}
	
		
		
}
