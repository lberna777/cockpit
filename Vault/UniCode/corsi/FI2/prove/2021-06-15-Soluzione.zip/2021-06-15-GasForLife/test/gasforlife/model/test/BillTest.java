package gasforlife.model.test;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Month;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;

import gasforlife.model.Bill;
import gasforlife.model.Flat;
import gasforlife.model.Share;
import gasforlife.model.BillingFrequency;

public class BillTest {
	@Test
	public void testOK_1() {
		Bill bill = new Bill(BillingFrequency.ANNUAL, 1d, 2d, 3d, 4d, 5d, 6d, Optional.of(Month.MARCH));
		Assert.assertEquals(BillingFrequency.ANNUAL, bill.getBillingFrequency());
		Assert.assertEquals(1d, bill.getValue(), 0.01);
		Assert.assertEquals(2d, bill.getFixedCost(), 0.01);
		Assert.assertEquals(3d, bill.getVariableCost(), 0.01);
		Assert.assertEquals(4d, bill.getConsumption(), 0.01);
		Assert.assertEquals(5d, bill.getCostM3(), 0.01);
		Assert.assertEquals(6d, bill.getExtraCostM3(), 0.01);
		Assert.assertEquals(Month.MARCH, bill.getMonth().get());
	}

	@Test
	public void testOK_2() {
		Bill bill = new Bill(BillingFrequency.MONTHLY, 1d, 2d, 3d, 4d, 5d, 6d, Optional.empty());
		Assert.assertEquals(BillingFrequency.MONTHLY, bill.getBillingFrequency());
		Assert.assertEquals(1d, bill.getValue(), 0.01);
		Assert.assertEquals(2d, bill.getFixedCost(), 0.01);
		Assert.assertEquals(3d, bill.getVariableCost(), 0.01);
		Assert.assertEquals(4d, bill.getConsumption(), 0.01);
		Assert.assertEquals(5d, bill.getCostM3(), 0.01);
		Assert.assertEquals(6d, bill.getExtraCostM3(), 0.01);
		Assert.assertTrue(bill.getMonth().isEmpty());
	}

	@Test
	public void testShares() {
		Bill bill = new Bill(BillingFrequency.MONTHLY, 1d, 2d, 3d, 4d, 5d, 6d, Optional.empty());
		Assert.assertEquals(0, bill.getShares().size());
		Share q1 = new Share(new Flat("1", 100d, "Test"), 0, 0);
		bill.addShare(q1);
		Assert.assertEquals(1, bill.getShares().size());
		Assert.assertEquals(q1, bill.getShares().get(0));
	}

	@Test
	public void testKO_NullBillingFrequency() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(null, 1d, 1d, 1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeTotal() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, -1d, 1d, 1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroTotal() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 0, 1d, 1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeFixedCost() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, -1d, 1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroFixedCost() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 0, 1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeVariableCost() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, -1d, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroVariableCost() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 0, 1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeConsumption() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, -1d, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroConsumption() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 0, 1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeCostM3() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 1d, -1d, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroCostM3() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 1d, 0, 1d, Optional.empty());
		});
	}

	@Test
	public void testKO_NegativeExtraCostM3() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 1d, 1d, -1d, Optional.empty());
		});
	}

	@Test
	public void testKO_ZeroExtraCostM3() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 1d, 1d, 0, Optional.empty());
		});
	}

	@Test
	public void testKO_NullOptionalMonth() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Bill(BillingFrequency.ANNUAL, 1d, 1d, 1d, 1d, 1d, 1d, null);
		});
	}

}
