package trainstats.model;

import java.util.List;
import java.util.Map;
import java.time.Duration;
import java.util.HashMap;
import java.util.stream.Collectors;

public class Train {	
	private List<Recording> recordings;
	private Map<String,Recording> recordingMap; // (Station,Recording)
	private Map<String,Long> delayMap; 			// (Station,Delay) // per ipotesi, esclude la prima stazione
	private String firstStation, lastStation;
	
	public Train(List<Recording> recordings) {
		if (recordings==null) throw new IllegalArgumentException("la lista delle rilevazioni non può essere null");
		if (recordings.size()<2) throw new IllegalArgumentException("la lista delle rilevazioni deve contenere almeno due voci");
		//
		this.recordings = recordings;
		this.recordingMap = new HashMap<>();
		this.delayMap = new HashMap<>();
		var initialRecording = recordings.get(0);
		var finalRecording =   recordings.get(recordings.size()-1);
		this.firstStation = initialRecording.getStation();
		this.lastStation = finalRecording.getStation();
		//
		if(initialRecording.getScheduledArrivalTime().isPresent() || initialRecording.getActualArrivalTime().isPresent()) 
			throw new IllegalArgumentException("la stazione iniziale non può specificare orari di arrivo");
		if(finalRecording.getScheduledDepartureTime().isPresent() || finalRecording.getActualDepartureTime().isPresent()) 
			throw new IllegalArgumentException("la stazione finale non può specificare orari di partenza");
		//
		for (Recording r:recordings) {
			recordingMap.put(r.getStation(), r);
			if (!r.getStation().equals(firstStation))
				delayMap.put(r.getStation(), 
						Math.max(0,
						Duration.between(r.getScheduledArrivalTime().get(),r.getActualArrivalTime().get()).toMinutes()) );
		}
	}

	@Override
	public String toString() {
		return  String.format("%-20s%8s%8s%8s%8s%n", "stazione", "a.p.","a.r.","p.p.","p.r.") + 
				recordings.stream().map(Recording::toString).collect(Collectors.joining(System.lineSeparator()));
	}

	public List<Recording> getRecordings() {
		return recordings;
	}

	public Map<String, Recording> getRecordingMap() {
		return recordingMap;
	}

	public Map<String, Long> getDelayMap() {
		return delayMap;
	}
	
	public String getFirstStation() {
		return firstStation;
	}

	public String getLastStation() {
		return lastStation;
	}
	
	
}
