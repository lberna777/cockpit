package trainstats.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;

import trainstats.model.Train;
import trainstats.model.Recording;


public class MyTrainReader implements TrainReader {

	/*
	 * 	stazione;arrivo previsto;arrivo effettivo;partenza prevista;partenza effettiva
	 * 
		MILANO CENTRALE		;--   ;--   ;13:20;13:54
		MILANO LAMBRATE		;13:26;13:59;13:27;14:01
		MILANO ROGOREDO		;13:31;14:05;13:32;14:07
		LODI           		;13:46;14:21;13:47;14:22
		CASALPUSTERLENGO	;13:57;14:34;13:58;14:36
		PIACENZA       		;14:12;14:45;14:14;14:48
		FIORENZUOLA    		;14:26;14:58;14:27;14:59
		FIDENZA        		;14:35;15:06;14:37;15:07
		PARMA          		;14:58;15:18;15:00;15:19
		SANT'ILARIO    		;15:07;15:25;15:08;15:27
		REGGIO EMILIA  		;15:18;15:36;15:20;15:38
		RUBIERA        		;15:27;15:43;15:28;15:45
		MODENA         		;15:36;15:54;15:38;15:57
		CASTELFRANCO EMILIA	;15:45;16:02;15:46;16:04
		SAMOGGIA       		;15:51;16:09;15:52;16:09
		ANZOLA         		;15:56;16:13;15:57;16:14
		BOLOGNA C.LE   		;16:10;16:24;--   ;--		
		...
	*/

	private DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);
	
	@Override
	public Train readTrain(Reader rdr) throws IOException {
		
		if (rdr==null) throw new IllegalArgumentException("reader is null");
		BufferedReader reader = new BufferedReader(rdr);
		
		List<Recording> recordings = new ArrayList<>(); 
		
		String line;
		while((line = reader.readLine())!=null) {
			if (line.isBlank()) continue; // skip blank lines
			
			String[] items = line.split(";+");
			// ci sono sempre 5 elementi
			if (items.length!=5) throw new BadFileFormatException("Riga mal formattata, non ha 5 elementi:\t" + line);

			// il primo è una stringa, gli altri 4 sono orari (tranne i casi con "--") e vanno convertiti
			String stationName = items[0].trim();
			List<Optional<LocalTime>> timesList = new ArrayList<>();
			for (int i=1; i<5; i++) {
				String timeAsString = items[i].trim();
				try {
					timesList.add( timeAsString.contains("--") ? Optional.empty() : Optional.of(formatter.parse(timeAsString, LocalTime::from)) );
				}
				catch(DateTimeParseException e) {
					throw new BadFileFormatException("Orario mal formattato in riga:\t" + line);				
				}
				
			}
			try {
				recordings.add(new Recording(stationName, timesList.get(0), timesList.get(1), timesList.get(2), timesList.get(3)));
			}
			catch(IllegalArgumentException e) {
				throw new BadFileFormatException("Recording mal formattata in riga:\t" + line);
			}
		}
		return new Train(recordings);
	}

}