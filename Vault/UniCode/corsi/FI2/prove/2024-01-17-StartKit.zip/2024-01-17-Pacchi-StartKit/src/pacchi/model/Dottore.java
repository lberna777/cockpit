package pacchi.model;

public class Dottore {

	private StatoPartita statoPartita;
	
	public Dottore(StatoPartita statoPartita) {
		this.statoPartita = statoPartita;
	}
	
	public Risposta interpella() {
		// ***************
		// ****DA FARE****
		// Specifica: il Dottore offre sempre fra 1/4 della media e la media dei premi rimasti
		// Sintetizzare la risposta del Dottore che incapsula il Valore offerto
		// ***************
		return new Risposta(new Valore(1)); // FAKE, DA FARE
	}

	public StatoPartita getStatoPartita() { // metodo presente solo per motivi di test
		return statoPartita;
	}
	
	public int media() { // metodo reso pubblico solo per motivi di test
		// ***************
		// ****DA FARE****
		// Restituisce la media dei premi dei pacchi ancora da aprire, trasformata in int
		// L'elenco dei pacchi da aprire è recuperabile tramite i metodi di StatoPartita:
		// - getPacchiDaAprire, che restituisce l'insieme dei pacchi ancora da aprire in possesso
		//   dei partecipanti (escluso quindi quello in mano al concorrente)
		// - getPaccoConcorrente, che restituisce ovviamente il solo pacco del concorrente.
		// ***************		
		return 10; // FAKE, da implementare
	}
			
}
