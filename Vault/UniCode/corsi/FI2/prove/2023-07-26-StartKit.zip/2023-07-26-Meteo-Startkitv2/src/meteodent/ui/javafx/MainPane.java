package meteodent.ui.javafx;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Set;

import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import meteodent.controller.Controller;
import meteodent.model.TipoBollettino;


public class MainPane extends BorderPane {
	
	private Controller controller;
	
	private ComboBox<String> localitaCombo;
	private ComboBox<LocalDate> dateCombo;
	private TextArea outputArea;
	private Button buttonDettagliato, buttonSintetico;
	

	public MainPane(Controller controller) {
		this.controller=controller;
		//
		VBox leftBox = new VBox();
		leftBox.setPrefWidth(200);
			HBox miniBoxIniziale = new HBox(); miniBoxIniziale.setAlignment(Pos.CENTER);
			Label titolino = new Label("Meteo Dent");
			titolino.setStyle("-fx-font-weight: bold");
			miniBoxIniziale.getChildren().addAll(titolino);
			leftBox.getChildren().addAll(new Label("  "), miniBoxIniziale, new Label("  "));
			//
			localitaCombo = new ComboBox<>(FXCollections.observableList(controller.getListaLocalita()));
			localitaCombo.setTooltip(new Tooltip("Scegliere la località"));
			localitaCombo.setPrefWidth(175);
			localitaCombo.setValue(localitaCombo.getItems().get(0));
			leftBox.getChildren().addAll(new Label(" Località:  "), localitaCombo);
			//
			// AGGANCIARE ALLA COMBO IL GESTORE EVENTI
			//
			//
			dateCombo = new ComboBox<>();
			populateDateCombo();
			dateCombo.setTooltip(new Tooltip("Scegliere la data desiderata"));
			dateCombo.setPrefWidth(175);
			dateCombo.setValue(dateCombo.getItems().get(0));
			leftBox.getChildren().addAll(new Label(" Data:  "), dateCombo);
			//
			buttonDettagliato = new Button("Bollettino dettagliato");
			// AGGANCIARE AL BOTTONE IL GESTORE EVENTI
			buttonSintetico = new Button("Bollettino sintetico");
			// AGGANCIARE AL BOTTONE IL GESTORE EVENTI
			leftBox.getChildren().addAll(buttonDettagliato,buttonSintetico);
			//
			this.setLeft(leftBox);
		VBox rightBox = new VBox();
			rightBox.setPrefWidth(580);
			outputArea = new TextArea();
			outputArea.setPrefSize(580,500);
			outputArea.setFont(Font.font("Courier New", FontWeight.NORMAL, 11));
			outputArea.setEditable(false);
			rightBox.getChildren().addAll(outputArea);
		this.setRight(rightBox);
	}

	private void populateDateCombo() {
		// DA IMPLEMENTARE
		// Recupera la località, recupera tramite il controller le date che la riguardano, 
		// e preimposta il primo item come selezione di default 
	}
	
	private void showPrevisione(TipoBollettino tipo) {
		// DA IMPLEMENTARE
		// Recupera dalle due combo i dati necessari a far generare al Controller 
		// il Bollettino del tipo richiesto, mostrandone l’output sull’area
	}
}
