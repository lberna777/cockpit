package meteodent.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

public class MyGeneratoreBollettino implements GeneratoreBollettino {

	@Override
	public Bollettino generaBollettino(List<Previsione> previsioni, TipoBollettino tipoBollettino) {
		// DA IMPLEMENTARE
		return null; // FAKE, SOSTITUIRE CON IMPLEMENTAZIONE EFFETTIVA
	}
	
}
