package meteodent.persistence;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import meteodent.model.Previsione;
import meteodent.model.ProbPioggia;
import meteodent.model.Temperatura;

public class MyPrevisioniReader implements PrevisioniReader {
	
	private static final int    TOKEN_COUNT = 5;
	private static final String SEPARATOR = ",";
	private static final String DEGREE_SYMBOL = "°";
	private static final String PERCENT_SYMBOL = "%";

	@Override
	public Map<String, SortedSet<Previsione>> leggiPrevisioni(Reader reader) throws IOException, BadFileFormatException {
		// Si consiglia di incapsulare nel metodo privato leggiSingolaPrevisione (sotto)
		// la logica di lettura della singola previsione per una data città, giorno e ora
		// In tal modo, questo metodo dovrà concentrarsi solo sulla logica generale
		return null; // FAKE, DA IMPLEMENTARE
	}

	private Previsione leggiSingolaPrevisione(BufferedReader reader) throws IOException, BadFileFormatException {
		// metodo privato fortemente consigliato per disaccoppiare il problema
		return null; // FAKE, DA IMPLEMENTARE
	}

}
