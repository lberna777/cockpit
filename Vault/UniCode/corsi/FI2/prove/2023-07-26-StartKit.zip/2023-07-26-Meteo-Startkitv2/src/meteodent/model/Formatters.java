package meteodent.model;

import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class Formatters {
	// FAKE FORMATTERS, DA SOSTITUIRE CON QUELLI EFFETTIVI!!
	public static final DateTimeFormatter itDateFormatter = DateTimeFormatter.BASIC_ISO_DATE;
	public static final DateTimeFormatter dateFormatter = DateTimeFormatter.BASIC_ISO_DATE;
	public static final DateTimeFormatter datetimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
}
