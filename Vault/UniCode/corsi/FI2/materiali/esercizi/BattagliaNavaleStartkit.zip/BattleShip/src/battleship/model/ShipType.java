package battleship.model;

public enum ShipType {
	
}
