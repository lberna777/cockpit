package battleship.model;

public enum Orientation {
	
}
