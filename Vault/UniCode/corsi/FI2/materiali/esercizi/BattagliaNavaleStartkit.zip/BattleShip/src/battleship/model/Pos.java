package battleship.model;

public record Pos(int row, int col) {
	
}
