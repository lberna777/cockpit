package media.filters;

import media.*;

public class GenreFilter implements Filter {
	private String genre = null;

	public GenreFilter(String genre) {
		setGenre(genre);
	}

	public void setGenre(String genre) {
		this.genre = genre.trim();
	}

    
	@Override
	public boolean filter(Media media) {
		 if (media instanceof HasGenre hg) 
		 {	 
		 return this.genre.isEmpty() || (hg.getGenre().equals(this.genre));
		 }
		 return false;
	}
}
