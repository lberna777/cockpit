package persistence;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import media.collection.MediaCollection;

public class MyMediaPersister implements MediaPersister {
	private static final String FILE_PATH = "Media.bin";
	
	@Override
	public MediaCollection load() throws FileNotFoundException, IOException, ClassNotFoundException {
		try (FileInputStream input = new FileInputStream(FILE_PATH)) {
			try (ObjectInputStream ois = new ObjectInputStream(input)) {
				return (MediaCollection) ois.readObject();
			}
		}
	}

	@Override
	public void save(MediaCollection medias) throws FileNotFoundException, IOException {
		try (FileOutputStream output = new FileOutputStream(FILE_PATH)) {
			try (ObjectOutputStream oos = new ObjectOutputStream(output)) {
				oos.writeObject(medias);
			}
		}
	}

}
