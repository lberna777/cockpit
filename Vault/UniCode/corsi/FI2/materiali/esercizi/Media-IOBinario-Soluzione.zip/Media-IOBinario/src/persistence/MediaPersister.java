package persistence;

import java.io.FileNotFoundException;
import java.io.IOException;

import media.collection.MediaCollection;


public interface MediaPersister {
	MediaCollection load() throws FileNotFoundException, IOException, ClassNotFoundException;
	void save(MediaCollection medias) throws FileNotFoundException, IOException;
}
