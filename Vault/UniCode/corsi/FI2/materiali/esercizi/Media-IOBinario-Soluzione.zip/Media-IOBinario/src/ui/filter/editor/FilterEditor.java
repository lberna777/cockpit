package ui.filter.editor;

import media.filters.Filter;

public interface FilterEditor {
	Filter create();
}
