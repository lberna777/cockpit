package controller;

import java.io.FileNotFoundException;
import java.io.IOException;

import media.Media;
import media.collection.MediaCollection;
import media.filters.Filter;
import persistence.MediaPersister;

public class MyMediaController implements MediaController {
	private MediaCollection allMedias = null;
	MediaPersister persister = null;

	public MyMediaController(MediaPersister persister) {
		this.persister = persister;
		try {
			allMedias = this.persister.load();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			allMedias = new MediaCollection();			
		}
	}

	public boolean add(Media m) {
		if (allMedias.indexOf(m) >= 0)
			return false;

		allMedias.add(m);
		saveAll();
		return true;
	}

	private void saveAll() {
		try {
			this.persister.save(allMedias);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean remove(Media media) {
		int position = allMedias.indexOf(media);
		if (position >= 0) {
			allMedias.remove(position);
			saveAll();
			return true;
		}
		return false;
	}

	public MediaCollection getAll() {
		MediaCollection me = new MediaCollection(allMedias.size());
		for (int i = 0; i < allMedias.size(); i++) {
			me.add(allMedias.get(i));
		}

		return me;
	}

	public MediaCollection find(Filter f) {
		MediaCollection result = new MediaCollection();
		for (int i = 0; i < allMedias.size(); i++) {
			Media media = allMedias.get(i);
			if (f.filter(media)) {
				result.add(media);
			}
		}
		return result;
	}

}
