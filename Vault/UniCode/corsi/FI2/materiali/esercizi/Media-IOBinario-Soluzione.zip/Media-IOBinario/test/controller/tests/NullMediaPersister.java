package controller.tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import media.collection.MediaCollection;
import persistence.MediaPersister;

public class NullMediaPersister implements MediaPersister {

	@Override
	public MediaCollection load() throws FileNotFoundException, IOException, ClassNotFoundException {
		return new MediaCollection(100);
	}

	@Override
	public void save(MediaCollection medias) throws FileNotFoundException, IOException {
	}

}
