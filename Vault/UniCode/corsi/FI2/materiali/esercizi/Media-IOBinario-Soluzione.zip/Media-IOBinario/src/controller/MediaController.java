package controller;

import media.Media;
import media.collection.MediaCollection;
import media.filters.Filter;
public interface MediaController {

	boolean add(Media m);

	boolean remove(Media media);

	MediaCollection getAll();

	MediaCollection find(Filter f);

}
