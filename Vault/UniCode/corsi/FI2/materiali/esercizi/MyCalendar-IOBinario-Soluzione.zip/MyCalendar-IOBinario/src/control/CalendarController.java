package control;

import java.time.LocalDate;

import model.Appointment;
import model.AppointmentCollection;

public interface CalendarController {

	// aggiungo un nuovo appuntamento
	boolean add(Appointment app);

	boolean remove(Appointment app);

	AppointmentCollection getDayAppointments(LocalDate date);

	AppointmentCollection getMonthAppointments(LocalDate date);

	AppointmentCollection getWeekAppointments(LocalDate date);

	AppointmentCollection getAllAppointments();

}