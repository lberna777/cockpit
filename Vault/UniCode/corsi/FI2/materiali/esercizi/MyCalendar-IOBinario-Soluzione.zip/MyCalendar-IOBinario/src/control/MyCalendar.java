package control;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import model.Appointment;
import model.AppointmentCollection;
import persistence.CalendarPersister;

public class MyCalendar implements CalendarController {
	private AppointmentCollection allAppointments;
	private CalendarPersister persister;

	public MyCalendar(CalendarPersister persister) {
		allAppointments = new AppointmentCollection(100);
		this.persister = persister;
		
		try {
			AppointmentCollection loaded = persister.load();
			for (int i = 0; i < loaded.size(); i++) {
				allAppointments.add(loaded.get(i));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@Override
	public boolean add(Appointment app) {		
		allAppointments.add(app);
		saveAll();
		return true;
	}

	private void saveAll() {
		try {
			persister.save(allAppointments);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Override
	public boolean remove(Appointment app) {
		int position = allAppointments.indexOf(app);
		if (position >= 0) {
			allAppointments.remove(position);
			saveAll();
			return true;
		}
		return false;
	}

	private boolean isOverlapped(LocalDateTime start, LocalDateTime end, 
			LocalDateTime refStart, LocalDateTime refEnd) {
//		return !(end.isBefore(refStart) || start.isAfter(refEnd) || start.isEqual(refEnd));
		return (start.isAfter(refStart) || start.isEqual(refStart)) && start.isBefore(refEnd) ||
			   (end.isAfter(refStart) || end.isEqual(refStart)) && end.isBefore(refEnd) ||
			   (start.isBefore(refStart) && end.isAfter(refStart));
	}

	private AppointmentCollection getAppointmentsIn(LocalDateTime start, LocalDateTime end) {
		AppointmentCollection appList = new AppointmentCollection(
				allAppointments.size());
		for (int i = 0; i < allAppointments.size(); i++) {
			Appointment app = allAppointments.get(i);
			if (isOverlapped(app.getFrom(), app.getTo(), start, end)) {
				appList.add(app);
			}
		}
		return appList;
	}

	
	@Override
	public AppointmentCollection getDayAppointments(LocalDate date) {
		LocalDateTime dayStart = LocalDateTime.of(date, LocalTime.of(0, 0));
		LocalDateTime dayEnd = dayStart.plusDays(1);
		return getAppointmentsIn(dayStart, dayEnd);
	}

	
	@Override
	public AppointmentCollection getMonthAppointments(LocalDate date) {
		LocalDate firstDayOfMonth = date.withDayOfMonth(1);
		LocalDateTime monthStart = LocalDateTime.of(firstDayOfMonth, LocalTime.of(0, 0));
		LocalDateTime monthEnd = monthStart.plusMonths(1);
		return getAppointmentsIn(monthStart, monthEnd);
	}

	
	@Override
	public AppointmentCollection getWeekAppointments(LocalDate date) {
		long distanceFromPastMonday = date.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue();
		LocalDate weekStartDate = date.minusDays(distanceFromPastMonday);
		LocalDateTime weekStart = LocalDateTime.of(weekStartDate, LocalTime.of(0, 0));
		LocalDateTime weekEnd = weekStart.plusWeeks(1);

		return getAppointmentsIn(weekStart, weekEnd);
	}

	
	@Override
	public AppointmentCollection getAllAppointments() {
		AppointmentCollection appCollection = new AppointmentCollection(
				allAppointments.size());
		for (int i = 0; i < allAppointments.size(); i++) {
			appCollection.add(allAppointments.get(i));
		}
		return appCollection;
	}

}
