package persistence;

import java.io.FileNotFoundException;
import java.io.IOException;

import model.AppointmentCollection;

public interface CalendarPersister {
	AppointmentCollection load() throws FileNotFoundException, IOException, ClassNotFoundException;
	void save(AppointmentCollection appointments) throws FileNotFoundException, IOException, ClassNotFoundException;	
}
