package control.tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import model.AppointmentCollection;
import persistence.CalendarPersister;


public class NullCalendarPersister implements CalendarPersister {

	@Override
	public AppointmentCollection load() throws FileNotFoundException, IOException {
		return new AppointmentCollection(0);
	}

	@Override
	public void save(AppointmentCollection appointments) throws FileNotFoundException, IOException {
	}

}
