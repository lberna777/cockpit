package persistence;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import model.AppointmentCollection;

public class MyCalendarPersister implements CalendarPersister {
	private static final String FILE_PATH = "Calendar.bin";

	@Override
	public AppointmentCollection load() throws FileNotFoundException, IOException, ClassNotFoundException {
		try (FileInputStream input = new FileInputStream(FILE_PATH)) {
			try (ObjectInputStream ois = new ObjectInputStream(input)) {
				return (AppointmentCollection) ois.readObject();
			}
		}
	}

	@Override
	public void save(AppointmentCollection appColl) throws FileNotFoundException, IOException {
		try (FileOutputStream output = new FileOutputStream(FILE_PATH)) {
			try (ObjectOutputStream oos = new ObjectOutputStream(output)) {
				oos.writeObject(appColl);
			}
		}
	}
}
