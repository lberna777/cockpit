package battleship.model;

public class Ship {
	private ShipType type;
	private int integrity;
	private String name;
	private Orientation orientation;
	private Pos pos;
	
	public Ship(ShipType type, Pos pos, Orientation orientation, String name) {
		// occorrerebbe verificare che gli argomenti non siano nulli
		// e potenzialmente anche che il nome attribuito sia univoco
		this.type=type;
		this.name=name;
		this.pos=pos;
		this.orientation=orientation;
		this.integrity=type.getLength();
	}
	
	public ShipType getType() {
		return type;
	}

	public int getIntegrity() {
		return integrity;
	}
	
	public ShotResult decreaseIntegrity() {
		integrity--;
		return switch(Integer.valueOf(integrity)) {
			case 0 -> ShotResult.AFFONDATO;
			case Integer i -> i>0 ? ShotResult.COLPITO : null; 
		};
	}

	public String getName() {
		return name;
	}

	public Orientation getOrientation() {
		return orientation;
	}
	
	public Pos[] getPositions() {
		Pos[] result = new Pos[this.type.getLength()];
		for(int i=0; i<this.type.getLength(); i++)
			result[i] = pos.next(orientation, i);
		return result;
	}

	public Pos getPos() {
		return pos;
	}
	
	public Pos getLastPos() {
		return pos.next(orientation, type.getLength()-1);
	}

	@Override
	public String toString() {
		return type + " " + name + " da " + pos + " a " + pos.next(getOrientation(), type.getLength()-1);
	}
	
	public boolean isOrientationEqualTo(Ship other) {
		return this.orientation==other.orientation;
	}
	
	public boolean overlaps(Pos pos) {
		return Pos.contains(this.getPositions(), pos);
	}
	
	public boolean overlaps(Ship other) {
		return Pos.findCommons(this.getPositions(), other.getPositions()).length>0;
	}
	
}
