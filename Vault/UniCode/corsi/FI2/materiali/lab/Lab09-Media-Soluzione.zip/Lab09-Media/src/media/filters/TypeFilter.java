package media.filters;

import media.Media;
import media.Type;

public class TypeFilter implements Filter {
	private Type typeToFind;

	public TypeFilter(Type typeToFind) {
		this.typeToFind = typeToFind;
	}

	public void setType(Type typeToFind) {
		this.typeToFind = typeToFind;
	}

	
	@Override
	public boolean filter(Media media) {
      return media.getType().equals(this.typeToFind);	
	}

}
