package fractioncollection;
import frazione.Frazione;

public class FractionCollection {
	private static final int DEFAULT_PHYSICAL_SIZE = 10;
	private static final int DEFAULT_GROWTH_FACTOR = 2;
	
	private Frazione[] innerContainer;
	private int size;
	
	public FractionCollection(Frazione[] collection) {
		innerContainer = new Frazione[collection.length];
		size =0;
		for (int i = 0; i < collection.length; ++i) {
			
			if (collection[i] != null) {
				innerContainer[size] = collection[i];
				size++; 
				}
				}
		}
	
	public FractionCollection(int physicalSize) {
		innerContainer = new Frazione[physicalSize];
		size = 0;
	}
	
	public FractionCollection() {
		this(DEFAULT_PHYSICAL_SIZE);
	}
	
	public int size() {
		return size;
	}
	
	public void put(Frazione f) {
		if (innerContainer.length == size) {
			Frazione[] newContainer = new Frazione[size * DEFAULT_GROWTH_FACTOR];
			for (int i = 0; i < innerContainer.length; i++) {
				newContainer[i] = innerContainer[i];
			}
			innerContainer = newContainer;
		}
		innerContainer[size++] = f;
	}
	
	public void remove(int index) {
		if (index < 0 || index >= size)
			return;
		
		for (int i = index; i < size - 1; i++) {
			innerContainer[i] = innerContainer[i+1];
		}
		size--;
	}
	
	public Frazione get(int index) {
		if (index < 0 || index >= size)
			return null;
	
		return innerContainer[index];
	}
	
	public FractionCollection sum(FractionCollection collection) {
		if (size() != collection.size())
			return null;
		
		FractionCollection result = new FractionCollection(size());		
		for (int i = 0; i < size(); i++) {
			Frazione f = get(i).sum(collection.get(i));
			result.put(f);
		}		
		return result;
	}
	
	public FractionCollection mul(FractionCollection collection) {
		if (size() != collection.size())
			return null;
		
		FractionCollection result = new FractionCollection(size());		
		for (int i = 0; i < size(); i++) {
			Frazione f = get(i).mul(collection.get(i));
			result.put(f);
		}		
		return result;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < size(); i++) {
			sb.append(get(i).toString());
			if (i < size() - 1)
				sb.append(", ");
		}
		sb.append("]");
		return sb.toString();
	}
}
