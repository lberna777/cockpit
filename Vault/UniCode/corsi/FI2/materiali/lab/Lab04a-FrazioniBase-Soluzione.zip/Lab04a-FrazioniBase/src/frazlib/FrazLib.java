package frazlib;

import frazione.Frazione;

/**
 * Libreria funzioni statiche di Frazione
 * 
 * @author Fondamenti di Informatica T-2
 * @version March 2024
 */
public class FrazLib {
	
	public static Frazione sum(Frazione[] fs)
	{
		Frazione tmp = new Frazione(0, 1); // Elemento neutro
		for (Frazione f : fs)		
			tmp = tmp.sum(f);
		return tmp;   
	}	
	public static Frazione mul(Frazione[] fs)
	{
		Frazione tmp = new Frazione(1, 1); // Elemento neutro 
		for (Frazione f : fs)
			tmp = tmp.mul(f);
		return tmp;
	}

}
