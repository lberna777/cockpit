package agenda.persistence;

import agenda.model.Detail;
import agenda.model.DetailFactory;
import agenda.model.EMail;

public class EMailPersister implements DetailPersister {
	private final static String SEPARATOR = ";";

	@Override
	public Detail load(String[] tokens) throws BadFileFormatException{
		EMail email = (EMail) DetailFactory.of("Email");
		//controllo generale sul numero di token, si potrebbero affinare i controlli
		if(tokens.length!=3)
			throw new BadFileFormatException("Email: not enough tokens");
		email.setDescription(tokens[1]);
		email.setValue(tokens[2]);
		return email;
	}

	@Override
	public void save(Detail d, StringBuilder sb) {
		EMail p = (EMail) d;
		sb.append(p.getName());
		sb.append(SEPARATOR);
		sb.append(p.getDescription());
		sb.append(SEPARATOR);
		sb.append(p.getValue());
		sb.append(FileUtils.NEWLINE);
	}

}
