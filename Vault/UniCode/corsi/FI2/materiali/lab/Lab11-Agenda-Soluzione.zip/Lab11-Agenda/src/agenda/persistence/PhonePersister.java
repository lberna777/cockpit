package agenda.persistence;

import agenda.model.Detail;
import agenda.model.DetailFactory;
import agenda.model.Phone;

public class PhonePersister implements DetailPersister {
	private final static String SEPARATOR = ";";

	@Override
	public Detail load(String[] tokens) throws BadFileFormatException {
		Phone phone = (Phone) DetailFactory.of("Phone");
		//controllo generale sul numero di token, si potrebbero affinare i controlli
		if(tokens.length!=3)
			throw new BadFileFormatException("Phone: not enough tokens");
		phone.setDescription(tokens[1]);
		phone.setValue(tokens[2]);
		return phone;
	}

	@Override
	public void save(Detail d, StringBuilder sb) {
		Phone phone = (Phone) d;
		sb.append(phone.getName());
		sb.append(SEPARATOR);
		sb.append(phone.getDescription());
		sb.append(SEPARATOR);
		sb.append(phone.getValue());
		sb.append(FileUtils.NEWLINE);
	}

}
