package agenda.persistence;

import agenda.model.Address;
import agenda.model.Detail;
import agenda.model.DetailFactory;

public class AddressPersister implements DetailPersister {
	private final static String SEPARATOR = ";";

	@Override
	public Detail load(String[] tokens) throws BadFileFormatException{
		Address a = (Address) DetailFactory.of("Address");
		//controllo generale sul numero di token, si potrebbero affinare i controlli
		if(tokens.length!=7)
			throw new BadFileFormatException("Address: not enough tokens");
		a.setDescription(tokens[1]);
		a.setStreet(tokens[2]);
		a.setNumber(tokens[3]);
		a.setZipCode(tokens[4]);
		a.setCity(tokens[5]);
		a.setState(tokens[6]);
		return a;
	}

	@Override
	public void save(Detail d, StringBuilder sb) {
		Address a = (Address) d;
		sb.append(a.getName());
		sb.append(SEPARATOR);
		sb.append(a.getDescription());
		sb.append(SEPARATOR);
		sb.append(a.getStreet());
		sb.append(SEPARATOR);
		sb.append(a.getNumber());
		sb.append(SEPARATOR);
		sb.append(a.getZipCode());
		sb.append(SEPARATOR);
		sb.append(a.getCity());
		sb.append(SEPARATOR);
		sb.append(a.getState());
		sb.append(FileUtils.NEWLINE);
	}

}
