package edlift.model.util;

import java.util.Arrays;

public class Queue {
	private int maxBookings, booked;;
	private int[] bookings;
	
	public Queue(int maxBookings) {
		this.maxBookings=maxBookings;
		this.bookings = new int[maxBookings];
		this.booked=0;
	}
	
	public boolean insert(int n) {
		if(booked>=this.maxBookings) return false;
		this.bookings[booked++]=n;
			System.err.println(this);
		return true;
	}
	
	public int extract() {
		if(booked<=0) return Integer.MIN_VALUE;
		int res = this.bookings[0];
		for(int i=0; i<booked-1; i++)
			this.bookings[i]=this.bookings[i+1];
		booked--;
			System.err.println(this);
		return res;
	}
	
	public int peek() {
		if(booked<=0) return Integer.MIN_VALUE;
		return this.bookings[0];
	}
	
	public String toString() {
		return Arrays.toString(Arrays.copyOf(this.bookings, booked));
	}
	
	public boolean hasItems() {
		return booked>0;
	}
	
	public int size() {
		return booked;
	}
	
}