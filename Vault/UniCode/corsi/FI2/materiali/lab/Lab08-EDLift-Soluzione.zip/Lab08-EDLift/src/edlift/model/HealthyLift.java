package edlift.model;

public class HealthyLift extends Lift {
	
	// L'ascensore salutista non ti porta al piano richiesto, si ferma un piano prima
	
	public HealthyLift(int minFloor, int maxFloor, int initialFloor, double speed) {
		super(minFloor, maxFloor, initialFloor, speed);
    }

	@Override
	public RequestResult goToFloor(int floor){
		checkArrivalFloor(floor);
		// Come l'ascensore base, anche questo non accetta richieste mentre è in movimento
		if (getCurrentState()!=LiftState.REST) return RequestResult.REJECTED;
		else {
			int actualDestinationFloor=floor;
			RequestResult result;
			// MA a differenza dell'ascensore base, questo valuta se e dove portarti
			if (Math.abs(getCurrentFloor()-floor)<=1) {
				/*
				Controller.info("Healthy lift", "Unhealthy request", 
						"Your request is unhealthy: please use stairs");
						*/
				result = RequestResult.REJECTED;
				result.setMsg("rejected as unhealthy");
				result.setFloor(Integer.MIN_VALUE);
			}
			else {
				actualDestinationFloor = floor < getCurrentFloor() ? floor+1 : floor-1;
				/*
				Controller.info("Healthy lift", 
						"Will go to floor " + actualDestinationFloor + " instead",
						"You request has been modified for a healthier lifestyle");
						*/
				setRequestedFloor(actualDestinationFloor);
				result = RequestResult.MODIFIED;
				result.setMsg("modified to floor " + actualDestinationFloor);
				result.setFloor(actualDestinationFloor);
			}
			return result;
		}
	}

	@Override
	public String getMode() {
		return "Healthy";
	}

}
