package edlift.model;

public class BasicLift extends Lift {
	
	public BasicLift(int minFloor, int maxFloor, int initialFloor, double speed) {
		super(minFloor, maxFloor, initialFloor, speed);
    }

	@Override
	public RequestResult goToFloor(int floor){
		checkArrivalFloor(floor);
		// l'ascensore base non accetta richieste mentre è in movimento
		if (getCurrentState()!=LiftState.REST) return RequestResult.REJECTED;
		else setRequestedFloor(floor);
		return RequestResult.ACCEPTED;
	}
	
	@Override
	public String getMode() {
		return "Basic";
	}


}
