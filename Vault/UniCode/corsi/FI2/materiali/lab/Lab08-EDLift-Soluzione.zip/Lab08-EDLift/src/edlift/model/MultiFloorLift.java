package edlift.model;

import edlift.model.util.Queue;

public class MultiFloorLift extends Lift {
	
	private Queue queue;
	
	public MultiFloorLift(int minFloor, int maxFloor, int initialFloor, double speed) {
		super(minFloor, maxFloor, initialFloor, speed);
		queue = new Queue(4);
    }

	@Override
	public RequestResult goToFloor(int floor){
		checkArrivalFloor(floor);
		// A differenza degli altri, questo tipo di ascensore accetta richieste anche mentre è in movimento
		if (getCurrentState()!=LiftState.REST) {
			// inserisci prenotazione per il piano richiesto, da servire successivamente
			if(!queue.insert(floor)) {
				RequestResult result = RequestResult.REJECTED;
				result.setMsg("rejected because of too many pending requests");
				result.setFloor(Integer.MIN_VALUE);
				return result;
			} // altrimenti la prenotazione è stata accettata
			return RequestResult.ACCEPTED;
		}
		else {
				setRequestedFloor(floor);
				return RequestResult.ACCEPTED;
		}
	}

	@Override
	public String getMode() {
		return "Multi";
	}
	
	public int nextPendingFloor(LiftState state) {
		// questo ascensore ignora la direzione attuale dell'ascensore
		return queue.extract();
	}

	public boolean hasPendingFloors() {
		return queue.hasItems();
	}

}
