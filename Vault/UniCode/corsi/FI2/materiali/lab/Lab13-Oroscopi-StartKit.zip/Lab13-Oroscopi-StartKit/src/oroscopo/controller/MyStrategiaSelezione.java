package oroscopo.controller;

import java.util.List;
import oroscopo.model.Previsione;
import oroscopo.model.SegnoZodiacale;


public class MyStrategiaSelezione implements StrategiaSelezione {

	@Override
	public Previsione seleziona(List<Previsione> previsioni, SegnoZodiacale segno) {
		// DA IMPLEMENTARE
		return null;
	}

}
