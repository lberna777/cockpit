package oroscopo.ui;

import javafx.scene.layout.BorderPane;
import oroscopo.controller.AbstractController;

public class MainPane extends BorderPane {

	public MainPane(AbstractController controller, int fortunaMin) {
		// TODO Auto-generated constructor stub
	}
	
	// DA FARE TUTTO
}
