package oroscopo.model;

public class OroscopoMensile implements Oroscopo, Comparable<Oroscopo> {

	public OroscopoMensile(String string, Previsione previsione, Previsione previsione2, Previsione previsione3) {
		// costruttore ausiliario con primo argomento stringa
	}

	public OroscopoMensile(SegnoZodiacale acquario, Previsione previsione, Previsione previsione2, Previsione previsione3) {
		// costruttore primario
	}

	@Override
	public int compareTo(Oroscopo o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public SegnoZodiacale getSegnoZodiacale() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Previsione getPrevisioneAmore() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Previsione getPrevisioneSalute() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Previsione getPrevisioneLavoro() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getFortuna() {
		// TODO Auto-generated method stub
		return 0;
	}

}
