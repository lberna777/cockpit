package oroscopo.controller;


import java.io.IOException;

import oroscopo.model.Oroscopo;
import oroscopo.model.SegnoZodiacale;
import oroscopo.persistence.OroscopoRepository;

public class MyController extends AbstractController {

	private StrategiaSelezione strategiaSelezione;

	public MyController(OroscopoRepository myReader, StrategiaSelezione strategiaSelezione)throws IOException {
		super(myReader);
		this.strategiaSelezione = strategiaSelezione;
	}

	@Override
	public SegnoZodiacale[] getSegni() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Oroscopo[] generaOroscopoAnnuale(SegnoZodiacale segno, int fortunaMin) {
		// genera 12 oroscopi mensili e li compone in un oroscopo annuale, calcolandone anche la fortuna complessiva
		return null;
	}

	@Override
	public Oroscopo generaOroscopoCasuale(SegnoZodiacale segno) {
		// usa la strategia di selezione per ottenere le tre previsioni
		return null;
	}
}
