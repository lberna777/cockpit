package oroscopo.persistence;

import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.Set;
import oroscopo.model.Previsione;


public class TextFileOroscopoRepository implements OroscopoRepository {

	public TextFileOroscopoRepository(Reader reader) throws IOException, BadFileFormatException {
		// DA FARE
	}

	@Override
	public List<Previsione> getPrevisioni(String sezione) {
		// DA FARE
		return null; // FAKE
	}

	@Override
	public Set<String> getSettori() {
		// DA FARE
		return null; // FAKE
	}

}
