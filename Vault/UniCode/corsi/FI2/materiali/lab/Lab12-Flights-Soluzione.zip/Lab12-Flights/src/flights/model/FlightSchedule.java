package flights.model;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

public class FlightSchedule {

	private String code;
	private Airport departureAirport;
	private LocalTime departureLocalTime;
	private Airport arrivalAirport;
	private LocalTime arrivalLocalTime;
	private int dayOffset;
	private Set<DayOfWeek> daysOfWeek;
	private Aircraft aircraft;

	public FlightSchedule(String code, Airport departureAirport,
			LocalTime departureLocalTime, Airport arrivalAirport,
			LocalTime arrivalLocalTime, int dayOffset,
			Collection<DayOfWeek> daysOfWeek, Aircraft aircraft) {
		
		Objects.requireNonNull(code, "Codice volo non dev'essere nullo");
		Objects.requireNonNull(departureAirport, "Aeroporto di partenza non dev'essere nullo");
		Objects.requireNonNull(arrivalAirport, "Aeroporto di arrivo non dev'essere nullo");
		Objects.requireNonNull(departureLocalTime, "Orario di partenza non dev'essere nullo");
		Objects.requireNonNull(arrivalLocalTime, "Orario di arrivo non dev'essere nullo");
		Objects.requireNonNull(daysOfWeek, "Giorni di effettuazione non dev'essere nullo");
		Objects.requireNonNull(aircraft, "Aeromobile non dev'essere nullo");
				
		if(code.isEmpty()) {
			throw new IllegalArgumentException("FlightSchedule code vuoto");
		}
		
	
		
		OffsetDateTime departureUTC = OffsetDateTime.of(LocalDate.now(), 
				departureLocalTime, 
				ZoneOffset.ofHours(departureAirport.getCity().getTimeZone()));
		
		OffsetDateTime arrivalUTC = OffsetDateTime.of(LocalDate.now().plusDays(dayOffset), 
				arrivalLocalTime,
				ZoneOffset.ofHours(arrivalAirport.getCity().getTimeZone()));
		
		if(arrivalUTC.isBefore(departureUTC)) {
			throw new IllegalArgumentException(
					"Il volo " + code +" arriva prima di partire: arr. " + arrivalUTC + ", dep." + departureUTC);
		}
		
	
		
		if(dayOffset < -1 || dayOffset > 1) {
			throw new IllegalArgumentException("dayOffset non corretto");
		}
		
		if(daysOfWeek.isEmpty()) {
			throw new IllegalArgumentException("daysOfWeek non corretto");
		}
		
		this.code = code;
		this.departureAirport = departureAirport;
		this.departureLocalTime = departureLocalTime;
		this.arrivalAirport = arrivalAirport;
		this.arrivalLocalTime = arrivalLocalTime;
		this.dayOffset = dayOffset;
		this.daysOfWeek = new TreeSet<DayOfWeek>(daysOfWeek);
		this.aircraft = aircraft;
	}

	public String getCode() {
		return code;
	}

	public Airport getDepartureAirport() {
		return departureAirport;
	}

	public LocalTime getDepartureLocalTime() {
		return departureLocalTime;
	}

	public Airport getArrivalAirport() {
		return arrivalAirport;
	}

	public LocalTime getArrivalLocalTime() {
		return arrivalLocalTime;
	}
	
	public int getDayOffset() {
		return dayOffset;
	}

	public Set<DayOfWeek> getDaysOfWeek() {
		return daysOfWeek;
	}

	public Aircraft getAircraft() {
		return aircraft;
	}

	public Duration getFlightDuration() {
		OffsetDateTime departure = OffsetDateTime.of(LocalDate.now(), 
				departureLocalTime, 
				ZoneOffset.ofHours(getDepartureAirport().getCity().getTimeZone()));
		
		OffsetDateTime arrival = OffsetDateTime.of(LocalDate.now().plusDays(getDayOffset()), 
				arrivalLocalTime,
				ZoneOffset.ofHours(getArrivalAirport().getCity().getTimeZone()));
		
		Duration flightDuration = Duration.between(departure, arrival);
		if (flightDuration.isNegative()) {
			flightDuration = flightDuration.plusDays(1);
		}	
		return flightDuration;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aircraft == null) ? 0 : aircraft.hashCode());
		result = prime * result + ((arrivalAirport == null) ? 0 : arrivalAirport.hashCode());
		result = prime * result + ((arrivalLocalTime == null) ? 0 : arrivalLocalTime.hashCode());
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + dayOffset;
		result = prime * result + ((daysOfWeek == null) ? 0 : daysOfWeek.hashCode());
		result = prime * result + ((departureAirport == null) ? 0 : departureAirport.hashCode());
		result = prime * result + ((departureLocalTime == null) ? 0 : departureLocalTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightSchedule other = (FlightSchedule) obj;
		if (aircraft == null) {
			if (other.aircraft != null)
				return false;
		} else if (!aircraft.equals(other.aircraft))
			return false;
		if (arrivalAirport == null) {
			if (other.arrivalAirport != null)
				return false;
		} else if (!arrivalAirport.equals(other.arrivalAirport))
			return false;
		if (arrivalLocalTime == null) {
			if (other.arrivalLocalTime != null)
				return false;
		} else if (!arrivalLocalTime.equals(other.arrivalLocalTime))
			return false;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (dayOffset != other.dayOffset)
			return false;
		if (daysOfWeek == null) {
			if (other.daysOfWeek != null)
				return false;
		} else if (!daysOfWeek.equals(other.daysOfWeek))
			return false;
		if (departureAirport == null) {
			if (other.departureAirport != null)
				return false;
		} else if (!departureAirport.equals(other.departureAirport))
			return false;
		if (departureLocalTime == null) {
			if (other.departureLocalTime != null)
				return false;
		} else if (!departureLocalTime.equals(other.departureLocalTime))
			return false;
		return true;
	}
}
