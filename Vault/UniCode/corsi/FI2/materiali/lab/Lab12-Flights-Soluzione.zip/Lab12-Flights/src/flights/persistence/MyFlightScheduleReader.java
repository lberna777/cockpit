package flights.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import flights.model.*;

public class MyFlightScheduleReader implements FlightScheduleReader {

	private static final DateTimeFormatter timeFormatter = DateTimeFormatter
			// .ISO_TIME;
			.ofLocalizedTime(FormatStyle.SHORT).withLocale(Locale.ITALY);

	@Override
	public Collection<FlightSchedule> read(Reader reader, Map<String, Airport> airportMap,
			Map<String, Aircraft> aircraftMap) throws IOException, BadFileFormatException {
		BufferedReader bufferedReader = new BufferedReader(reader);
		ArrayList<FlightSchedule> schedules = new ArrayList<FlightSchedule>();

		FlightSchedule schedule;
		while ((schedule = readSchedule(bufferedReader, airportMap, aircraftMap)) != null) {
			schedules.add(schedule);
		}

		return schedules;
	}

	private FlightSchedule readSchedule(BufferedReader reader, 
									Map<String, Airport> airportMap, Map<String, Aircraft> aircraftMap) 
												throws IOException, BadFileFormatException {
		String line = reader.readLine();
		if (line == null || line.trim().isEmpty()) return null;

		String[] tokens = line.split(",");
		// check numero elemento in riga
		if(tokens.length!=8)
			throw new BadFileFormatException("Wrong number of items in line: " + line +", expected 8, found " + tokens.length);
		
		//#1: codice volo
		String code = tokens[0];
		
		//#2: aeroporto di partenza
		Airport departureAirport = airportMap.get(tokens[1]);
		if (departureAirport == null)
			throw new BadFileFormatException("Departure airport not present: " + tokens[1]);

		//#3: orario di partenza
		LocalTime departureLocalTime;
		try {
			departureLocalTime = LocalTime.parse(tokens[2], timeFormatter);
		}
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("Wrong departure time in line: " + line);
		}

		//#4: aeroporto di arrivo
		Airport arrivalAirport = airportMap.get(tokens[3]);
		if (arrivalAirport == null)
			throw new BadFileFormatException("Arrival airport not present: " + tokens[3]);

		//#5: orario di arrivo
		LocalTime arrivalLocalTime;
		try {
			arrivalLocalTime = LocalTime.parse(tokens[4], timeFormatter);
		}
		catch(DateTimeParseException e) {
			throw new BadFileFormatException("Wrong arrival time in line: " + line);
		}

		//#6: offset giorno di arrivo
		int dayOffset;
		try {
			dayOffset = Integer.parseInt(tokens[5]);
		}
		catch(NumberFormatException e) {
			throw new BadFileFormatException("Wrong day offset in line: " + line);
		}
		
		//#7: giorni di effettuazione
		Collection<DayOfWeek> daysOfWeek = readDaysOfWeek(tokens[6]);

		//#8: tipo di aeromobile
		Aircraft aircraft = aircraftMap.get(tokens[7]);
		if (aircraft == null)
			throw new BadFileFormatException("Aircraft not present: " + tokens[7]);

		// costruzione FlightSchedule
		FlightSchedule schedule;
		try {
			schedule = new FlightSchedule(code, departureAirport, departureLocalTime, 
												arrivalAirport, arrivalLocalTime, 
												dayOffset, daysOfWeek, aircraft);
		}
		catch(IllegalArgumentException e) {
			throw new BadFileFormatException(e);
		}
		return schedule;
	}

	private Collection<DayOfWeek> readDaysOfWeek(String days) throws BadFileFormatException {
		if (days.length() != 7)
			throw new BadFileFormatException();

		ArrayList<DayOfWeek> daysOfWeek = new ArrayList<DayOfWeek>();
		for (int i = 0; i < 7; i++) {
			char c = days.charAt(i);
			if (c == '1' + i) {
				daysOfWeek.add(DayOfWeek.of(c - '0'));
			} else if (c != '-') {
				throw new BadFileFormatException("Bad Days Format");
			}
		}
		return daysOfWeek;
	}

}
