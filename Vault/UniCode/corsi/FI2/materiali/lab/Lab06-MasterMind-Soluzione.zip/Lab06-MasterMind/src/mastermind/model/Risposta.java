package mastermind.model;

import java.util.Arrays;
import java.util.StringJoiner;

public class Risposta {

	private PioloRisposta[] risposta;
	private int dim;
	
	public Risposta(int size) {
		risposta = new PioloRisposta[size];
		this.dim = size;
		Arrays.fill(risposta, PioloRisposta.VUOTO);
	}
	
	public PioloRisposta getPiolo(int index) {
		// might throw NPE if the referenced board cell is null
		return risposta[index];
	}
	
	public void setPiolo(int index, PioloRisposta pr) {
		// might throw NPE if the referenced board cell is null 
		risposta[index] = pr; 
	}

	public int dim() {
		return dim;
	}
	
	public boolean vittoria() {
		for(PioloRisposta r:risposta) {
			if (!r.equals(PioloRisposta.NERO)) return false;
		}
		return true;
	}
	
	public String toString() {
		StringJoiner sb = new StringJoiner(",");
		for(PioloRisposta r:risposta) {
			sb.add(r.toString());
		}
		return sb.toString();
	}

	
	public boolean equals(Risposta that) {
		if (this == that) return true;
		if (that == null) return false;
		return (this.dim == that.dim) && Arrays.equals(this.risposta, that.risposta);
	}	 
	
}

