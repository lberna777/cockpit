package mastermind.model;

import java.util.Random;

public class MasterMind /*extends Gioco*/ {

	private Combinazione segreta;

	public MasterMind(int lunghezzaCodice) {
		this.segreta=new Combinazione(lunghezzaCodice);
		sorteggiaCombinazione(segreta);
	}
		
	public Risposta calcolaRisposta(Combinazione tentativo) {
		int neri = 0, totali = 0;
		for (int i=0; i<tentativo.dim(); i++) {
			if (tentativo.getPiolo(i).equals(segreta.getPiolo(i))) neri++;
		}
		// Usare degli array indicizzati per ordinal dell'enumerativo è un modo rozzo per fare tabelle
		// In futuro infatti useremo, assai più propriamente, delle mappe! Ma per ora...
		int[] occorrenzeSegreta = occorrenze(segreta);
		//	System.err.println("occorrenze nel codice segreto: " + Arrays.toString(occorrenzeSegreta));
		int[] occorrenzeTentativo = occorrenze(tentativo);
		//	System.err.println("occorrenze nel tentativo:      " + Arrays.toString(occorrenzeTentativo));
		for (PioloDiGioco p : PioloDiGioco.values()) {
			totali += Math.min(occorrenzeSegreta[p.ordinal()], occorrenzeTentativo[p.ordinal()]);
		}
		Risposta r = new Risposta(tentativo.dim());
		for (int i=0; i<neri; i++) r.setPiolo(i, PioloRisposta.NERO);
		for (int i=neri; i<totali; i++) r.setPiolo(i, PioloRisposta.BIANCO);
		return r;
	}

	private int[] occorrenze(Combinazione tentativo){
		// Usare degli array indicizzati per ordinal dell'enumerativo è un modo rozzo per fare tabelle
		// In futuro infatti useremo, assai più propriamente, delle mappe! Ma per ora...
		int[] arrayOccorrenze = new int[PioloDiGioco.values().length];
		for (int i=0; i<PioloDiGioco.values().length; i++) arrayOccorrenze[i]=0;
		for (int i=0; i<tentativo.dim(); i++) {
			PioloDiGioco pioloAttuale = tentativo.getPiolo(i);
			int frequenzaAttuale = arrayOccorrenze[pioloAttuale.ordinal()];
			arrayOccorrenze[pioloAttuale.ordinal()] = frequenzaAttuale+1;
		}
		return arrayOccorrenze;
	}
	
	protected void sorteggiaCombinazione(Combinazione segreta) {
		Random rnd = new Random();
		for(int i=0; i<this.segreta.dim();i++) {
			int randomIndex = rnd.nextInt(PioloDiGioco.values().length-1)+1; // range 1..6, escludendo 0 (VUOTA)
			segreta.setPiolo(i, PioloDiGioco.values()[randomIndex]);
		}		
	}
	
	public String combinazioneSegreta() {
		return segreta.toString();
	}
}

