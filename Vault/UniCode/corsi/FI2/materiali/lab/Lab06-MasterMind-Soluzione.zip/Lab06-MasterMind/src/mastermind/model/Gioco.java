package mastermind.model;

public class Gioco {

	private Combinazione[] tentativi;
	private Risposta[] risposte;
	private int numTentativi, maxTentativi, dim;
	private Status status;
	
	public Gioco(int maxTentativi, int dim) {
		this.maxTentativi=maxTentativi;
		tentativi = new Combinazione[maxTentativi];
		risposte = new Risposta[maxTentativi];
		numTentativi = 0;
		this.dim=dim;
		status = Status.IN_CORSO;
	}
	
	public int tentativiEffettuati(){
		return numTentativi;
	}

	public int maxTentativi(){
		return maxTentativi;
	}

	public int tentativiRimasti(){
		return maxTentativi-numTentativi;
	}
	
	public int dimensione() {
		return dim;
	}
	
	public Combinazione tentativo(int index) {
		if (index>=numTentativi) { // in futuro si lancerà eccezione di tipo IllegalArgumentException
			System.err.println("Tentativo " + index + " inesistente: l'ultimo è il " + numTentativi);
			return null; // pessimo! genera e propaga mine vaganti! Ma per ora...
		}
		return tentativi[index];
	}
	
	public Risposta risposta(int index) {
		if (index>=numTentativi) { // in futuro si lancerà eccezione di tipo IllegalArgumentException 
			System.err.println("Risposta " + index + " inesistente: l'ultima è la " + numTentativi);
			return null; // pessimo! genera e propaga mine vaganti! Ma per ora...
		}
		return risposte[index];
	}
	
	public Combinazione ultimoTentativo() {
		if (numTentativi==0) return null;
		return tentativo(numTentativi-1);
	}

	public Risposta ultimaRisposta() {
		if (numTentativi==0) return null;
		return risposta(numTentativi-1);
	}
	
	public Status registraMossa(Combinazione tentativo, Risposta risposta) {
		tentativi[numTentativi]=tentativo;
		risposte[numTentativi]=risposta;
		numTentativi++;
		if (risposta.vittoria()) status=Status.VITTORIA;
		else if (numTentativi<maxTentativi) status=Status.IN_CORSO;
		else status=Status.PERSO;
		return status;
	}
	
	public Status stato() {
		return status;
	}
	public String situazione() {
		StringBuilder sb = new StringBuilder(); 
		for (int i=0; i<numTentativi; i++) {
			sb.append((i+1) + ") " + tentativi[i].toString() + "\t\t" +
					(tentativi[i].toString().length()<20 ? "\t" : "") +
					risposte[i].toString()+ System.lineSeparator());
		}
		return sb.toString();
	}
	
	@Override
	public String toString() {
		return 	"Situazione:" + System.lineSeparator() + situazione() + System.lineSeparator() +
				"Gioco: " + this.stato() + System.lineSeparator();
	}

}

