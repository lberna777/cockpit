package mastermind.model;

import java.util.Arrays;
import java.util.StringJoiner;

public class Combinazione {

	private PioloDiGioco[] combinazione;
	private int dim;
	
	public Combinazione(int dim) {
		combinazione = new PioloDiGioco[dim];
		this.dim = dim;
		Arrays.fill(combinazione, PioloDiGioco.VUOTO);
	}
	
	public PioloDiGioco getPiolo(int index) {
		// might throw NPE if the referenced board cell is null
		return combinazione[index];
	}
	
	public void setPiolo(int index, PioloDiGioco c) {
		// might throw NPE if the referenced board cell is null 
		combinazione[index] = c; 
	}

	public int dim() {
		return dim;
	}
	
	public String toString() {
		StringJoiner sb = new StringJoiner(",");
		for(PioloDiGioco c:combinazione) {
			sb.add(c.toString());
		}
		return sb.toString();
	}

	public boolean equals(Combinazione that) {
		if (this == that) return true;
		if (that == null) return false;
		return (this.dim == that.dim) && Arrays.equals(this.combinazione, that.combinazione);
	}
	
}

