package oroscopo.controller;

import java.util.List;
import java.util.Random;

import oroscopo.model.Previsione;
import oroscopo.model.SegnoZodiacale;

public class MyStrategiaSelezione implements StrategiaSelezione {

	private Random r = new Random();
	
	@Override
	public Previsione seleziona(List<Previsione> previsioni, SegnoZodiacale segno) {
		if (previsioni == null || previsioni.isEmpty())
			throw new IllegalArgumentException("previsioni");
		if (segno == null)
			throw new IllegalArgumentException("segno");
		
		int maxIterazioni = 100*previsioni.size(); // watchdog per prevenire ciclo infinito nel caso non ci siano
		int iterCounter=0;						   // previsioni valide per il segno specificato
		
		Previsione risultato = null;

		while (!(risultato = previsioni.get(r.nextInt(previsioni.size()))).validaPerSegno(segno) && iterCounter<maxIterazioni) {
			iterCounter++;
		}
		if(iterCounter>=maxIterazioni) throw new IllegalArgumentException("Impossibile trovare una previsione valida per " + segno);

		return risultato;
	}

}
