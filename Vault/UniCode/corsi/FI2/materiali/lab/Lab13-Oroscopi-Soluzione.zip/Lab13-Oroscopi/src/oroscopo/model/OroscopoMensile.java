package oroscopo.model;

public class OroscopoMensile implements Oroscopo, Comparable<Oroscopo> {

	

	private Previsione amore, lavoro, salute;
	private SegnoZodiacale segnoZodiacale;

	private static SegnoZodiacale getSegnoZodiacaleFrom(String nomeSegnoZodiacale) {
		if (nomeSegnoZodiacale == null)
			throw new NullPointerException("segno null");
		
		if (nomeSegnoZodiacale.isEmpty())
			throw new IllegalArgumentException("segno vuoto");
		
		return SegnoZodiacale.valueOf(nomeSegnoZodiacale.toUpperCase());
	}

	public OroscopoMensile(String nomeSegnoZodiacale, Previsione amore, Previsione lavoro, Previsione salute) {
		this(getSegnoZodiacaleFrom(nomeSegnoZodiacale), amore, lavoro, salute);
	}

	public OroscopoMensile(SegnoZodiacale segno, Previsione amore, Previsione lavoro, Previsione salute) {
		if (segno == null)
			throw new NullPointerException("Il segno è null");
		if (amore == null || lavoro == null || salute == null)
			throw new NullPointerException("Una delle previsioni è null");

		if (!amore.validaPerSegno(segno) || !lavoro.validaPerSegno(segno) || !salute.validaPerSegno(segno))
			throw new IllegalArgumentException("Tutte le previsioni devono essere valide per: " + segno);

		this.amore = amore;
		this.lavoro = lavoro;
		this.salute = salute;
		this.segnoZodiacale = segno;
	}

	public SegnoZodiacale getSegnoZodiacale() {
		return segnoZodiacale;
	}

	public Previsione getPrevisioneAmore() {
		return amore;
	}

	public Previsione getPrevisioneSalute() {
		return salute;
	}

	public Previsione getPrevisioneLavoro() {
		return lavoro;
	}

	public int getFortuna() {
		//System.out.println("Amore = " + amore.getValore() +", Lavoro = " + lavoro.getValore() + ", Salute = " + salute.getValore());
		long val = Math.round((amore.getValore() + lavoro.getValore() + salute.getValore()) / 3.0);
		//System.out.println("Totale = " + val);
		return (int) val;
	}

	public String toString() {
		return "Amore:\t" + amore.getPrevisione() + "\n" + "Lavoro:\t" + lavoro.getPrevisione() + "\n" + "Salute:\t"
				+ salute.getPrevisione() + "\n";
	}

	public int compareTo(Oroscopo that) {
		if (that == null)
			throw new NullPointerException("that");

		int z1 = this.getSegnoZodiacale().ordinal();
		int z2 = that.getSegnoZodiacale().ordinal();
		return z1 < z2 ? -1 : (z1 == z2 ? 0 : 1);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((amore == null) ? 0 : amore.hashCode());
		result = prime * result + ((lavoro == null) ? 0 : lavoro.hashCode());
		result = prime * result + ((salute == null) ? 0 : salute.hashCode());
		result = prime * result + ((segnoZodiacale == null) ? 0 : segnoZodiacale.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OroscopoMensile other = (OroscopoMensile) obj;
		if (amore == null) {
			if (other.amore != null)
				return false;
		} else if (!amore.equals(other.amore))
			return false;
		if (lavoro == null) {
			if (other.lavoro != null)
				return false;
		} else if (!lavoro.equals(other.lavoro))
			return false;
		if (salute == null) {
			if (other.salute != null)
				return false;
		} else if (!salute.equals(other.salute))
			return false;
		if (segnoZodiacale != other.segnoZodiacale)
			return false;
		return true;
	}
}
